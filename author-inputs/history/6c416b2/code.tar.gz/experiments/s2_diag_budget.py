"""诊断（Claude 2026-10-07，未经审核，不是正式报告）：主测量参照段“本机预算终止”的归因。

正式规则（方案第 6 节；rewardfail/s2/guard.py 文件头）：单个进程池子进程超过上限被杀，“那一行记未裁定”。
rewardfail/s2/analyze.py 按子进程 pid（budget_killed）和池代次（gen_budget_kills）归因：参照段一个子进程连续判几千行，
它后来在某一行上超限被杀，此前已正常结束的几千行也都被记成“本机预算终止（未裁定）”。

这里把参照段复制到临时目录，在副本上重新合成逐行记录，只改一处：一次尝试的子进程已经写出 task_end（这一行在它被杀之前
已经判完），且结局不是池损坏或外层超时，就不再记预算终止。其余合成、分类、主指标与判定代码原样调用。原始运行目录只读。
输出：results/s2_main/budget_attribution_diag.json。

用法：.venv/bin/python -I experiments/s2_diag_budget.py [运行目录]
"""
import hashlib
import json
import shutil
import sys
import tempfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from rewardfail.s2 import analyze, report  # noqa: E402

RUN = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.home() / ".local/share/rewardfail/stage2/runs/main-20261007-202545"
OUT = ROOT / "results/s2_main/budget_attribution_diag.json"
fixed = Counter()


def fix(row):
    for a in row["attempts"]:
        c = a.get("child")
        if c and c.get("task_end") is not None and a.get("outcome") not in ("broken_pool", "outer_timeout"):
            if c.get("budget_killed") or a.get("gen_budget_kills"):
                fixed[row["id"]] += 1
            c["budget_killed"] = False
            a["gen_budget_kills"] = []
    return row


def classes(path):
    out = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            r = json.loads(line)
            out[r["id"]] = r["class"]
    return out


def manifest(run):
    files = sorted(p for p in run.rglob("*") if p.is_file())
    lines = [f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(run)}" for p in files]
    return len(files), hashlib.sha256("\n".join(lines).encode()).hexdigest()


def main():
    n_before, m_before = manifest(RUN)
    _check, _classify = analyze.check_row, analyze.classify
    analyze.check_row = lambda row: _check(fix(row))
    analyze.classify = lambda row: _classify(fix(row))
    with tempfile.TemporaryDirectory() as tmp:
        copy = Path(tmp) / "reference"
        shutil.copytree(RUN / "reference", copy)
        stats = analyze.summarize_stream(copy, copy / "rows-diag.jsonl")
        rcls_new = classes(copy / "rows-diag.jsonl")
    rcls_old = classes(RUN / "reference/rows.jsonl")
    dcls = classes(RUN / "default/rows.jsonl")
    ids = [i for i in dcls if not i.startswith("warm-")]
    m_old, k_old, _ = report.main_metric(ids, dcls, rcls_old)
    m_new, k_new, u_new = report.main_metric(ids, dcls, rcls_new)
    ones = [i for i in rcls_new if not i.startswith("warm-") and report.default_verdict(dcls.get(i)) == 1]
    changed = Counter((rcls_old[i], rcls_new.get(i)) for i in rcls_old if rcls_old[i] != rcls_new.get(i))
    n_after, m_after = manifest(RUN)
    out = {"what": "诊断：参照段预算终止只记被杀时仍在判的那一行，重新合成后重算主指标（未经审核，不是正式报告）",
           "run_dir": str(RUN), "rows_with_fixed_attempts": len(fixed), "fixed_attempts": sum(fixed.values()),
           "reference_classes": {"official": dict(Counter(rcls_old.values())), "diagnostic": dict(Counter(rcls_new.values()))},
           "class_changes": {f"{a} → {b}": n for (a, b), n in changed.most_common()},
           "budget_rows_diagnostic": sorted(i for i, c in rcls_new.items() if c == "本机预算终止（未裁定）"),
           "interrupted_twice_diagnostic": sorted(i for i, c in rcls_new.items() if c.startswith("未裁定（中断两次")),
           "main_metric": {"official": m_old, "diagnostic": m_new},
           "k_ids": {"official": k_old, "diagnostic": k_new}, "u_ids_diagnostic": u_new,
           "reference_on_default_1": {"official": dict(Counter(rcls_old.get(i) for i in ones)),
                                      "diagnostic": dict(Counter(rcls_new[i] for i in ones))},
           "reference_events": {"official": sum(1 for c in rcls_old.values() if c not in ("1 分", "正常 0")),
                                "diagnostic": sum(1 for c in rcls_new.values() if c not in ("1 分", "正常 0"))},
           "resynth_stats": {k: v for k, v in stats.items() if k in ("rows", "warm_rows", "pools", "budget_kills",
                                                                     "hard_stops", "interrupted_rows")},
           "raw_files": {"before": [n_before, m_before], "after": [n_after, m_after], "unchanged": m_before == m_after}}
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    m = m_new
    print(f"诊断：k={m['k']} u={m['u']} 上界={m['upper_one_sided_95_k_plus_u']:.3g}（正式 u={m_old['u']}，"
          f"上界={m_old['upper_one_sided_95_k_plus_u']:.3g}）；原始文件不变={out['raw_files']['unchanged']}")


if __name__ == "__main__":
    main()
