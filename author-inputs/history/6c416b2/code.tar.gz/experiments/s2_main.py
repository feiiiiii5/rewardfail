"""第二阶段主测量（方案第 4–7 节；Codex 10-07 审核第 13.2 节第 2、4、5 项修订）。

顺序：默认一遍 → 参照 → 时限 2 秒与 10 秒 → 原设置重放 3 次 → 随机 1% 重测 → 判定与统计。
重放放在时限检查之后（修订前在之前，后来才出现的时限敏感变化补不进重放）。重放集合是下面几类的并集
（report.replay_set）：默认那一遍有事件、参照有事件、主指标翻转（k）、2/5/10 秒裁定不全相同、默认单行超过 10 秒。
条件实验候选在重放集合里找（report.candidates）：默认与三次重放都外层超时、都池损坏（任何一次是本机预算终止的不算），
或默认、重放任一次单行超过 10 秒（预算终止的那几次不算）。

Codex 审核测量前提之前不对主样本运行（D111、D130、D131）：--source main 必须同时给 --confirm-main。
测试：--source pilot 用主样本以外的回答（试跑集，rewardfail/s2/data.py 的 pilot_set）走同一流程；--synthetic 再混入
五条注入行（与自检同一套注入），核对 k、u 的记账、重放、时限敏感度和条件实验候选。流程本身另有不调用判分器的
替身测试（tests/test_s2_flow.py）。

预先写定的随机选择（种子与 plan/sample_map.py 相同，只用题面哈希 key，不看任何判分结果）：
- 重测 1%：draw(b"retest", key, 100) == 0；
- 时限敏感度的随机 1%：draw(b"limits", key, 100) == 0（有库内超时或任一步超过 1 秒的行本来就跑）；
- 参照核查的 1,000 条默认得 1 的行：按 sha256(种子 \\0 refone \\0 key) 前 8 字节从小到大排，取前 1,000 条默认得 1 的。
跟进只针对主样本里的行。参照覆盖默认不是 1 的全部行（0、最终异常与其他未裁定），另加上面 1,000 条。

并发：每段开始时按方案第 6 节的公式算 P（预算 = min(8 GiB, max(1 GiB, 可用 − 1.5 GiB))，留一个子进程涨到上限的
余量，流水线与子进程常驻取试跑实测），再取它与 --P 的较小者；算出 P<1 就停下（“不强行开一条”；1 GiB 的预算下限
因此不会强行开跑），等机器空闲后用同一 --run-dir 续跑。

资源保护：判分段由 supervise.run_phase 里的整机保护管；构建任务与生成版本锁、核对版本锁、分桶合成、段间统计和最终
汇总由 rewardfail/s2/stepguard.py 管，同一套条件，记录在运行目录 guard-steps.jsonl。停在这些环节退出码 7（主线程卡住、
被直接结束是 6），已完成的段不受影响，续跑时这个环节重来。环节结束时才查到的停止要求同样退出码 7，不进入下一阶段
（Codex 10-07 修订复核第 15.2 节）。

版本锁（续跑核对）：第一次运行把实际执行的代码（rewardfail/__init__.py、rewardfail/s2/*.py、s2_main.py、s2_worker.py）
各文件的 sha256 记下，并把这些文件原样存一份在运行目录 code/ 下；连同被测 verl 仓的提交与工作树状态、包装文件
sha256、Python 与关键包版本、抽样映射与十个数据分片的 sha256、预先抽取与命令参数（--P 只管调度，不在内），写进
run.json 的 lock。续跑时逐项重算核对，有一项不同就停下并列出不同，不删原记录、不自动重判；拒绝的原因同时记在
guard-steps.jsonl 里“核对版本锁”这一环节的结束记录（outcome=error 与 error 摘要）。代码文件只改了注释或
文档字符串的，要在运行目录 compat.json 里逐个登记（文件、旧新 sha256、审查说明），并且去掉文档字符串后的语法树
与快照相同，才放行；放行记进 run.json 的 resumes。
每段开始写 pass_spec.json（模式、时限参数、行数与行编号摘要、单子进程上限、单行时限）；已有记录的段只有 spec 相同
才续跑或复用 pass_done.json，不同就停下。

检查点：每段一个目录，已判过的行跳过；整段判完、逐行记录合成后写 pass_done.json。文件都先写临时文件再改名。
结果：主样本写 results/s2_main/report.json，测试默认写 results/s2_rev1/main_test/report.json（--out 可改）；
运行目录里各留一份。
"""
import argparse
import ast
import hashlib
import json
import shutil
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import psutil  # noqa: E402

from rewardfail.s2 import analyze, data, guard as guard_mod, mem, report, supervise  # noqa: E402
from rewardfail.s2.atype import answer_type  # noqa: E402
from rewardfail.s2.envinfo import env  # noqa: E402
from rewardfail.s2.stepguard import EXIT_STOP, StepGuard, StepStop, every, write_atomic  # noqa: E402

GiB, MiB = 1 << 30, 1 << 20
RUNS = Path.home() / ".local/share/rewardfail/stage2/runs"
REF_ONES = 1000
PCT = 100  # 1%
ROW_LIMIT = {"observe": 2 * 30 + 90, "reference": 2 * 300 + 90}
PILOT_REPORT = ROOT / "results/s2_rev1/pilot/report.json"  # 修订后重跑的试跑（观测层改了，流水线内存取新实测）
EXEC_FILES = ("rewardfail/__init__.py", "rewardfail/s2/*.py", "experiments/s2_main.py", "experiments/s2_worker.py")
STEPS_LOG = "guard-steps.jsonl"

SYNTHETIC = [  # 只在测试时混入；题目平凡，注入与自检同一套
    {"id": "syn-flip", "gt": "2", "out": "The answer is \\boxed{2}", "inject": {"slow": "pred_parse", "sec": 8}},
    {"id": "syn-refto", "gt": "2", "out": "The answer is \\boxed{2}", "inject": {"slow": "pred_parse", "sec": 65}},
    {"id": "syn-exc", "gt": "2", "out": "The answer is \\boxed{2}", "fault": "kill_persistent"},
    {"id": "syn-hog", "gt": "2", "out": "The answer is \\boxed{2}", "inject": {"hog_mb": 700, "hold": 20}},
    {"id": "syn-outer", "gt": "2", "out": "The answer is \\boxed{2}", "timeout": 0},
]
SYN_EXPECT = {  # 默认类别、参照类别、记入 k/u、2 秒/默认/10 秒的裁定（None 表示不在时限跟进里）
    "syn-flip": ("0 分：回答侧解析超时", "1 分", "k", "0/0/1"),
    "syn-refto": ("0 分：回答侧解析超时", "0 分：回答侧解析超时", "u", "0/0/0"),
    "syn-exc": ("最终异常（BrokenProcessPool）", "最终异常（BrokenProcessPool）", "u", None),
    "syn-hog": ("本机预算终止（未裁定）", "本机预算终止（未裁定）", "u", None),
    "syn-outer": ("0 分：外层超时", "0 分：外层超时", "u", None),
}


def log(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)


def build(a, tick):
    """任务（编号、分片、行号、第几条回答）与每题的元数据（key、前后半、答案类型）。"""
    rows = data.load_map()
    tick()
    answers = data.answers_by_row(tick=tick)
    tasks, meta = [], {}
    t1 = every(1000, tick)
    if a.source == "main":
        for r in rows:
            t1()
            tid = "m-" + r["key"][:16]
            tasks.append({"id": tid, "shard": r["shard"], "row": r["row"], "idx": r["pick"]})
            meta[tid] = {"key": r["key"], "half": r["half"], "atype": answer_type(answers[(r["shard"], r["row"])])}
    else:
        by_pos = {(r["shard"], r["row"]): r for r in rows}
        for t in data.pilot_set(rows, answers, tick=tick)[:a.n]:
            t1()
            r = by_pos[(t["shard"], t["row"])]
            tid = "t-" + t["id"][len("pilot-"):]
            tasks.append({"id": tid, "shard": t["shard"], "row": t["row"], "idx": t["idx"]})
            meta[tid] = {"key": r["key"], "half": r["half"], "atype": t["atype"]}
    if len(meta) != len(tasks):
        raise SystemExit("任务编号有重复")
    tasks.sort(key=lambda t: (t["shard"], t["row"], t["idx"]))
    if a.synthetic:
        for i, s in enumerate(SYNTHETIC):
            tasks.append(dict(s))
            meta[s["id"]] = {"key": hashlib.sha256(s["id"].encode()).hexdigest(), "half": i % 2, "atype": "整数"}
    return tasks, meta


def make_draws(ids, meta, tick=lambda: None):
    d, t1 = {}, every(5000, tick)
    for i in ids:
        t1()
        key = bytes.fromhex(meta[i]["key"])
        d[i] = (data.draw(b"retest", key, PCT) == 0, data.draw(b"limits", key, PCT) == 0,
                int.from_bytes(hashlib.sha256(data.SEED + b"\x00refone\x00" + key).digest()[:8], "big"))
    return d


def digest(ids):
    return hashlib.sha256("\n".join(ids).encode()).hexdigest()


# ---------------- 版本锁（Codex 10-07 审核第 13.2 节第 5 项）----------------
def file_sha(path, tick=None):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while chunk := fh.read(8 << 20):
            h.update(chunk)
            if tick:
                tick()
    return h.hexdigest()


def exec_files(root=ROOT):
    return sorted({f for pat in EXEC_FILES for f in root.glob(pat)})


def _git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True).stdout.strip()


def current_lock(pre, tick=None):
    """这一次实际会执行的版本：代码、被测源码、依赖、数据、预先抽取与参数。"""
    e = env()
    vdir = Path(e["verl_dir"])
    return {"pre": pre,
            "code_sha256": {str(f.relative_to(ROOT)): file_sha(f) for f in exec_files()},
            "tested_source": {"verl_dir": e["verl_dir"], "verl_head": _git(vdir.parent, "rev-parse", "HEAD"),
                              "verl_dirty": _git(vdir.parent, "status", "--porcelain").splitlines(),
                              "wrapper_sha256": file_sha(vdir / "utils/reward_score/math_verify.py")},
            "python": e["python"], "versions": e["versions"],
            "data": {"sample_map_sha256": file_sha(data.STAGE2 / "sample_map.tsv"),
                     "shards_sha256": {f.name: file_sha(f, tick) for f in sorted(data.SHARDS.glob("train-*.parquet"))}}}


def lock_diffs(old, new, path=()):
    """逐项比较两份锁，返回 [(项, 旧值, 新值)]。"""
    if isinstance(old, dict) and isinstance(new, dict):
        out = []
        for k in sorted(set(old) | set(new), key=str):
            out += lock_diffs(old.get(k), new.get(k), (*path, str(k)))
        return out
    return [] if old == new else [(" / ".join(path), old, new)]


def code_tree(src):
    """去掉模块、类、函数的文档字符串后的语法树（注释本来就不在语法树里）。"""
    tree = ast.parse(src)
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            b = node.body
            if b and isinstance(b[0], ast.Expr) and isinstance(b[0].value, ast.Constant) and isinstance(b[0].value.value, str):
                node.body = b[1:] or [ast.Pass()]
    return ast.dump(tree)


def check_lock(base, lock, root=ROOT):
    """第一次运行写锁和代码快照，返回 (False, [])；续跑逐项核对，返回 (True, 放行的注释改动)。不同就停下。"""
    pj = base / "run.json"
    if not pj.exists():
        for rel in lock["code_sha256"]:
            dst = base / "code" / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(root / rel, dst)
        write_atomic(pj, json.dumps({"lock": lock, "env": env(), "started": time.strftime("%Y-%m-%d %H:%M:%S"),
                                     "resumes": []}, ensure_ascii=False, indent=1))
        return False, []
    run = json.loads(pj.read_text(encoding="utf-8"))
    if "lock" not in run:
        raise SystemExit(f"{pj} 没有版本锁（修订前的运行目录），不能用这一版脚本续跑")
    diffs = lock_diffs(run["lock"], lock)
    other = [d for d in diffs if not d[0].startswith("code_sha256 / ")]
    if other:
        raise SystemExit("续跑时的执行版本与第一次运行不同，停下（不删原记录、不自动重判）：\n"
                         + "\n".join(f"  {k}：{x} → {y}" for k, x, y in other))
    allowed, bad = [], []
    cp = base / "compat.json"
    compat = json.loads(cp.read_text(encoding="utf-8")).get("files", {}) if cp.exists() else {}
    for k, old_sha, new_sha in diffs:
        rel = k[len("code_sha256 / "):]
        rec = compat.get(rel) or {}
        why = None
        if old_sha is None or new_sha is None:
            why = "文件新增或删除"
        elif rec.get("old") != old_sha or rec.get("new") != new_sha or not rec.get("note"):
            why = "compat.json 没有登记这次改动（文件、旧新 sha256、审查说明）"
        elif code_tree((base / "code" / rel).read_text(encoding="utf-8")) != code_tree((root / rel).read_text(encoding="utf-8")):
            why = "去掉文档字符串后语法树与快照不同，是执行变化"
        if why:
            bad.append(f"  {rel}：{why}")
        else:
            allowed.append({"file": rel, "old": old_sha, "new": new_sha, "note": rec["note"]})
    if bad:
        raise SystemExit("续跑时代码与第一次运行不同，停下（不删原记录、不自动重判）：\n" + "\n".join(bad))
    run["resumes"].append({"t": time.strftime("%Y-%m-%d %H:%M:%S"), "compat_allowed": allowed})
    write_atomic(pj, json.dumps(run, ensure_ascii=False, indent=1))
    return True, allowed


def pass_spec(name, tasks, mode, extra, child_limit):
    return {"pass": name, "mode": mode, "extra": list(extra), "n": len(tasks), "ids_sha256": digest([t["id"] for t in tasks]),
            "child_limit": child_limit, "row_limit": ROW_LIMIT[mode]}


def check_spec(d, spec):
    """段参数：第一次写 pass_spec.json；已有的必须相同。已有记录却没有 spec 的也停下。"""
    sp = d / "pass_spec.json"
    if sp.exists():
        old = json.loads(sp.read_text(encoding="utf-8"))
        if old != spec:
            raise SystemExit(f"{d.name} 段的参数与已有记录不同，停下（不删原记录、不自动重判）：\n"
                             + "\n".join(f"  {k}：{x} → {y}" for k, x, y in lock_diffs(old, spec)))
        return
    if d.exists() and any(d.iterdir()):
        raise SystemExit(f"{d.name} 段已有记录却没有 pass_spec.json，确认不了参数，停下")
    d.mkdir(parents=True, exist_ok=True)
    write_atomic(sp, json.dumps(spec, ensure_ascii=False, indent=1))


# ---------------- 各段 ----------------
def choose_P(a):
    p = json.loads(PILOT_REPORT.read_text(encoding="utf-8"))["plan_P"]
    vm = psutil.virtual_memory()
    budget = min(8 * GiB, max(1 * GiB, vm.available - int(1.5 * GiB)))
    sup = mem.usage()[0]
    formula = guard_mod.plan_parallel(budget - sup, int(p["pipeline_max"] * GiB), int(p["child_base_p50"] * GiB),
                                      a.child_limit)
    return min(a.P, formula), {"budget_gib": round(budget / GiB, 3), "available_gib": round(vm.available / GiB, 3),
                               "supervisor_gib": round(sup / GiB, 3), "pipeline_gib_from_pilot": p["pipeline_max"],
                               "child_base_gib_from_pilot": p["child_base_p50"], "child_limit_gib": round(a.child_limit / GiB, 3),
                               "formula_P": formula, "max_P": a.P, "pilot_report": str(PILOT_REPORT.relative_to(ROOT))}


def load_stats(d):
    st = [e for f in sorted(d.glob("guard-*.jsonl")) for e in analyze._jsonl(f) if e["ev"] == "status"]
    ld = sorted(e["load1"] for e in st if e.get("load1") is not None)
    return {"status_records": len(st), "load1_p50": ld[len(ld) // 2] if ld else None, "load1_max": ld[-1] if ld else None,
            "pressure_max": max((e["pressure"] for e in st), default=None),
            "avail_min_gib": round(min((e["avail"] for e in st), default=0) / GiB, 3),
            "swap_max_gib": round(max((e["swap"] for e in st), default=0) / GiB, 3)}


def run_pass(base, name, tasks, mode, extra, a):
    d = base / name
    check_spec(d, pass_spec(name, tasks, mode, extra, a.child_limit))
    done = d / "pass_done.json"
    if done.exists():
        return dict(json.loads(done.read_text(encoding="utf-8")), reused=True)
    if not tasks:
        write_atomic(d / "rows.jsonl", "")
        info = {"pass": name, "tasks": 0, "skipped": "没有要跑的行"}
        write_atomic(done, json.dumps(info, ensure_ascii=False, indent=1))
        return info
    P, pinfo = choose_P(a)
    if P < 1:
        log(f"{name}：按当前可用内存算出 P={pinfo['formula_P']}，不强行开一条（方案第 6 节）；{pinfo}。"
            f"等机器空闲后用 --run-dir {base} 续跑")
        sys.exit(3)
    log(f"{name}：{len(tasks)} 行，P={P}（{pinfo}）")
    t0 = time.time()
    res = supervise.run_phase(d, tasks, P, worker_args=["--mode", mode, *extra], label=name,
                              guard_kw={"child_limit": a.child_limit}, row_limit=ROW_LIMIT[mode])
    if res.get("aborted"):
        write_atomic(d / f"aborted-{int(time.time())}.json", json.dumps(res, ensure_ascii=False, indent=1, default=str))
        log(f"{name} 段中止：{res['aborted']}；用 --run-dir {base} 续跑")
        sys.exit(2)
    with StepGuard(base / STEPS_LOG, f"{name}·合成逐行记录") as sg:
        stats = analyze.summarize_stream(d, d / "rows.jsonl", tick=sg.tick)
    info = {"pass": name, "mode": mode, "extra": extra, "tasks": len(tasks), "P": P, "P_info": pinfo, "supervise": res,
            "stats": stats, "seconds": round(time.time() - t0, 1), "load": load_stats(d)}
    write_atomic(done, json.dumps(info, ensure_ascii=False, indent=1, default=str))
    log(f"{name} 完成：{info['seconds']} 秒")
    return info


def scan(d, tick=lambda: None):
    t1 = every(2000, tick)
    with open(d / "rows.jsonl", encoding="utf-8") as fh:
        for line in fh:
            t1()
            r = json.loads(line)
            if not r.get("warm"):
                yield r


def classes(d, tick=lambda: None):
    return {r["id"]: sys.intern(r["class"]) for r in scan(d, tick)}


def followups(base, ids, by_id, draws, run, seg):
    """跟进流程（方案第 4 节；Codex 10-07 审核第 13.2 节第 2 项修订）。run(name, tasks, mode, extra) 跑一段，
    逐行记录写在 base/name/rows.jsonl（主测量里是 run_pass；替身测试里直接写记录）；seg(label) 给段间统计套资源保护。"""
    passes = {"default": run("default", [by_id[i] for i in ids], "observe", [])}
    with seg("默认一遍·统计") as sg:
        tally = report.DefaultTally()
        for r in scan(base / "default", sg.tick):
            tally.add(r)
        dcls = tally.cls
        refone_order = sorted(ids, key=lambda i: draws[i][2])
        ones = [i for i in refone_order if report.default_verdict(dcls.get(i)) == 1][:REF_ONES]
        ones_set = set(ones)
        ref_ids = [i for i in ids if report.default_verdict(dcls.get(i)) != 1 or i in ones_set]
    passes["reference"] = run("reference", [by_id[i] for i in ref_ids], "reference", [])
    with seg("参照·统计") as sg:
        rcls, rev = {}, set()
        for r in scan(base / "reference", sg.tick):
            rcls[r["id"]] = sys.intern(r["class"])
            if report.is_event(r):
                rev.add(r["id"])
        metric, k_ids, u_ids = report.main_metric(ids, dcls, rcls)
        rand_lim = {i for i in ids if draws[i][1]}
        lim_ids = [i for i in ids if (i in tally.keep and report.is_limit_row(tally.keep[i])) or i in rand_lim]
    log(f"主指标：n={metric['n']} k={metric['k']} u={metric['u']}")
    passes["limit2s"] = run("limit2s", [by_id[i] for i in lim_ids], "observe", ["--limits", "2"])
    passes["limit10s"] = run("limit10s", [by_id[i] for i in lim_ids], "observe", ["--limits", "10"])
    with seg("时限·统计") as sg:
        lc2, lc10 = classes(base / "limit2s", sg.tick), classes(base / "limit10s", sg.tick)
        lim = report.limits_table(lim_ids, lc2, dcls, lc10)
        sens = report.limit_sensitive(lim_ids, lc2, dcls, lc10)
        rep_ids, why = report.replay_set(ids, tally.keep, rev, set(k_ids), sens)
    for j in (1, 2, 3):
        passes[f"replay{j}"] = run(f"replay{j}", [by_id[i] for i in rep_ids], "observe", [])
    retest_ids = [i for i in ids if draws[i][0]]
    passes["retest"] = run("retest", [by_id[i] for i in retest_ids], "observe", [])
    with seg("重放与重测·统计") as sg:
        reps = [{r["id"]: r for r in scan(base / f"replay{j}", sg.tick)} for j in (1, 2, 3)]
        rep = report.replays(rep_ids, dcls, reps)
        cands = report.candidates(rep_ids, tally.keep, reps)
        rt = report.retest(retest_ids, dcls, classes(base / "retest", sg.tick))
    return {"passes": passes, "tally": tally, "dcls": dcls, "rcls": rcls, "ones": ones, "metric": metric, "k_ids": k_ids,
            "u_ids": u_ids, "lim_ids": lim_ids, "lc2": lc2, "lc10": lc10, "limits": lim, "sensitive": sens,
            "rep_ids": rep_ids, "replay_why": why, "replays": rep, "candidates": cands, "retest_ids": retest_ids, "retest": rt}


def synthetic_check(f, ids):
    dcls, rcls, lc2, lc10 = f["dcls"], f["rcls"], f["lc2"], f["lc10"]
    k_set, u_set, rep, cands = set(f["k_ids"]), set(f["u_ids"]), f["replays"], f["candidates"]
    got = {}
    for i, (d_exp, r_exp, ku, lim_exp) in SYN_EXPECT.items():
        g = (dcls.get(i), rcls.get(i), "k" if i in k_set else "u" if i in u_set else "-",
             None if i not in lc2 else "/".join("未" if v is None else str(v) for v in
                                               (report.default_verdict(lc2.get(i)), report.default_verdict(dcls.get(i)),
                                                report.default_verdict(lc10.get(i)))))
        exp = (d_exp, r_exp, ku, lim_exp)
        got[i] = {"expected": exp, "got": g, "pass": g == exp if lim_exp is not None or i not in lc2 else g[:3] == exp[:3]}
    natural = [i for i in ids if not i.startswith("syn-")]
    rep_set = set(f["rep_ids"])
    extra = {"syn-exc 在继续第 1 条": rep["continue_1_reproducible_final_exception"] == ["syn-exc"],
             "条件实验候选是 syn-outer（外层超时）与 syn-exc（池损坏），不含预算终止的 syn-hog":
                 sorted(c["id"] for c in cands if c["id"].startswith("syn-")) == ["syn-exc", "syn-outer"]
                 and [c["id"] for c in cands if c["outer_timeout_every_time"]] == ["syn-outer"],
             "合成行都在重放里": all(i in rep_set for i in SYN_EXPECT),
             "时限敏感的行都在重放里": all(i in rep_set for i in f["sensitive"]),
             "试跑行没有未裁定": all(report.default_verdict(dcls.get(i)) is not None for i in natural),
             "门槛算术": report.lower(111, 93733) >= 1e-3 > report.lower(110, 93733)
                        and report.upper(4, 93733) < 1e-4 <= report.upper(5, 93733)}
    ok = all(v["pass"] for v in got.values()) and all(extra.values())
    return {"rows": got, "other": extra, "pass": ok}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", choices=["main", "pilot"], required=True)
    ap.add_argument("--confirm-main", action="store_true", help="Codex 审核测量前提并经用户转交确认后才给")
    ap.add_argument("--run-dir", help="续跑：给上次的运行目录")
    ap.add_argument("--P", type=int, default=4, help="并发上限；实际取它与方案第 6 节公式的较小者（只管调度，不进版本锁）")
    ap.add_argument("--n", type=int, default=300, help="测试：取试跑集前 n 条")
    ap.add_argument("--synthetic", action="store_true", help="测试：混入注入行")
    ap.add_argument("--child-limit-mib", type=int, default=None, help="测试：单个子进程上限（主测量固定 3 GiB）")
    ap.add_argument("--out", help="报告写到哪里（默认见文件开头）")
    a = ap.parse_args()
    if a.source == "main":
        if not a.confirm_main:
            ap.error("主样本要等 Codex 审核测量前提（D111、D130、D131），确认后才加 --confirm-main")
        if a.synthetic or a.child_limit_mib:
            ap.error("--synthetic、--child-limit-mib 只用于测试")
    a.child_limit = (a.child_limit_mib or 3072) * MiB
    tag = "main" if a.source == "main" else "maintest"
    base = Path(a.run_dir) if a.run_dir else RUNS / f"{tag}-{time.strftime('%Y%m%d-%H%M%S')}"
    base.mkdir(parents=True, exist_ok=True)
    dest = Path(a.out) if a.out else ROOT / ("results/s2_main/report.json" if a.source == "main"
                                            else "results/s2_rev1/main_test/report.json")
    t0 = time.time()
    try:
        with StepGuard(base / STEPS_LOG, "构建任务与生成版本锁") as sg:  # 这一块只生成当前的锁，比较在下一块
            tasks, meta = build(a, sg.tick)
            ids = [t["id"] for t in tasks]
            by_id = {t["id"]: t for t in tasks}
            draws = make_draws(ids, meta, sg.tick)
            retest_ids = [i for i in ids if draws[i][0]]
            rand_lim = {i for i in ids if draws[i][1]}
            refone_order = sorted(ids, key=lambda i: draws[i][2])
            pre = {"source": a.source, "n": len(ids), "ids_sha256": digest(ids), "retest": len(retest_ids),
                   "retest_sha256": digest(retest_ids), "limits_random": len(rand_lim),
                   "limits_random_sha256": digest(sorted(rand_lim)), "refone_order_sha256": digest(refone_order),
                   "synthetic": bool(a.synthetic), "child_limit_mib": a.child_limit // MiB}
            lock = current_lock(pre, sg.tick)
        with StepGuard(base / STEPS_LOG, "核对版本锁"):
            resumed, allowed = check_lock(base, lock)
        log(f"运行目录 {base}；{len(ids)} 行；{'续跑，版本核对一致' if resumed else '第一次运行，已写版本锁'}"
            + (f"（放行只改注释的文件 {[x['file'] for x in allowed]}）" if allowed else "") + f"；预先抽取 {pre}")
        f = followups(base, ids, by_id, draws, lambda name, ts, mode, extra: run_pass(base, name, ts, mode, extra, a),
                      lambda label: StepGuard(base / STEPS_LOG, label))
        with StepGuard(base / STEPS_LOG, "汇总报告") as sg:
            tally, dcls, rcls, k_set = f["tally"], f["dcls"], f["rcls"], set(f["k_ids"])
            types = report.answer_types(ids, meta, k_set, set(f["u_ids"]))
            sg.tick()
            ref_ones = {"rows": len(f["ones"]), "reference_classes": dict(Counter(rcls.get(i) for i in f["ones"])),
                        "not_1": sum(1 for i in f["ones"] if report.ref_verdict(rcls.get(i)) != 1)}
            rep = f["replays"]
            out = {"what": "第二阶段主测量" if a.source == "main" else "第二阶段主测量脚本测试（主样本以外的回答，不是测量结果）",
                   "run_dir": str(base), "pre": pre, "lock": {k: v for k, v in lock.items() if k != "pre"}, "resumed": resumed,
                   "compat_allowed": allowed, "env": env(), "passes": f["passes"], "main_metric": f["metric"],
                   "answer_types": types,
                   "default_events": {name: report.rate(tally.ev[name], len(ids)) for name, _ in report.EVENTS},
                   "default_classes": dict(Counter(dcls.values())), "reference_classes": dict(Counter(rcls.values())),
                   "replay_set": {"rows": len(f["rep_ids"]), "why": f["replay_why"]},
                   "replays": {k: v for k, v in rep.items() if k != "detail"}, "replay_detail": rep["detail"],
                   "concurrency_candidates": f["candidates"], "limits": f["limits"], "retest": f["retest"],
                   "reference_check_on_default_1": ref_ones,
                   "decision": report.decide(f["metric"], types, rep, f["candidates"]), "seconds": round(time.time() - t0, 1)}
            ok = True
            if a.synthetic:
                out["synthetic_check"] = synthetic_check(f, ids)
                ok = out["synthetic_check"]["pass"]
            text = json.dumps(out, ensure_ascii=False, indent=1, default=str)
            dest.parent.mkdir(parents=True, exist_ok=True)
            write_atomic(dest, text)
            write_atomic(base / "report.json", text)
    except StepStop as e:
        log(f"{e}；已完成的段不受影响，用 --run-dir {base} 续跑")
        sys.exit(EXIT_STOP)
    log(f"写好 {dest}；判定 {out['decision']}" + (f"；合成行核对 {'通过' if ok else '不通过'}" if a.synthetic else ""))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
