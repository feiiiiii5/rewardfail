"""第二阶段观测层与整机保护自检（方案第 4、6 节；Codex 复核第 11.2 节）。每项期望先写在这里，再跑。

阶段（全部只用本机 CPU、合成输入，不读真实数据）：
 G  保护逻辑（不起进程，替换采样读数和时钟）：读数失败、严重压力、警告持续、超预算持续、
    交换区持续增长与重设基线、恢复要连续 30 秒、单个子进程超限被杀、并发数 P 的计算。
 G2 真实内存读数：起一个子进程写满 400 MiB 同一字节，看 16 秒。分两项（Codex 10-07 审核第 13.4 节）：存续占用按
    footprint 计入（通过/未通过）；RSS 下降时 footprint 保持——这次 RSS 没有比 footprint 低 10% 以上的读数就记“未验证”，
    不为它制造整机内存压力，压缩情景的证据是独立探针 results/s2_selftest/footprint_probe.*。
 A  顺序注入（观测开启）：正常 1/0、两侧解析超时、比较超时（字符串救回与否）、两侧库其他异常、
    收到计时信号而库没记超时（模拟吞掉异常）、长 C 计算拖晚计时信号、外层超时与杀池、退出一次重试恢复、
    持续退出最终抛出、坏池连带下一行、单进程超限被保护杀掉、壳层库超时异常、钩子只装一次、状态记录的分角色内存、
    日志里没有输入原文（含测量进程日志）。
 A- 观测负对照（Codex 10-07 审核第 13.2 节第 1 项）：把 A 段的原始记录复制出来，逐个删行、重复行、改池代次、改进程号、
    颠倒步骤、改结果或时限，每种改法都必须让被改的行进“观测不完整（未裁定）”，并且只看逐行检查时其他行的问题与
    类别不变；删行、重复行另要触发文件级序号检查。原记录不动，副本留在运行目录 A-negative/ 下。
 B  并发连带（观测开启，17 个线程）：慢行外层超时重置杀池；之前已完成的同行不受损；在途同行池损坏一次后在新池恢复，
    它们的重置因身份检查不杀池。
 C  开关对照：同一组输入与外部故障（调用前杀池、持续杀新池、外层 0 秒超时），观测开、关各跑一遍，
    分数/异常与池状态逐行一致。
 R  参照时限（reference）：解析或比较慢 8 秒，在 60 秒时限下得 1 分，子进程收到的时限是 60/60。
 D  整项停止：给一个小预算，让一行占内存时超预算 → 暂停 → 持续 → 整项停止、整组杀掉 → 等条件解除 → 从检查点续跑；
    同一行中断两次记未裁定；已完成的行不重跑。
 E  中断与调度不在：一行判到一半从外面杀掉整个测量进程组，调度重启后这行重跑完成，逐行记录只取产出结果的那次启动
    （负对照：不按测量进程筛，会取到被杀那次的子进程）；调度进程退出后，测量进程不做新行、收尾退出。
A 段另核主测量用的分桶合成：每 2 行一桶合成的精简逐行记录，与一次合成的逐字段相同。
每项结果是“通过”“未通过”或“未验证”（条件没出现，不算通过也不算未通过）。结果写 results/s2_rev2/selftest/report.json
（10-07 晚第二次修订后；第一次修订后的 results/s2_rev1/selftest/report.json 与修订前的 results/s2_selftest/report.json
原样保留）；原始记录在
~/.local/share/rewardfail/stage2/runs/selftest-时间/ 下各阶段目录。
"""
import json
import os
import shutil
import signal
import subprocess
import sys
import threading
import time
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import psutil  # noqa: E402

from rewardfail.s2 import analyze, guard as guard_mod, mem, supervise  # noqa: E402
from rewardfail.s2.envinfo import env  # noqa: E402

GiB, MiB = 1 << 30, 1 << 20
GT, OK = "2", "The answer is \\boxed{2}"
CHECKS = []


def check(phase, case, expect, actual, ok):
    """ok 为 None 表示“未验证”：要检验的条件这次没有出现。"""
    status = "未验证" if ok is None else ("通过" if ok else "未通过")
    CHECKS.append({"phase": phase, "case": case, "expect": expect, "actual": actual, "pass": None if ok is None else bool(ok),
                   "status": status})
    print(status, phase, case, "|", expect, "|", json.dumps(actual, ensure_ascii=False, default=str)[:300],
          flush=True)


# ---------------- G：保护逻辑 ----------------
class Clock:
    def __init__(self):
        self.now = 1_000_000.0

    def time(self):
        return self.now


def phase_g(out_dir):
    clock = Clock()
    real_time, real_kill = guard_mod.time, guard_mod.os.kill
    guard_mod.time = types.SimpleNamespace(time=clock.time, sleep=lambda s: None)
    killed = []
    guard_mod.os = types.SimpleNamespace(kill=lambda pid, sig: killed.append((pid, sig)), getloadavg=os.getloadavg)
    try:
        def mk(**kw):
            g = guard_mod.Guard(out_dir / "guard-G.jsonl", budget=2 * GiB, **kw)
            g.swap_base = 1 * GiB
            g.swap_hist.clear()
            return g

        def smp(total=1 * GiB, pressure=1, avail=4 * GiB, swap=1 * GiB, read_fail=(), pool_children=()):
            return {"read_fail": list(read_fail), "procs": [(1, 0, total, total)], "total": total, "total_rss": total,
                    "pressure": pressure, "avail": avail, "swap": swap, "load1": 1.0,
                    "pool_children": list(pool_children), "roles": None}

        def run(g, seq, workers=(111,)):
            outs = []
            for dt, s in seq:
                clock.now += dt
                g.sample = lambda pids, s=s: s
                outs.append(g.step(list(workers)))
            return outs

        g = mk()
        check("G", "读数失败（有测量进程）", "stop", run(g, [(1, smp(pressure=None, read_fail=["内存压力"]))])[-1],
              run(mk(), [(1, smp(pressure=None, read_fail=["内存压力"]))])[-1] == "stop")
        check("G", "读数失败（并发已为 0）", "pause，不当作安全",
              run(mk(), [(1, smp(pressure=None, read_fail=["内存压力"]))], workers=())[-1],
              run(mk(), [(1, smp(pressure=None, read_fail=["内存压力"]))], workers=())[-1] == "pause")
        r = run(mk(), [(1, smp(pressure=4))])
        check("G", "内存压力严重", "立即 stop", r, r == ["stop"])
        r = run(mk(), [(1, smp(pressure=2))] * 16)
        check("G", "压力警告持续", "先 pause，暂停满 15 秒仍警告则 stop", r[:1] + r[14:],
              r[:15] == ["pause"] * 15 and r[15] == "stop")
        r = run(mk(), [(1, smp(total=3 * GiB))] * 16)
        check("G", "合计超预算持续", "先 pause，暂停满 15 秒仍超则 stop", r[-2:], r[:-1] == ["pause"] * 15 and r[-1] == "stop")
        r = run(mk(), [(1, smp(avail=int(0.5 * GiB)))])
        check("G", "可用内存低于硬下限", "立即 stop", r, r == ["stop"])
        g = mk()
        r = run(g, [(1, smp(swap=int(2.1 * GiB)))] * 16)
        check("G", "交换区超基线 1 GiB 但暂停后不再涨", "只 pause，不 stop", sorted(set(r)), set(r) == {"pause"})
        r2 = run(g, [(1, smp(swap=int(2.1 * GiB) + 300 * MiB))])
        check("G", "暂停后交换区又涨 300 MiB", "stop", r2, r2 == ["stop"])
        r3 = run(g, [(1, smp(swap=int(2.1 * GiB) + 300 * MiB))] * 70, workers=())
        check("G", "停下后交换区稳定 30 秒且其他条件解除", "重设基线后恢复 run",
              {"最后": r3[-1], "新基线(GiB)": round(g.swap_base / GiB, 3)},
              r3[-1] == "run" and g.swap_base == int(2.1 * GiB) + 300 * MiB)
        g = mk()
        r = run(g, [(1, smp(pressure=2))] + [(1, smp())] * 31)
        check("G", "解除后要连续 30 秒才恢复", "29 秒内仍 pause，满 30 秒 run", [r[1], r[-2], r[-1]],
              set(r[1:-1]) == {"pause"} and r[-1] == "run")
        g = mk(child_limit=3 * GiB)
        run(g, [(1, smp(pool_children=[(4242, int(3.1 * GiB)), (4343, 1 * GiB)]))])
        check("G", "单个子进程超 3 GiB", "只杀超限的那个（SIGKILL）", killed, killed == [(4242, 9)])
        p1 = guard_mod.plan_parallel(int(3.5 * GiB), int(0.75 * GiB), int(0.35 * GiB), 3 * GiB)
        p2 = guard_mod.plan_parallel(3 * GiB, int(0.75 * GiB), int(0.35 * GiB), 3 * GiB)
        p3 = guard_mod.plan_parallel(8 * GiB, int(0.75 * GiB), int(0.35 * GiB), 3 * GiB)
        check("G", "并发数 P", "3.5 GiB→1；3 GiB→0（不强开）；8 GiB→4（封顶）", [p1, p2, p3], [p1, p2, p3] == [1, 0, 4])
    finally:
        guard_mod.time, guard_mod.os = real_time, os
        assert guard_mod.os.kill is real_kill


# ---------------- G2：真实内存读数 ----------------
HOG_CHILD = "import time; b = bytearray(b'\\x01') * (400 << 20); time.sleep(25)"


def phase_g2(out_dir):
    """子进程写满 400 MiB 同一字节；整机保护把本进程当作测量进程，子进程就是它的进程池子进程。"""
    g = guard_mod.Guard(out_dir / "guard-G2.jsonl", budget=64 * GiB, child_limit=64 * GiB)
    p = subprocess.Popen([sys.executable, "-I", "-c", HOG_CHILD])
    try:
        reads = []
        for i in range(16):
            time.sleep(1)
            s = g.sample({os.getpid()})
            mine = [x for x in s["procs"] if x[0] == p.pid]
            reads.append({"秒": i + 1, "footprint_MiB": mine[0][2] >> 20 if mine else None,
                          "rss_MiB": mine[0][3] >> 20 if mine else None,
                          "计入进程池子进程": [fp >> 20 for pid, fp in s["pool_children"] if pid == p.pid],
                          "读数失败": s["read_fail"]})
    finally:
        p.kill()
        p.wait()
    last = reads[-1]
    check("G2", "存续占用按 footprint 计入", "第 16 秒 footprint ≥ 400 MiB，且按进程池子进程计入；没有读数失败；RSS 照记",
          {"第1秒": reads[0], "第16秒": last},
          (last["footprint_MiB"] or 0) >= 400 and last["计入进程池子进程"] == [last["footprint_MiB"]]
          and not any(r["读数失败"] for r in reads))
    dropped = [r for r in reads if r["rss_MiB"] is not None and r["footprint_MiB"] is not None
               and r["rss_MiB"] < 0.9 * r["footprint_MiB"]]
    check("G2", "RSS 下降时 footprint 保持", "RSS 比 footprint 低 10% 以上的读数里 footprint 仍 ≥ 400 MiB；"
          "这次没有这样的读数就记未验证（不为此制造整机内存压力）",
          {"RSS 明显低于 footprint 的读数": dropped[:3], "RSS 最小": min((r["rss_MiB"] for r in reads if r["rss_MiB"]), default=None)},
          all((r["footprint_MiB"] or 0) >= 400 for r in dropped) if dropped else None)
    gone = g.sample({os.getpid()})
    check("G2", "已退出的子进程不算读数失败", "杀掉回收后再采样：不再计入，也没有读数失败",
          {"procs": [x[0] for x in gone["procs"]], "read_fail": gone["read_fail"]},
          p.pid not in [x[0] for x in gone["procs"]] and not gone["read_fail"])
    return reads


# ---------------- 运行与读取 ----------------
def run_tasks(run_dir, tasks, worker_args=(), guard_kw=None, P=1, label="p"):
    t0 = time.time()
    res = supervise.run_phase(run_dir, tasks, P, worker_args=worker_args, guard_kw=guard_kw, label=label)
    res["elapsed"] = round(time.time() - t0, 1)
    run = analyze.load_run(run_dir)
    return res, run, analyze.summarize(run)


def outs(row):
    return [(a.get("outcome"), a.get("gen")) for a in row["attempts"]]


def steps(row, att=0):
    a = row["attempts"][att]
    return (a.get("child") or {}).get("steps") or []


def step_logs(row, kind, att=0):
    return [(s["wall"], [(lg["level"], lg["cat"], lg["exc"]) for lg in s["logs"]]) for s in steps(row, att)
            if s["kind"] == kind]


def step_alarms(row, kind, att=0):
    return [s.get("alarms") for s in steps(row, att) if s["kind"] == kind]


def alarm_near(al, lo, hi):
    return len(al) == 1 and within(al[0], lo, hi)


def no_raw_text(run_dir, needles):
    hits = []
    files = list(Path(run_dir).glob("*.jsonl")) + list((Path(run_dir) / "child_logs").glob("*.jsonl"))
    for f in files + list(Path(run_dir).glob("worker-*.log")):
        if f.name.startswith("tasks-"):
            continue  # 任务清单本身含合成输入
        txt = f.read_text(encoding="utf-8")
        hits += [(f.name, n) for n in needles if n in txt]
    return hits


# ---------------- A：顺序注入 ----------------
A_TASKS = [
    {"id": "S1", "gt": GT, "out": OK},
    {"id": "S1b", "gt": GT, "out": "\\boxed{3}"},
    {"id": "S2", "gt": GT, "out": OK, "inject": {"slow": "pred_parse", "sec": 8}},
    {"id": "S3", "gt": GT, "out": OK, "inject": {"slow": "gold_parse", "sec": 8}},
    {"id": "S4", "gt": GT, "out": "\\boxed{\\frac{4}{2}}", "inject": {"slow": "compare", "sec": 8}},
    {"id": "S5", "gt": GT, "out": OK, "inject": {"slow": "compare", "sec": 8}},
    {"id": "S6", "gt": GT, "out": OK, "inject": {"raise": "pred_parse"}},
    {"id": "S6b", "gt": GT, "out": OK, "inject": {"raise": "gold_parse"}},
    {"id": "S11", "gt": GT, "out": OK, "inject": {"swallow": "pred_parse", "sec": 8}},
    {"id": "S12", "gt": GT, "out": OK, "inject": {"block": "pred_parse", "sec": 8}},
    {"id": "S7", "gt": GT, "out": OK, "inject": {"slow": "outside", "sec": 35}},
    {"id": "S8", "gt": GT, "out": OK, "inject": {"exit": 17, "atts": [1]}},
    {"id": "S9", "gt": GT, "out": OK, "inject": {"exit": 17, "atts": [1, 2]}},
    {"id": "S9b", "gt": GT, "out": OK, "no_warm": True},
    {"id": "S10", "gt": GT, "out": OK, "inject": {"hog_mb": 700, "hold": 20}},
    {"id": "S13", "gt": GT, "out": OK, "inject": {"raise_task_timeout": True}},
    {"id": "S14", "gt": GT, "out": OK},
]


def within(x, lo, hi):
    return x is not None and lo <= x <= hi


def phase_a(run_dir):
    res, run, rows = run_tasks(run_dir, A_TASKS, guard_kw={"child_limit": 768 * MiB}, label="A")
    check("A", "阶段完成", "aborted=None", res.get("aborted"), res.get("aborted") is None)
    R = rows
    sc = {k: (R[k]["result"] or {}).get("score") for k in R if not k.startswith("warm-")}
    r = R["S1"]
    check("A", "S1 正常得分", "1 分；一次尝试；步骤 gold_parse→pred_parse→compare；无库日志；一致",
          {"score": sc["S1"], "outs": outs(r), "kinds": [s["kind"] for s in steps(r)], "problems": r["problems"]},
          sc["S1"] == 1.0 and len(r["attempts"]) == 1 and [s["kind"] for s in steps(r)][:2] == ["gold_parse", "pred_parse"]
          and "compare" in [s["kind"] for s in steps(r)] and not analyze.side_events(r["attempts"][0])
          and not r["problems"] and r["class"] == "1 分")
    r = R["S1b"]
    check("A", "S1b 正常 0 分", "0 分，无任何库事件，归“正常 0”", {"score": sc["S1b"], "class": r["class"]},
          sc["S1b"] == 0.0 and r["class"] == "正常 0")
    r = R["S2"]
    pl = step_logs(r, "pred_parse")
    check("A", "S2 回答侧解析超时", "0 分；pred_parse 约 5 秒、有 WARNING 解析超时、计时信号约第 5 秒到；gold_parse 无日志",
          {"score": sc["S2"], "pred_parse": pl, "alarms": step_alarms(r, "pred_parse"), "gold": step_logs(r, "gold_parse"),
           "class": r["class"], "flags": r["flags"]},
          sc["S2"] == 0.0 and len(pl) == 1 and within(pl[0][0], 4.5, 6.5)
          and pl[0][1] == [("WARNING", "Timeout during parsing", None)] and step_logs(r, "gold_parse")[0][1] == []
          and alarm_near(step_alarms(r, "pred_parse")[0], 4.5, 6.0) and step_alarms(r, "gold_parse")[0] == []
          and r["class"] == "0 分：回答侧解析超时" and not r["problems"] and not r["flags"])
    r = R["S3"]
    gl = step_logs(r, "gold_parse")
    check("A", "S3 标准答案侧解析超时", "0 分；gold_parse 约 5 秒且有 WARNING 解析超时",
          {"score": sc["S3"], "gold_parse": gl, "class": r["class"]},
          sc["S3"] == 0.0 and within(gl[0][0], 4.5, 6.5) and gl[0][1] == [("WARNING", "Timeout during parsing", None)]
          and alarm_near(step_alarms(r, "gold_parse")[0], 4.5, 6.0)
          and r["class"] == "0 分：标准答案侧解析超时" and not r["problems"])
    r = R["S4"]
    cl = [x for x in step_logs(r, "compare") if x[1]]
    ca = [x for x in step_alarms(r, "compare") if x]
    check("A", "S4 比较超时（字符串不同）", "0 分；一次比较约 5 秒且 WARNING 比较超时；归“比较超时”",
          {"score": sc["S4"], "compare_with_logs": cl, "class": r["class"]},
          sc["S4"] == 0.0 and len(cl) == 1 and within(cl[0][0], 4.5, 6.5)
          and cl[0][1] == [("WARNING", "Timeout during comparison", None)] and r["class"] == "0 分：比较超时"
          and len(ca) == 1 and alarm_near(ca[0], 4.5, 6.0) and not r["problems"])
    r = R["S5"]
    cl = [x for x in step_logs(r, "compare") if x[1]]
    check("A", "S5 比较超时但字符串相同", "1 分，同时记到比较超时日志", {"score": sc["S5"], "logs": cl, "class": r["class"]},
          sc["S5"] == 1.0 and len(cl) == 1 and r["class"] == "1 分，有库超时日志" and not r["problems"])
    r = R["S6"]
    check("A", "S6 回答侧库其他异常", "0 分；pred_parse 有 DEBUG 解析出错（ValueError）",
          {"score": sc["S6"], "pred_parse": step_logs(r, "pred_parse"), "class": r["class"]},
          sc["S6"] == 0.0 and step_logs(r, "pred_parse")[0][1] == [("DEBUG", "Error parsing", "ValueError")]
          and r["class"] == "0 分：回答侧解析出错" and not r["problems"])
    r = R["S6b"]
    check("A", "S6b 标准答案侧库其他异常", "0 分；gold_parse 有 DEBUG 解析出错（ValueError）",
          {"score": sc["S6b"], "gold_parse": step_logs(r, "gold_parse"), "class": r["class"]},
          sc["S6b"] == 0.0 and step_logs(r, "gold_parse")[0][1] == [("DEBUG", "Error parsing", "ValueError")]
          and r["class"] == "0 分：标准答案侧解析出错" and not r["problems"])
    r = R["S11"]
    pl, pa = step_logs(r, "pred_parse"), step_alarms(r, "pred_parse")
    check("A", "S11 收到计时信号、库没记超时（模拟吞掉）", "1 分；pred_parse 约 8 秒、计时信号约第 5 秒到、没有超时日志；"
          "标“收到计时信号、库没记超时”，不算观测不完整",
          {"score": sc["S11"], "pred_parse": pl, "alarms": pa, "flags": r["flags"], "class": r["class"],
           "problems": r["problems"]},
          sc["S11"] == 1.0 and within(pl[0][0], 7.5, 9.5) and pl[0][1] == [] and alarm_near(pa[0], 4.5, 6.0)
          and r["flags"] == [f"第 1 次 pred_parse：{analyze.FLAG_NO_LOG}"] and r["class"] == "1 分" and not r["problems"])
    r = R["S12"]
    pl, pa = step_logs(r, "pred_parse"), step_alarms(r, "pred_parse")
    check("A", "S12 长 C 计算拖晚计时信号", "0 分；pred_parse 约 8 秒、WARNING 解析超时、计时信号第 6.5 秒以后才轮到；标“晚到”",
          {"score": sc["S12"], "pred_parse": pl, "alarms": pa, "flags": r["flags"], "class": r["class"],
           "problems": r["problems"]},
          sc["S12"] == 0.0 and within(pl[0][0], 6.5, 16) and pl[0][1] == [("WARNING", "Timeout during parsing", None)]
          and len(pa[0]) == 1 and pa[0][0] >= 6.5 and len(r["flags"]) == 1 and "晚到" in r["flags"][0]
          and r["class"] == "0 分：回答侧解析超时" and not r["problems"])
    r = R["S7"]
    a = r["attempts"][0]
    rs = r["resets"]
    check("A", "S7 外层超时", "0 分；等满约 30 秒；有取消；重置时是当前池并真的杀了运行它的子进程（退出码 -9）；子任务没有结束记录",
          {"score": sc["S7"], "outs": outs(r), "waited": a.get("waited"), "cancel_ok": a.get("cancel_ok"),
           "resets": rs, "child_pid": a["child"]["pid"], "child_exit": a["child"]["exit"],
           "task_end": a["child"]["task_end"], "class": r["class"], "problems": r["problems"]},
          sc["S7"] == 0.0 and outs(r)[0][0] == "outer_timeout" and within(a.get("waited"), 29.5, 31.5)
          and a.get("cancel_ok") is False and len(rs) == 1 and rs[0]["is_current"] and a["child"]["pid"] in rs[0]["kills"]
          and a["child"]["exit"] == -9 and a["child"]["task_end"] is None and r["class"] == "0 分：外层超时"
          and not r["problems"])
    r = R["S8"]
    o = outs(r)
    check("A", "S8 子进程退出一次", "1 分；第 1 次池损坏（该子进程退出码 17），重置后第 2 次在新一代池得分",
          {"score": sc["S8"], "outs": o, "exit1": r["attempts"][0]["child"].get("exit"), "resets": r["resets"],
           "class": r["class"]},
          sc["S8"] == 1.0 and [x[0] for x in o] == ["broken_pool", "score"] and o[1][1] == o[0][1] + 1
          and r["attempts"][0]["child"].get("exit") == 17 and len(r["resets"]) == 1 and r["resets"][0]["is_current"]
          and r["class"] == "1 分（重试后）" and not r["problems"])
    r9 = R["S9"]
    o9 = outs(r9)
    check("A", "S9 子进程两次都退出", "最终抛 BrokenProcessPool；两次池损坏、两代池、退出码都是 17；只在第 1 次后重置",
          {"exc": r9["result"].get("exc"), "outs": o9, "exits": [a["child"].get("exit") for a in r9["attempts"]],
           "resets": len(r9["resets"]), "class": r9["class"]},
          r9["result"].get("exc") == "BrokenProcessPool" and [x[0] for x in o9] == ["broken_pool", "broken_pool"]
          and o9[1][1] == o9[0][1] + 1 and [a["child"].get("exit") for a in r9["attempts"]] == [17, 17]
          and len(r9["resets"]) == 1 and r9["class"] == "最终异常（BrokenProcessPool）" and not r9["problems"])
    r = R["S9b"]
    o = outs(r)
    check("A", "S9b 上一行留下坏池（不预热）", "第 1 次提交即池损坏（同一代坏池，未进子进程），重置后新池得 1 分",
          {"score": sc["S9b"], "outs": o, "submitted": [a.get("submitted") for a in r["attempts"]], "S9_gen2": o9[1][1]},
          sc["S9b"] == 1.0 and [x[0] for x in o] == ["broken_pool", "score"] and o[0][1] == o9[1][1]
          and r["attempts"][0].get("submitted") is False and o[1][1] == o9[1][1] + 1 and not r["problems"])
    r = R["S10"]
    bk = [e for e in run["guard"] if e["ev"] == "budget_kill"]
    mine = {a["child"]["pid"] for a in r["attempts"] if a.get("child")}
    check("A", "S10 单个子进程超本机上限", "整机保护杀掉两次（都是这行的子进程），这行记“本机预算终止（未裁定）”",
          {"result": {k: r["result"].get(k) for k in ("score", "exc")}, "budget_kills": [(e["pid"], e["fp"]) for e in bk],
           "row_pids": sorted(mine), "class": r["class"]},
          len(bk) == 2 and {e["pid"] for e in bk} == mine and r["class"] == "本机预算终止（未裁定）")
    r = R["S13"]
    check("A", "S13 壳层库超时异常", "0 分；结局 lib_timeout_exc；不重置", {"score": sc["S13"], "outs": outs(r),
                                                                    "resets": r["resets"], "class": r["class"]},
          sc["S13"] == 0.0 and [x[0] for x in outs(r)] == ["lib_timeout_exc"] and not r["resets"]
          and r["class"] == "0 分：库超时异常（壳层）" and not r["problems"])
    hooks = [a["child"]["task_start"]["hooks"] for row in R.values() for a in row["attempts"]
             if a.get("child") and a["child"].get("task_start")]
    check("A", "钩子只装一次", "每个子任务开始时：本观测的日志处理器 1 个、安装 1 次、parse/verify/signal 是本层",
          {"tasks": len(hooks), "distinct": sorted({json.dumps(h, sort_keys=True) for h in hooks})},
          hooks and all(h == {"handlers": 1, "installs": 1, "parse_ours": True, "verify_ours": True, "alarm_ours": True}
                        for h in hooks))
    st = [e for e in run["guard"] if e["ev"] == "status" and e.get("roles")]
    bad_sum = [e for e in st if e["total"] != e["roles"]["sup"] + sum(x[1] for x in e["roles"]["workers"])
               + sum(x[2] for x in e["roles"]["pool"]) + sum(x[2] for x in e["roles"]["other"])]
    with_pool = [e for e in st if e["roles"]["workers"] and e["roles"]["pool"]]
    check("A", "状态记录的分角色内存", "每条状态都带分角色 footprint，各角色之和等于合计；有测量进程与进程池子进程的记录",
          {"status": len(st), "sum_mismatch": len(bad_sum), "with_pool": len(with_pool)},
          st and not bad_sum and with_pool)
    bad = {k: v["problems"] for k, v in R.items() if v["problems"]}
    check("A", "全部行观测一致（含预热行）", "没有一行“观测不完整”", bad, not bad)
    hits = no_raw_text(run_dir, ["\\boxed{2}", "\\frac{4}{2}", "The answer is"])
    check("A", "观测日志只存哈希和类型", "观测、子进程、保护、结果记录和测量进程日志里都找不到输入原文", hits, not hits)
    st = analyze.summarize_stream(run_dir, run_dir / "rows-stream.jsonl", batch=2)
    streamed = {r.pop("id"): r for r in analyze._jsonl(run_dir / "rows-stream.jsonl")}
    whole = {k: analyze.compact_row(v) for k, v in R.items()}
    diff = sorted(k for k in set(whole) | set(streamed)
                  if k not in whole or k not in streamed
                  or {x: y for x, y in whole[k].items() if x != "id"} != {x: y for x, y in streamed[k].items() if x != "warm"})
    warm_ok = all(streamed[k]["warm"] == k.startswith("warm-") for k in streamed)
    check("A", "分桶合成与整体合成一致", "每 2 行一桶合成的精简逐行记录与一次合成逐字段相同（含预热行），预热行标对",
          {"rows": st["rows"], "warm_rows": st["warm_rows"], "diff": diff, "warm_ok": warm_ok},
          not diff and warm_ok and st["rows"] + st["warm_rows"] == len(whole))
    negative_controls(run_dir, R)
    pipe = sorted(w[1] + sum(x[2] for x in e["roles"]["pool"] if x[1] == w[0])
                  for e in with_pool for w in e["roles"]["workers"])
    # 中位数：A 段里 S10 那行本身占 700 MiB，取最大值会把 D 段的预算抬高（10-07 第二次自检的教训）
    return {"supervise": res, "stats": analyze.run_stats(run, rows),
            "pipeline_fp_median": pipe[len(pipe) // 2] if pipe else None, "pipeline_fp_max": pipe[-1] if pipe else None}


# ---------------- A-：观测负对照（Codex 10-07 审核第 13.2 节第 1 项）----------------
def _edit(path, fn):
    recs = [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]
    path.write_text("".join(json.dumps(e, ensure_ascii=False) + "\n" for e in fn(recs)), encoding="utf-8")


def _drop(pred):
    return lambda recs: [e for e in recs if not pred(e)]


def _dup_first(pred):
    def f(recs):
        out, done = [], False
        for e in recs:
            out.append(e)
            if not done and pred(e):
                out.append(dict(e))
                done = True
        return out
    return f


def _set(pred, **kw):
    return lambda recs: [dict(e, **kw) if pred(e) else e for e in recs]


def negative_controls(run_dir, R):
    """在 A 段原始记录的副本上逐个删改，核检查器把被改的行标成观测不完整，且不误伤其他行。"""
    neg = Path(run_dir).parent / "A-negative"
    S1, S2, S7 = R["S1"], R["S2"], R["S7"]

    def cfile(m, row):
        return m / "child_logs" / f"child-{row['attempts'][0]['child']['pid']}.jsonl"

    def ofile(m, row):
        return m / f"obs-{row['worker']}.jsonl"

    def rfile(m, row):
        return next(f for f in m.glob("results-*.jsonl") if f'"{row["id"]}"' in f.read_text(encoding="utf-8"))

    def req(r, **kw):
        return lambda e: e.get("req") == r and all(e.get(k) == v for k, v in kw.items())

    s7pid = S7["attempts"][0]["child"]["pid"]
    s7exit = next(e for e in analyze._jsonl(Path(run_dir) / f"obs-{S7['worker']}.jsonl")
                  if e["ev"] == "proc_exit" and e["pid"] == s7pid)

    def swap12(e):
        if e.get("req") == "S1" and e["ev"] in ("step_start", "step_end") and e["step"] in (1, 2):
            return dict(e, kind={"gold_parse": "pred_parse", "pred_parse": "gold_parse"}[e["kind"]])
        return e

    # (名称, 被改的行, 改哪个文件, 怎么改, 是否增删了行)
    cases = [
        ("删掉 S2 回答侧解析的起止与日志", {"S2"}, lambda m: cfile(m, S2), _drop(req("S2", step=2)), True),
        ("只删 S2 回答侧解析的超时 WARNING", {"S2"}, lambda m: cfile(m, S2), _drop(req("S2", ev="log", level="WARNING")), True),
        ("删掉 S1 的 task_start", {"S1"}, lambda m: cfile(m, S1), _drop(req("S1", ev="task_start")), True),
        ("删掉 S1 回答侧解析的 step_end", {"S1"}, lambda m: cfile(m, S1), _drop(req("S1", ev="step_end", kind="pred_parse")), True),
        ("S1 子侧池代次改成 778（父侧不变）", {"S1"}, lambda m: cfile(m, S1), _set(req("S1"), gen=778), False),
        ("S1 子侧一条比较结束记录重复", {"S1"}, lambda m: cfile(m, S1), _dup_first(req("S1", ev="step_end", kind="compare")), True),
        ("S1 子侧进程号换成父侧没登记的", {"S1"}, lambda m: cfile(m, S1), _set(req("S1"), pid=999999), False),
        ("S1 前两步的种类互换（顺序不合包装）", {"S1"}, lambda m: cfile(m, S1), lambda recs: [swap12(e) for e in recs], False),
        ("S1 子侧收到的时限改成 9 秒", {"S1"}, lambda m: cfile(m, S1), _set(req("S1", ev="task_start"), limits={"parse": 9, "compare": 9}), False),
        ("S1 回答侧解析结果改成空（比较还在）", {"S1"}, lambda m: cfile(m, S1), _set(req("S1", ev="step_end", kind="pred_parse"), res=[]), False),
        ("S1 比较结果改成不相等（任务结果仍是 1）", {"S1"}, lambda m: cfile(m, S1), _set(req("S1", ev="step_end", kind="compare"), res=False), False),
        ("删掉 S2 回答侧解析记到的计时信号", {"S2"}, lambda m: cfile(m, S2), _set(req("S2", ev="step_end", step=2), alarms=[]), False),
        ("S1 子侧记的测量进程改名", {"S1"}, lambda m: cfile(m, S1), _set(req("S1"), worker="X9"), False),
        ("父侧 S1 的等待结局重复一条", {"S1"}, lambda m: ofile(m, S1), _dup_first(req("S1", ev="wait_end")), True),
        ("删掉父侧 S1 的 row_end", {"S1"}, lambda m: ofile(m, S1), _drop(req("S1", ev="row_end")), True),
        ("删掉父侧 S7 的重置记录（reset_enter）", {"S7"}, lambda m: ofile(m, S7), _drop(req("S7", ev="reset_enter")), True),
        ("删掉 S7 子进程的退出记录", {"S7"} | ({s7exit["req"]} if s7exit.get("req") else set()), lambda m: ofile(m, S7),
         _drop(lambda e: e["ev"] == "proc_exit" and e["pid"] == s7pid), True),
        ("S1 的结果行重复", {"S1"}, lambda m: rfile(m, S1), _dup_first(lambda e: e["id"] == "S1"), False),
    ]
    results = []
    for k, (name, targets, which, fn, lines) in enumerate(cases, 1):
        m = neg / f"{k:02d}"
        shutil.copytree(run_dir, m, ignore=shutil.ignore_patterns("rows-stream.jsonl"))
        _edit(which(m), fn)
        full = analyze.summarize(analyze.load_run(m))
        run_rl = analyze.load_run(m)
        run_rl["file_problems"] = {"workers": {}, "pids": {}}
        rl = analyze.summarize(run_rl)  # 只看逐行检查（不含文件级序号）
        hit = {t: {"class": full[t]["class"], "row_level": rl[t]["problems"][:3]} for t in sorted(targets)}
        others = sorted(i for i in R if i not in targets
                        and (rl.get(i, {}).get("problems") != R[i]["problems"] or rl.get(i, {}).get("class") != R[i]["class"]))
        file_level = sorted(i for i, r in full.items() if any("缺行或多行" in x for x in r["problems"]))
        ok = (all(full[t]["class"] == "观测不完整（未裁定）" and rl[t]["problems"] for t in targets) and not others
              and (bool(file_level) if lines else not file_level))
        results.append({"case": name, "targets": hit, "others_changed": others, "file_level_rows": len(file_level), "pass": ok})
        if k == 2:  # 不带序号（修订前的记录格式）复核同一份副本：查不出来，S2 会被改判
            legacy = analyze.summarize(analyze.load_run(m, strict=False))["S2"]
            check("A-", "不带序号时只删超时 WARNING 查不出（说明为什么要加序号）",
                  "strict=False 复核：S2 没有问题、类别从“0 分：回答侧解析超时”变成别的；带序号复核：观测不完整",
                  {"legacy_class": legacy["class"], "legacy_problems": legacy["problems"], "legacy_flags": legacy["flags"],
                   "strict_class": full["S2"]["class"]},
                  not legacy["problems"] and legacy["class"] != R["S2"]["class"] and full["S2"]["class"] == "观测不完整（未裁定）")
    for r in results:
        check("A-", r["case"], "被改的行进“观测不完整（未裁定）”且逐行检查报出问题；其他行（只看逐行检查）问题与类别不变；"
              "增删了行的另触发文件级序号检查", r, r["pass"])
    return results


# ---------------- B：并发连带 ----------------
B_TASKS = ([{"id": "T-slow", "gt": GT, "out": OK, "start_at": 0, "inject": {"slow": "outside", "sec": 40, "atts": [1]}}]
           + [{"id": f"T-early{i}", "gt": GT, "out": OK, "start_at": 2} for i in range(1, 4)]
           + [{"id": f"T-peer{i:02d}", "gt": GT, "out": OK, "start_at": 28,
               "inject": {"slow": "outside", "sec": 5, "atts": [1]}} for i in range(1, 14)])


def phase_b(run_dir):
    res, run, R = run_tasks(run_dir, B_TASKS, worker_args=["--threads"], label="B")
    check("B", "阶段完成", "aborted=None", res.get("aborted"), res.get("aborted") is None)
    s = R["T-slow"]
    rs = s["resets"][0] if s["resets"] else {}
    g = outs(s)[0][1]
    check("B", "慢行外层超时并重置当前池", "0 分；重置时是当前池，杀掉这一代池里全部子进程",
          {"score": s["result"]["score"], "outs": outs(s), "reset": rs},
          s["result"]["score"] == 0.0 and outs(s)[0][0] == "outer_timeout" and rs.get("is_current")
          and sorted(rs.get("kills", [])) == sorted(rs.get("pids", [])) and len(rs.get("pids", [])) >= 2)
    early = {k: v for k, v in R.items() if k.startswith("T-early")}
    check("B", "重置前已完成的同行不受损", "3 行都是一次尝试、第一代池、1 分，结束时间早于重置",
          {k: (outs(v), v["result"]["score"], round(rs.get("t", 0) - v["result"]["t_end"], 1)) for k, v in early.items()},
          len(early) == 3 and all(outs(v) == [("score", g)] and v["result"]["score"] == 1.0
                                  and v["result"]["t_end"] < rs.get("t", 0) for v in early.values()))
    peers = {k: v for k, v in R.items() if k.startswith("T-peer")}
    ok_peers = all([x[0] for x in outs(v)] == ["broken_pool", "score"] and outs(v)[0][1] == g and outs(v)[1][1] == g + 1
                   and v["result"]["score"] == 1.0 for v in peers.values())
    check("B", "在途同行池损坏一次后在新池恢复", "13 行：第 1 次在第一代池损坏，第 2 次在第二代池得 1 分",
          {k: (outs(v), v["result"]["score"]) for k, v in sorted(peers.items())[:3]}, len(peers) == 13 and ok_peers)
    noop = all(len(v["resets"]) == 1 and v["resets"][0]["gen"] == g and v["resets"][0]["is_current"] is False
               and not v["resets"][0]["kills"] and not v["kills"] for v in peers.values())
    check("B", "同行的重置因身份检查不杀池", "每行一次重置、对象是第一代池、不是当前池、本行线程没有杀任何进程",
          {k: v["resets"] for k, v in sorted(peers.items())[:2]}, noop)
    killed_running = [v["attempts"][0]["child"]["pid"] for v in peers.values()
                      if v["attempts"][0].get("child") and v["attempts"][0]["child"]["task_end"] is None]
    check("B", "正在跑的同行由慢行的重置杀掉", "这些同行第 1 次的子进程都在慢行杀掉的进程里，退出码 -9",
          {"running_peer_pids": sorted(set(killed_running)), "slow_kills": rs.get("kills"),
           "exits": sorted({v["attempts"][0]["child"]["exit"] for v in peers.values() if v["attempts"][0].get("child")
                            and v["attempts"][0]["child"]["task_end"] is None}, key=str)},
          killed_running and set(killed_running) <= set(rs.get("kills", []))
          and all(v["attempts"][0]["child"]["exit"] == -9 for v in peers.values()
                  if v["attempts"][0].get("child") and v["attempts"][0]["child"]["task_end"] is None))
    bad = {k: v["problems"] for k, v in R.items() if v["problems"]}
    check("B", "全部行观测一致", "没有一行“观测不完整”", bad, not bad)
    return {"supervise": res, "stats": analyze.run_stats(run, R)}


# ---------------- C：开关对照 ----------------
C_TASKS = [
    {"id": "C-ok", "gt": GT, "out": OK},
    {"id": "C-zero", "gt": GT, "out": "\\boxed{3}"},
    {"id": "C-outer", "gt": GT, "out": OK, "timeout": 0},
    {"id": "C-killonce", "gt": GT, "out": OK, "fault": "kill_before"},
    {"id": "C-killall", "gt": GT, "out": OK, "fault": "kill_persistent"},
    {"id": "C-after", "gt": GT, "out": OK, "no_warm": True},
]
C_EXPECT = {"C-ok": (1.0, None), "C-zero": (0.0, None), "C-outer": (0.0, None), "C-killonce": (1.0, None),
            "C-killall": (None, "BrokenProcessPool"), "C-after": (1.0, None)}


def phase_c(base):
    out = {}
    for mode in ("observe", "off"):
        res, run, R = run_tasks(base / f"C-{mode}", C_TASKS, worker_args=["--mode", mode], label=f"C{mode}")
        out[mode] = {"res": res, "rows": R}
        check("C", f"{mode} 阶段完成", "aborted=None", res.get("aborted"), res.get("aborted") is None)
    on, off = out["observe"]["rows"], out["off"]["rows"]
    for t in C_TASKS:
        k = t["id"]
        a, b = on[k]["result"], off[k]["result"]
        pa = (a["pool_after"]["none"], a["pool_after"]["broken"])
        pb = (b["pool_after"]["none"], b["pool_after"]["broken"])
        check("C", f"{k} 开关一致", f"两种模式都是 {C_EXPECT[k]}，池状态（无池, 已损坏）相同",
              {"observe": (a["score"], a["exc"], pa), "off": (b["score"], b["exc"], pb)},
              (a["score"], a["exc"]) == C_EXPECT[k] == (b["score"], b["exc"]) and pa == pb)
    bad = {k: v["problems"] for k, v in on.items() if v["problems"]}
    check("C", "观测开启时全部行一致", "没有一行“观测不完整”", bad, not bad)
    o = outs(on["C-killonce"])
    check("C", "外部杀池一次（观测开启）", "第 1 次提交即池损坏，第 2 次新池得分", o, [x[0] for x in o] == ["broken_pool", "score"])
    o = outs(on["C-killall"])
    check("C", "外部持续杀新池（观测开启）", "两次都池损坏，最终抛出", o, [x[0] for x in o] == ["broken_pool", "broken_pool"])
    return {m: {"supervise": v["res"]} for m, v in out.items()}


# ---------------- R：参照时限 ----------------
R_TASKS = [
    {"id": "R-S4", "gt": GT, "out": "\\boxed{\\frac{4}{2}}", "inject": {"slow": "compare", "sec": 8}},
    {"id": "R-S5", "gt": GT, "out": OK, "inject": {"slow": "compare", "sec": 8}},
    {"id": "R-S2", "gt": GT, "out": OK, "inject": {"slow": "pred_parse", "sec": 8}},
]


def phase_r(run_dir):
    res, run, R = run_tasks(run_dir, R_TASKS, worker_args=["--mode", "reference"], label="R")
    check("R", "阶段完成", "aborted=None", res.get("aborted"), res.get("aborted") is None)
    for k, kind in (("R-S4", "compare"), ("R-S5", "compare"), ("R-S2", "pred_parse")):
        r = R[k]
        a = r["attempts"][0]
        slow = [x for x in step_logs(r, kind) if x[0] > 7]
        check("R", f"{k} 参照时限下得分", "1 分；外层等待时限 300；子进程收到 60/60；慢的那一步约 8 秒且没有超时日志",
              {"score": r["result"]["score"], "timeout": a.get("timeout"), "limits": a["child"]["task_start"]["limits"],
               "slow_steps": slow},
              r["result"]["score"] == 1.0 and a.get("timeout") == 300.0
              and a["child"]["task_start"]["limits"] == {"parse": 60, "compare": 60} and len(slow) >= 1
              and all(within(w, 7.5, 9.5) and not logs for w, logs in slow) and not r["problems"])
    return {"supervise": res}


# ---------------- D：整项停止 ----------------
D_TASKS = [{"id": "D-n1", "gt": GT, "out": OK},
           {"id": "D-hog", "gt": GT, "out": OK, "inject": {"hog_mb": 1000, "hold": 25}},
           {"id": "D-n2", "gt": GT, "out": OK},
           {"id": "D-n3", "gt": GT, "out": OK}]


def phase_d(run_dir, pipeline_fp=None):
    """预算 = 调度（本进程）+ A 段实测的流水线 footprint 中位数 + 0.5 GiB：正常行不超，占 1000 MiB 的那行一定超。"""
    own = mem.usage()[0]
    head = (pipeline_fp or int(0.8 * GiB)) + int(0.5 * GiB)
    gk = {"budget": own + head, "child_limit": 3 * GiB, "hard_after": 5, "resume_after": 5}
    res, run, R = run_tasks(run_dir, D_TASKS, guard_kw=gk, label="D")
    res["budget"] = {"own_fp": own, "pipeline_fp_median_from_A": pipeline_fp, "budget": gk["budget"]}
    g = run["guard"]
    hs = [e for e in g if e["ev"] == "hard_stop"]
    check("D", "阶段完成且整项停止两次", "aborted=None；两次 hard_stop，原因是暂停后仍合计超预算",
          {"aborted": res.get("aborted"), "stops": [e["reasons"] for e in hs]},
          res.get("aborted") is None and len(hs) == 2 and all("暂停后仍合计超预算" in e["reasons"] for e in hs))
    hist = res.get("history", [])
    check("D", "停止后进程组清空", "每次启动结束后组里没有残留进程；前两次是整项停止，第三次正常结束",
          hist, len(hist) == 3 and [h["stopped"] for h in hist] == [True, True, False]
          and all(h["orphans_killed"] == 0 for h in hist))
    # 停止后到下一次启动之间并发为 0
    zero = True
    for e in hs:
        nxt = [x for x in g if x["ev"] == "launch" and x["t"] > e["t"]]
        between = [x for x in g if x["ev"] == "status" and e["t"] < x["t"] < (nxt[0]["t"] if nxt else 1e18)]
        zero &= bool(between) and all(x["workers"] == 0 for x in between)
    check("D", "停止后并发为 0，等条件解除才续跑", "两次停止与下一次启动之间的状态记录里测量进程数都是 0", zero, zero)
    sup = [json.loads(x) for x in (Path(run_dir) / "results-supervisor.jsonl").read_text().splitlines() if x.strip()] \
        if (Path(run_dir) / "results-supervisor.jsonl").exists() else []
    check("D", "同一行中断两次记未裁定", "D-hog 记未裁定，两次中断原因都是整项停止（本机预算干预）",
          sup, len(sup) == 1 and sup[0]["id"] == "D-hog"
          and [i["why"] for i in sup[0]["interrupts"]] == ["整项停止（本机预算干预）"] * 2)
    lines = []
    for f in Path(run_dir).glob("results-D*.jsonl"):
        lines += [json.loads(x)["id"] for x in f.read_text().splitlines() if x.strip()]
    check("D", "已完成的行不重跑、其余行续跑完成", "D-n1、D-n2、D-n3 各恰好一条结果，都是 1 分",
          {k: lines.count(k) for k in ("D-n1", "D-n2", "D-n3")},
          all(lines.count(k) == 1 for k in ("D-n1", "D-n2", "D-n3"))
          and all(R[k]["result"]["score"] == 1.0 for k in ("D-n1", "D-n2", "D-n3")))
    left = []
    for p in psutil.process_iter(["pid"]):
        try:
            if os.getpgid(p.pid) in {pid for e in g if e["ev"] == "launch" for pid in e["pids"]}:
                left.append(p.pid)
        except (psutil.Error, OSError):
            pass
    check("D", "结束后没有残留进程", "各测量进程组里都没有进程", left, not left)
    return {"supervise": res}


# ---------------- E：中断后重跑与调度不在 ----------------
E_TASKS = [
    {"id": "E-before", "gt": GT, "out": OK},
    {"id": "E-once", "gt": GT, "out": OK, "inject": {"slow": "pred_parse", "sec": 3}},
    {"id": "E-after", "gt": GT, "out": OK},
]


def phase_e(base):
    # E1：E-once 开始 1 秒后（子进程正在 pred_parse 里慢）杀掉整个测量进程组；调度重启后这行重跑完成
    d1 = base / "E1"
    killed = []

    def killer():
        t_end = time.time() + 120
        while time.time() < t_end and not killed:
            if any('"E-once"' in f.read_text(encoding="utf-8") for f in d1.glob("progress-*.jsonl")):
                time.sleep(1.0)
                try:
                    launches = [e for f in d1.glob("guard-*.jsonl") for e in analyze._jsonl(f) if e["ev"] == "launch"]
                except json.JSONDecodeError:  # 保护日志正写到一半
                    time.sleep(0.1)
                    continue
                for pid in launches[-1]["pids"]:
                    try:
                        os.killpg(pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                killed.append(launches[-1]["workers"])
                return
            time.sleep(0.2)

    th = threading.Thread(target=killer, daemon=True)
    th.start()
    res, run, R = run_tasks(d1, E_TASKS, worker_args=["--mode", "observe"], label="E")
    th.join()
    check("E", "E1 阶段完成", "aborted=None；第 1 次启动被杀（-9），第 2 次正常结束",
          [(h["launch"], h["codes"]) for h in res.get("history", [])],
          res.get("aborted") is None and [h["codes"] for h in res["history"]] == [[-9], [0]])
    ints = run["interrupts"].get("E-once") or []
    check("E", "E1 中断记一次", "E-once 中断一次，原因“测量进程异常退出”；其他行没有中断",
          {"E-once": ints, "others": sorted(k for k in run["interrupts"] if k != "E-once")},
          [x["why"] for x in ints] == ["测量进程异常退出"] and set(run["interrupts"]) == {"E-once"})
    spawned = {}
    for e in run["parent"]:
        if e["ev"] == "proc_new":
            spawned.setdefault(e["worker"], set()).add(e["pid"])
    r = R["E-once"]
    fw = r["result"]["worker"]
    cp = [(a.get("child") or {}).get("pid") for a in r["attempts"]]
    first_w = killed[0][0] if killed else None
    check("E", "E1 重跑后只取产出结果那次的记录", "1 分、一次尝试、观测一致；测量进程是第 2 次启动的，子进程也是它起的",
          {"class": r["class"], "worker": fw, "killed_workers": killed, "child_pids": cp,
           "child_of_final": [p in spawned.get(fw, set()) for p in cp], "problems": r["problems"]},
          r["class"] == "1 分" and len(r["attempts"]) == 1 and not r["problems"] and fw != first_w
          and all(p in spawned.get(fw, set()) for p in cp))
    neg = analyze.summarize(dict(run, results={k: dict(v, worker=None) for k, v in run["results"].items()}))["E-once"]
    ncp = [(a.get("child") or {}).get("pid") for a in neg["attempts"]]
    check("E", "E1 负对照：不按测量进程筛", "合并两次启动的记录时，取到的子进程是被杀那次启动起的",
          {"child_pids": ncp, "of_killed_launch": [p in spawned.get(first_w, set()) for p in ncp]},
          bool(ncp) and any(p in spawned.get(first_w, set()) for p in ncp))
    bad = {k: v["problems"] for k, v in R.items() if v["problems"]}
    check("E", "E1 全部行观测一致", "没有一行“观测不完整”", bad, not bad)

    # E2：调度（这里是一个中间进程）起了测量进程就退出；测量进程发现父进程不是它，不做新行、收尾退出
    d2 = base / "E2"
    (d2 / "child_logs").mkdir(parents=True)
    tf = d2 / "tasks.jsonl"
    tf.write_text("".join(json.dumps({"id": f"E-o{i}", "gt": GT, "out": OK}) + "\n" for i in range(3)), encoding="utf-8")
    log = d2 / "worker-E2w0.log"
    starter = ("import os, subprocess, sys\n"
               "p = subprocess.Popen(sys.argv[2:] + ['--parent-pid', str(os.getpid())], stdout=open(sys.argv[1], 'w'),"
               " stderr=subprocess.STDOUT, start_new_session=True, cwd=os.path.dirname(sys.argv[1]))\n"
               "print(p.pid)\n")
    out = subprocess.run([sys.executable, "-I", "-c", starter, str(log), sys.executable, "-I", str(supervise.WORKER),
                          "--run-dir", str(d2), "--tasks", str(tf), "--worker", "E2w0", "--mode", "observe"],
                         capture_output=True, text=True, check=True)
    wpid = int(out.stdout.strip())
    t0 = time.time()
    while time.time() - t0 < 60 and psutil.pid_exists(wpid):
        try:
            if psutil.Process(wpid).status() == psutil.STATUS_ZOMBIE:
                break
        except psutil.NoSuchProcess:
            break
        time.sleep(0.2)
    gone_s = round(time.time() - t0, 1)
    left = [p.pid for p in psutil.process_iter(["pid"]) if _pgid(p.pid) == wpid]
    res_rows = sum(len(analyze._jsonl(f)) for f in d2.glob("results-*.jsonl"))
    warm = analyze._jsonl(d2 / "warm-E2w0.jsonl") if (d2 / "warm-E2w0.jsonl").exists() else []
    text = log.read_text(encoding="utf-8") if log.exists() else ""
    check("E", "E2 调度不在就停", "测量进程 60 秒内退出、一行没做、记了收尾，日志说明原因；进程组里没有残留",
          {"exited_after_s": gone_s, "results": res_rows, "warm_events": [w.get("ev") for w in warm], "left": left,
           "log_says": "不在了" in text},
          gone_s < 60 and res_rows == 0 and [w.get("ev") for w in warm] == ["worker_start", "worker_end"]
          and not left and "不在了" in text)
    return {"E1": {"supervise": res, "killed": killed}, "E2": {"exited_after_s": gone_s}}


def _pgid(pid):
    try:
        return os.getpgid(pid)
    except (ProcessLookupError, PermissionError):
        return None


def main():
    stamp = time.strftime("%Y%m%d-%H%M%S")
    base = Path.home() / ".local/share/rewardfail/stage2/runs" / f"selftest-{stamp}"
    base.mkdir(parents=True)
    only = set(sys.argv[1:]) or {"G", "A", "B", "C", "R", "D", "E"}
    t0 = time.time()
    info = {}
    if "G" in only:
        (base / "G").mkdir()
        phase_g(base / "G")
        info["G2"] = phase_g2(base / "G")
    if "A" in only:
        info["A"] = phase_a(base / "A")
    if "B" in only:
        info["B"] = phase_b(base / "B")
    if "C" in only:
        info["C"] = phase_c(base)
    if "R" in only:
        info["R"] = phase_r(base / "R")
    if "D" in only:
        info["D"] = phase_d(base / "D", (info.get("A") or {}).get("pipeline_fp_median"))
    if "E" in only:
        info["E"] = phase_e(base / "E")
    n_fail = sum(c["pass"] is False for c in CHECKS)
    n_unverified = sum(c["pass"] is None for c in CHECKS)
    report = {"what": "第二阶段观测层与整机保护自检（10-07 按 Codex 审核第 13 节修订后）", "run_dir": str(base),
              "phases": sorted(only), "env": env(), "seconds": round(time.time() - t0, 1), "n_checks": len(CHECKS),
              "n_pass": len(CHECKS) - n_fail - n_unverified, "n_fail": n_fail, "n_unverified": n_unverified,
              "checks": CHECKS, "phase_info": info}
    out = ROOT / "results/s2_rev2/selftest/report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    (base / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    print(f"共 {len(CHECKS)} 项：通过 {report['n_pass']}，未通过 {n_fail}，未验证 {n_unverified}；"
          f"用时 {report['seconds']} 秒；原始记录 {base}")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
