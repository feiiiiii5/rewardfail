"""第二阶段测量进程：逐行调用 #8015 的 compute_score，逐行落盘（方案第 4–6 节）。

由 rewardfail/s2/supervise.py 启动（python -I），每个测量进程单独一个进程组。
- --mode observe：装观测层（父侧 obs、子侧 child）；off：不装，做开关对照；
  reference：观测开启，参照判分（外层 300 秒，库的解析、比较各 60 秒，经 ctx 传给子进程）。
- --limits N：只配 observe，时限敏感度跟进用：库的解析、比较时限都改成 N 秒，外层仍 30 秒（方案第 4 节）。
- 调度进程不在了（--parent-pid 给的进程不再是父进程）就不做新行、收尾退出：没有整机保护时不接着测。
- 每行先在 progress 写一行，判完在 results 写一行；已有结果的行跳过（检查点续跑）。
- 预热：当前没有池或池已损坏时，先用一道显然的题把池建好；主测量每行都在预热过的池上单独请求。
  任务带 no_warm 时不预热（只在自检里用，看上一行留下的坏池怎样连带下一行）。
- 看门狗：一行（含预热）超过上限还没返回，打印各线程栈并退出，由调度记为测量进程中断、重跑一次。
- 暂停：调度在运行目录放 PAUSE 时，做完当前行后等它消失再接着做。
- 自检用的外部故障（开关两种模式都一样施加，不经观测层）：kill_before 先杀掉预热好的池的子进程，
  等池被标为损坏再调用；kill_persistent 另外起一个线程，把之后新建的池的子进程一出现就杀掉。
"""
import argparse
import faulthandler
import json
import os
import resource
import signal
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

GT_WARM, OUT_WARM = "1", "\\boxed{1}"


class Out:
    def __init__(self, path):
        self.fh, self.lock = open(path, "a", encoding="utf-8"), threading.Lock()

    def write(self, rec):
        line = json.dumps(rec, ensure_ascii=False) + "\n"
        with self.lock:
            self.fh.write(line)
            self.fh.flush()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--tasks", required=True)
    ap.add_argument("--worker", required=True)
    ap.add_argument("--mode", choices=["observe", "off", "reference"], default="observe")
    ap.add_argument("--threads", action="store_true", help="并发情景：每行一个线程，按 start_at 同时发")
    ap.add_argument("--row-limit", type=float, default=None)
    ap.add_argument("--limits", type=int, default=None, help="时限敏感度跟进：库内两个时限都改成 N 秒（外层仍 30 秒）")
    ap.add_argument("--parent-pid", type=int, default=None, help="调度进程；它不在了就停")
    a = ap.parse_args()
    run = Path(a.run_dir)
    tasks = [json.loads(x) for x in Path(a.tasks).read_text(encoding="utf-8").splitlines() if x.strip()]
    done = set()
    for f in run.glob("results-*.jsonl"):
        done |= {json.loads(x)["id"] for x in f.read_text(encoding="utf-8").splitlines() if x.strip()}
    tasks = [t for t in tasks if t["id"] not in done]
    ref = a.mode == "reference"
    if a.limits is not None and a.mode != "observe":
        ap.error("--limits 只配 --mode observe")
    parent0 = a.parent_pid or os.getppid()
    default_timeout = 300.0 if ref else 30.0
    row_limit = a.row_limit or (2 * default_timeout + 90)
    progress, results = Out(run / f"progress-{a.worker}.jsonl"), Out(run / f"results-{a.worker}.jsonl")
    warms = Out(run / f"warm-{a.worker}.jsonl")
    faulthandler.enable()

    t_imp = time.time()
    from verl.utils.reward_score import math_verify as W

    from rewardfail.s2 import mem
    obs = None
    if a.mode != "off":
        from rewardfail.s2.obs import Observer
        obs = Observer(W, run / f"obs-{a.worker}.jsonl", run / "child_logs", {"mode": a.mode, "worker": a.worker})
        obs.install()
    extra = ({"limits": {"parse": 60, "compare": 60}} if ref
             else {"limits": {"parse": a.limits, "compare": a.limits}} if a.limits else {})
    reader = None
    if any("shard" in t for t in tasks):
        from rewardfail.s2.data import Reader
        reader = Reader()
    warms.write({"id": f"start-{a.worker}", "ev": "worker_start", "pid": os.getpid(), "import_s": round(time.time() - t_imp, 3),
                 "mode": a.mode, "n_tasks": len(tasks)})

    def pool_state():
        p = W._pool
        return {"none": p is None, "broken": bool(p is not None and getattr(p, "_broken", False)),
                "gen": getattr(p, "_rf_gen", None), "n_procs": len(p._processes or {}) if p is not None else 0}

    def rec_event(ev, **kw):
        if obs:
            obs.rec(ev, **kw)

    n_warm = [0]

    def warm():
        for k in range(3):
            n_warm[0] += 1
            rid = f"warm-{a.worker}-{n_warm[0]}"
            faulthandler.dump_traceback_later(120, exit=True)
            if obs:
                obs.begin(rid)
            t0 = time.time()
            try:
                s, err = W.compute_score(OUT_WARM, GT_WARM), None
            except BaseException as e:
                s, err = None, type(e).__name__
            if obs:
                obs.end()
            faulthandler.cancel_dump_traceback_later()
            warms.write({"id": rid, "score": s, "exc": err, "wall": round(time.time() - t0, 4), "pool": pool_state()})
            if s == 1.0:
                return
        print("预热三次都没得到 1 分，退出", flush=True)
        sys.exit(4)

    def need_warm():
        p = W._pool
        return p is None or getattr(p, "_broken", False)

    def kill_procs(pool, why):
        pids = list((pool._processes or {}).keys()) if pool is not None else []
        rec_event("fault_kill", why=why, pids=pids, gen=getattr(pool, "_rf_gen", None))
        for pid in pids:
            try:
                os.kill(pid, signal.SIGKILL)  # 直接发信号，不经被观测的 Process.kill
            except ProcessLookupError:
                pass
        return pids

    def load(t):
        if "shard" in t:
            ans, gens = reader.get(t["shard"], t["row"])
            return ans, gens[t["idx"]]
        return t["gt"], t["out"]

    def run_one(t, gt, out):
        fault, killer, stop_killer = t.get("fault"), None, threading.Event()
        if fault in ("kill_before", "kill_persistent"):
            old = W._pool
            kill_procs(old, "外部故障：调用前杀掉预热好的池")
            t0 = time.time()
            while old is not None and not getattr(old, "_broken", False) and time.time() - t0 < 10:
                time.sleep(0.01)
            if fault == "kill_persistent":
                def kill_new():
                    seen = set()
                    while not stop_killer.is_set():
                        p = W._pool
                        if p is not None and p is not old:
                            for pid in list((p._processes or {}).keys()):
                                if pid not in seen:
                                    seen.add(pid)
                                    kill_procs(p, "外部故障：新池子进程一出现就杀")
                        time.sleep(0.005)
                killer = threading.Thread(target=kill_new, name="fault-killer", daemon=True)
                killer.start()
        if obs:
            obs.begin(t["id"], inject=t.get("inject"), ctx_extra=extra)
        before = pool_state()
        t0, c0 = time.time(), time.process_time()
        try:
            s, err = W.compute_score(out, gt, timeout=t.get("timeout", default_timeout)), None
        except BaseException as e:
            s, err = None, type(e).__name__
        wall, cpu = time.time() - t0, time.process_time() - c0
        try:
            pfp, pfp_max, _ = mem.usage()
        except Exception:
            pfp = pfp_max = None
        atts = getattr(obs.tl, "att", None) if obs else None
        if obs:
            obs.end()
        if killer:
            stop_killer.set()
            killer.join()
        return {"id": t["id"], "worker": a.worker, "mode": a.mode, "limits": a.limits, "score": s, "exc": err,
                "wall": round(wall, 4),
                "parent_cpu": round(cpu, 4), "attempts": atts, "pool_before": before, "pool_after": pool_state(),
                "parent_fp": pfp, "parent_fp_max": pfp_max,
                "parent_maxrss": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, "t_end": round(time.time(), 3)}

    orphaned = False
    if a.threads:
        warm()
        base = time.time() + 1.0
        faulthandler.dump_traceback_later(max(t.get("start_at", 0) for t in tasks) + row_limit, exit=True)

        def one(t):
            d = base + t.get("start_at", 0) - time.time()
            if d > 0:
                time.sleep(d)
            gt, out = load(t)
            progress.write({"id": t["id"], "t": round(time.time(), 3)})
            results.write(run_one(t, gt, out))

        ths = [threading.Thread(target=one, args=(t,), name=f"row-{t['id']}") for t in tasks]
        for th in ths:
            th.start()
        for th in ths:
            th.join()
        faulthandler.cancel_dump_traceback_later()
    else:
        for t in tasks:
            while (run / "PAUSE").exists() and os.getppid() == parent0:
                time.sleep(1)
            if os.getppid() != parent0:
                orphaned = True
                print(f"调度进程 {parent0} 不在了，不做新行，收尾退出", flush=True)
                break
            if not t.get("no_warm") and need_warm():
                warm()
            gt, out = load(t)
            progress.write({"id": t["id"], "t": round(time.time(), 3)})
            faulthandler.dump_traceback_later(row_limit, exit=True)
            r = run_one(t, gt, out)
            faulthandler.cancel_dump_traceback_later()
            results.write(r)

    if W._pool is not None:
        W._pool.shutdown(wait=True, cancel_futures=True)
    if obs:
        obs.poll_exits(reap=True, wait=5.0)  # 被杀的子进程等系统回收后再记退出码（最多 5 秒）
        obs.rec("worker_end", procs={str(k): v["code"] for k, v in obs.procs.items()})
    warms.write({"id": f"end-{a.worker}", "ev": "worker_end"})
    if orphaned:
        sys.exit(5)


if __name__ == "__main__":
    main()
