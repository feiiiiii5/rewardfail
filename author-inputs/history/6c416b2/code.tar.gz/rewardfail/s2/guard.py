"""整机保护（方案第 6 节，按 Codex 10-06 复核第 11.2 节）：每秒查一次。8 GiB 是监控预算，不是硬隔离。

- 内存一律按 macOS 的 footprint 计（rewardfail/s2/mem.py）：被压缩、被换出的页也算。10-07 第一次完整自检查出
  按常驻内存（RSS）计会低估：内存被压缩后 RSS 掉下去，占内存的那一行没能触发整项停止。RSS 只照记。
- 计入预算的是本测量的全部进程：调度进程、各测量进程、它们的进程池子进程（含旧池还没退出的）及其他后代。
  测量进程异常退出后留下的孤儿进程由调度按进程组清掉（supervise.py）。
- 预算 = min(8 GiB, max(1 GiB, 开跑时系统可用内存 − 1.5 GiB))；并发数按 plan_parallel 算，算出来小于 1 就不开。
  1 GiB 是预算下限：可用内存低于 2.5 GiB 时预算仍记 1 GiB，但主测量的单子进程上限是 3 GiB，这时 P 必为 0，不会因此
  开跑；可用内存低于 1.5 GiB 本身就是暂停条件。准备与分析环节（stepguard.py）用同一个公式。
- 暂停派新行：合计常驻内存超预算、系统内存压力到“警告”、交换区比基线多用 1 GiB 以上、或系统可用内存低于 1.5 GiB。
  正在判的那一行照常跑完；条件连续 30 秒都解除才恢复。
- 单个进程池子进程超过单进程上限：杀掉它，记“本机预算终止”，那一行记未裁定。
- 整项停止（并发降到 0，杀掉本测量的全部测量进程组，已完成的行都已逐行落盘）：
  内存压力“严重”、可用内存低于 0.75 GiB、监控读数失败，或暂停派发 15 秒后上述暂停条件仍在
  （交换区一项看暂停后是否还在涨，涨超 256 MiB 才算）。
- 交换区不会自己缩回去：停下或暂停后交换区 30 秒内不再增长、其他条件也都解除，就以当时的用量作新基线再恢复，记一笔。
- 状态记录（默认每 10 秒，条件变化时立刻记）带分角色的 footprint：调度、各测量进程、各进程池子进程、其他后代，
  供试跑按实测定并发数。
"""
import collections
import ctypes
import ctypes.util
import json
import os
import signal
import time

import psutil

from rewardfail.s2 import mem

GiB = 1 << 30
MiB = 1 << 20
_libc = ctypes.CDLL(ctypes.util.find_library("c"))
SWAP_REASON = "交换区增长超 1 GiB"


def sysctl_int(name):
    v, sz = ctypes.c_int(0), ctypes.c_size_t(ctypes.sizeof(ctypes.c_int))
    return v.value if _libc.sysctlbyname(name.encode(), ctypes.byref(v), ctypes.byref(sz), None, 0) == 0 else None


def pressure():
    """macOS 系统内存压力：1 正常，2 警告，4 严重；读不到返回 None。"""
    return sysctl_int("kern.memorystatus_vm_pressure_level")


def plan_parallel(budget, pipeline, child_base, child_limit, cap=4):
    """P = min(4, ⌊(预算 − 一个子进程最多还能涨的量) ÷ 每条流水线常驻内存⌋)；小于 1 时返回 0，不强开一条。"""
    head = max(0, child_limit - child_base)
    return max(0, min(cap, int((budget - head) // pipeline)))


class Guard:
    def __init__(self, log_path, *, budget=None, child_limit=3 * GiB, swap_growth=1 * GiB, avail_floor=1.5 * GiB,
                 avail_hard=0.75 * GiB, resume_after=30, hard_after=15, swap_regrow=256 * MiB, swap_stable=64 * MiB,
                 status_every=10):
        vm = psutil.virtual_memory()
        self.avail_start, self.swap_start = vm.available, psutil.swap_memory().used
        self.budget = budget or min(8 * GiB, max(1 * GiB, self.avail_start - int(1.5 * GiB)))
        self.child_limit, self.swap_growth, self.swap_regrow, self.swap_stable = (
            child_limit, swap_growth, swap_regrow, swap_stable)
        self.avail_floor, self.avail_hard = avail_floor, avail_hard
        self.resume_after, self.hard_after, self.status_every = resume_after, hard_after, status_every
        self.fh = open(log_path, "a", encoding="utf-8")
        self.swap_base = self.swap_start
        self.paused, self.pause_since, self.pause_swap, self.clear_since = False, None, None, None
        self.swap_hist = collections.deque()
        self.last_status, self.last_reasons = 0.0, None
        self.peak_total, self.min_avail, self.max_pressure = 0, self.avail_start, pressure() or 0
        self.kills, self.stops = 0, 0
        self.log("guard_start", budget=self.budget, child_limit=child_limit, avail_start=self.avail_start,
                 swap_start=self.swap_start, pressure=self.max_pressure, metric="phys_footprint")

    def log(self, ev, **kw):
        kw.update(ev=ev, t=round(time.time(), 3))
        self.fh.write(json.dumps(kw, ensure_ascii=False) + "\n")
        self.fh.flush()

    def sample(self, worker_pids):
        s = {"read_fail": [], "procs": [], "pressure": None, "avail": None, "swap": None, "load1": None}
        try:
            me = psutil.Process()
            tree = [me] + me.children(recursive=True)
        except Exception as e:  # 读不到自己的进程树：不能当作安全
            s["read_fail"].append(f"进程树:{type(e).__name__}")
            tree = []
        for p in tree:
            try:
                ppid = p.ppid()
                fp, _, rss = mem.usage(p.pid)
                s["procs"].append((p.pid, ppid, fp, rss))
            except (psutil.NoSuchProcess, psutil.ZombieProcess, mem.Gone):
                pass  # 刚好退出，不占内存
            except Exception as e:
                s["read_fail"].append(f"进程{p.pid}:{type(e).__name__}")
        s["total"] = sum(fp for _, _, fp, _ in s["procs"])
        s["total_rss"] = sum(rss for _, _, _, rss in s["procs"])
        s["pool_children"] = [(pid, fp) for pid, ppid, fp, _ in s["procs"] if ppid in worker_pids]
        me_pid = os.getpid()
        s["roles"] = {"sup": sum(fp for pid, _, fp, _ in s["procs"] if pid == me_pid),
                      "workers": [[pid, fp] for pid, _, fp, _ in s["procs"] if pid in worker_pids],
                      "pool": [[pid, ppid, fp] for pid, ppid, fp, _ in s["procs"] if ppid in worker_pids],
                      "other": [[pid, ppid, fp] for pid, ppid, fp, _ in s["procs"]
                                if pid != me_pid and pid not in worker_pids and ppid not in worker_pids]}
        s["pressure"] = pressure()
        if s["pressure"] is None:
            s["read_fail"].append("内存压力")
        try:
            s["avail"] = psutil.virtual_memory().available
        except Exception as e:
            s["read_fail"].append(f"可用内存:{type(e).__name__}")
        try:
            s["swap"] = psutil.swap_memory().used
        except Exception as e:
            s["read_fail"].append(f"交换区:{type(e).__name__}")
        try:
            s["load1"] = round(os.getloadavg()[0], 2)
        except OSError:
            pass
        return s

    def _swap_stable(self, now):
        """最近 resume_after 秒里交换区增长不超过 swap_stable（样本要覆盖满这段时间）。"""
        if not self.swap_hist or now - self.swap_hist[0][0] < self.resume_after - 1.5:
            return False
        vals = [v for _, v in self.swap_hist]
        return max(vals) - vals[0] <= self.swap_stable

    def step(self, worker_pids):
        """返回 "run"、"pause" 或 "stop"。单个子进程超限时自己动手杀并记录。worker_pids 为空表示并发已是 0。"""
        s = self.sample(set(worker_pids))
        now = time.time()
        self.peak_total = max(self.peak_total, s["total"])
        if s["avail"] is not None:
            self.min_avail = min(self.min_avail, s["avail"])
        if s["pressure"] is not None:
            self.max_pressure = max(self.max_pressure, s["pressure"])
        if s["swap"] is not None:
            self.swap_hist.append((now, s["swap"]))
            while now - self.swap_hist[0][0] > self.resume_after:
                self.swap_hist.popleft()
        for pid, fp in s["pool_children"]:
            if fp > self.child_limit:
                try:
                    os.kill(pid, signal.SIGKILL)
                    self.kills += 1
                    self.log("budget_kill", pid=pid, fp=fp, limit=self.child_limit)
                except ProcessLookupError:
                    pass
        reasons = []
        if s["total"] > self.budget:
            reasons.append("合计超预算")
        if s["pressure"] is not None and s["pressure"] >= 2:
            reasons.append("内存压力警告")
        if s["swap"] is not None and s["swap"] - self.swap_base > self.swap_growth:
            reasons.append(SWAP_REASON)
        if s["avail"] is not None and s["avail"] < self.avail_floor:
            reasons.append("可用内存低于下限")
        rebase = False
        if (SWAP_REASON in reasons and self.paused and self.pause_since and now - self.pause_since >= self.resume_after
                and self._swap_stable(now)):
            reasons.remove(SWAP_REASON)  # 停住后交换区不再涨：以当前用量作新基线
            rebase = True
        hard = []
        if s["read_fail"]:
            hard.append("监控读数失败：" + "、".join(s["read_fail"][:3]))
        if s["pressure"] is not None and s["pressure"] >= 4:
            hard.append("内存压力严重")
        if s["avail"] is not None and s["avail"] < self.avail_hard:
            hard.append("可用内存低于硬下限")
        if worker_pids and self.paused and self.pause_since and now - self.pause_since >= self.hard_after:
            persist = [r for r in reasons if r != SWAP_REASON]
            if persist:
                hard.append("暂停后仍" + "、".join(persist))
            if s["swap"] is not None and self.pause_swap is not None and s["swap"] - self.pause_swap > self.swap_regrow:
                hard.append("暂停后交换区仍在增长")
        key = (tuple(reasons), tuple(hard))
        if now - self.last_status >= self.status_every or key != self.last_reasons:
            self.last_status, self.last_reasons = now, key
            self.log("status", total=s["total"], total_rss=s.get("total_rss"), n_procs=len(s["procs"]),
                     avail=s["avail"], swap=s["swap"], pressure=s["pressure"], load1=s["load1"],
                     workers=len(worker_pids), paused=self.paused, reasons=reasons + hard, roles=s.get("roles"))
        if hard or reasons:
            if not self.paused:
                self.log("pause", reasons=reasons + hard)
                self.paused, self.pause_since, self.pause_swap = True, now, s["swap"]
            self.clear_since = None
            if hard and worker_pids:
                self.stops += 1
                self.log("hard_stop", reasons=hard, total=s["total"], avail=s["avail"], pressure=s["pressure"])
                return "stop"
            return "pause"
        if self.paused:
            self.clear_since = self.clear_since or now
            if now - self.clear_since < self.resume_after:
                return "pause"
            if rebase:
                self.log("swap_rebase", old=self.swap_base, new=s["swap"])
                self.swap_base = s["swap"]
            self.log("resume", paused_for=round(now - (self.pause_since or now), 1))
            self.paused, self.pause_since, self.pause_swap, self.clear_since = False, None, None, None
        return "run"

    def wait_clear(self, poll=1.0):
        """并发为 0 时等保护条件连续解除（step 自己记日志）。"""
        while self.step([]) != "run":
            time.sleep(poll)

    def summary(self):
        return {"budget": self.budget, "child_limit": self.child_limit, "avail_start": self.avail_start,
                "swap_start": self.swap_start, "swap_base_end": self.swap_base, "peak_total_fp": self.peak_total,
                "min_avail": self.min_avail, "max_pressure": self.max_pressure, "budget_kills": self.kills,
                "hard_stops": self.stops}
