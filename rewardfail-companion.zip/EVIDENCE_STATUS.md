# Public evidence status and reproducibility limits

This note clarifies the existing 12 October 2026 manuscript and companion. It
adds no experimental observations and does not revise the frozen main result.

## What can be reconstructed now

Run `python3 -B experiments/audit_public_evidence.py` from this archive. It uses
only the standard library, reads the distributed files, and writes JSON to
standard output. It does not install dependencies, download data, run scoring,
launch workers, or modify records. Exit zero means the supported checks agree;
it does **not** mean the full experiment is independently reproducible.

The audit excludes explicitly marked warm-up rows and independently counts the
93,733 main and 100,034 complement default-pass records. It compares main Table 2
and combined class totals with the saved reports, reconstructs 54 and 49 library
event rows (103 combined), and checks the saved 21-fixture outcome summary.
Saved fixture checks are not new executions. Derived-row reconstruction is not
reconstruction from complete raw parent/child events.

## What is still missing

The public package omits the corrected main reference-pass row records and the
complete original event archive. The reported main k=1 and u=18 can therefore be
read from the audited report but cannot be independently rebuilt from the public
paired reference evidence. The historical reanalysis uses an earlier analysis
version obtained with `git show 9a88991:rewardfail/s2/analyze.py`; that experiment
history is not in this archive or the public three-file repository.

For a complete public reanalysis, release the corrected paired default/reference
records, original events for the changed and unresolved rows, task/source IDs,
original and corrected analysis code, the classification-difference ledger, and
an executable reconstruction entry point. The budget-attribution correction
changed the reported unresolved count from 9,573 to 18; the saved report explains
the reason, but hashes and a final report do not replace the missing audit trail.
Do not backfill or fabricate original records. If records cannot be released,
state that restriction and retain the narrower reproducibility claim.

The public repository also lacks the LaTeX manuscript source. The author must
supply the exact source before source-based manuscript revisions or a compilable
submission package can be verified. The PDF is not changed by this clarification.

## Meaning of unresolved under the reference protocol

The paper distinguishes execution failures from ordinary negative verdicts.
However, the **frozen recovery metric** uses a narrower operational rule:
`rewardfail/s2/report.py::ref_verdict` treats a reference timeout as unresolved,
but a zero with a library error and no timeout as reference score zero. The main
reference class summary contains 12 comparison-error zeros and 4 answer-parse-
error zeros. Thus u=18 is **not the count of every library execution failure**.
The [1,19] recovery range is conditional on this declared scoring convention;
it is not a bound on hidden mathematically correct answers.

Keep the historical metric unchanged. A future error-inclusive sensitivity
analysis should separately identify unique default-zero/reference-error rows
from released paired records and recompute a clearly labelled alternative range.
Do not simply add aggregate error counts to u without verifying row pairing and
non-overlap. Longer limits and error-free execution do not establish correctness.

## Scope and contribution

The sparse-key defect, union-and-fill repair and concurrent reset interaction
were already described upstream. The contribution is the particular
wrapper-to-consumer trace, regression requirements, fixed-corpus measurements and
matched diagnostic controls, not a novel repair algorithm. Default corpus replay
observed no outer timeout or broken pool. The natural batch abort used diagnostic
60-second library and 30-second outer limits, an optional wrapper, and selected
heavy inputs; it is not a default training failure-rate estimate.

The measurements were made on one macOS arm64 machine. A fresh environment,
Linux, full-trainer behavior and training improvement remain unvalidated. The
claimed pre-declaration should be understood as an internally frozen protocol,
not independently timestamped public preregistration: the public snapshot alone
cannot establish the chronology of unpublished experiment commits.

## Next evidence needed, in priority order

1. Close the paired-reference and historical-analysis evidence gap above.
2. Provide the matching manuscript source and incorporate this terminology note.
3. Reproduce key scenes on a fresh Linux environment with real deployment worker
   routing, recording cold/warm state and resource load separately.
4. Add an unfiltered corpus and broader heavy-input families before generalizing.
5. Measure training effects only if making a learning-benefit claim. A more
   reliable audit artifact does not itself establish better learning.
