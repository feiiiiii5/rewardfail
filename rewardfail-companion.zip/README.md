# When the Verifier Cannot Decide: companion materials

This archive contains original code (Apache-2.0), compact reports, default-pass
derived score records, supplementary score records and selected shared-pool event
traces. It is not the complete original raw-log archive. Paths in public copies
are replaced by <REPO>, <HOME>, <STAGE2>, <DATA>, <AUDIT>, <VENV> or <TEMP> labels.
Reported scores, counts and numerical values are unchanged. Original fingerprints
remain in results/artifact_manifest.json; distributed-file fingerprints and exact
upstream URLs are recorded separately in package_manifest.json. See NOTICE for
third-party attribution and the distinction between code and manuscript licences.

## Inspect without installing dependencies or downloading data

From the extracted archive root:

    python3 -B experiments/check_artifacts.py --index package_manifest.json
    python3 -B experiments/compare_runs.py

The first command verifies this distributed snapshot, not the omitted complete
original-record inventory. Default classification records in records/ cover
93,733 main and 100,034 complement answers. The retained main reference rows
predate the audited budget-attribution correction and are deliberately omitted;
results/s2_main/report.json is the audited formal report. Supplementary score and
shared-pool traces are selected evidence, not independent replications. The audit
JSON files document the already completed separate reconstructions.

## Replay scope and prerequisites

Measured environment: macOS arm64, CPython 3.12.8; exact dependencies and upstream
revisions are in requirements.lock and setup.sh. Historical drivers require the
documented ~/.local/share/rewardfail layout, the fixed data files and upstream
checkouts. Linux and a newly installed machine have not been experimentally
validated. setup.sh prepares code/dependencies and a synthetic tokenizer/config;
it does not download model weights. Do not run setup.sh in a working measurement
environment: it recreates its selected virtual environment.

get_data.sh and data_manifest.tsv identify the fixed upstream data. Obtaining
those datasets is a separate action; data are not included here. Recreate the
fixed sample_map.tsv with plan/sample_map.py and compare its digest with
plan/sample_map.json. Full raw events and the original Git history are required
for the historical s2_main_reanalyze.py workflow; this zip is not that history.

For E1's original input selection, place the distributed default rows at
~/.local/share/rewardfail/stage2/runs/main-20261007-202545/default/rows.jsonl on a
fresh host, and the unchanged sources/main-wrapper.py at
~/.local/share/rewardfail/codex-audit/20261008-t40-handoff/sources/main-wrapper.py.
These derived records are sufficient for the selection scan, not for verification
against the omitted original-directory hashes. Never overwrite retained original
records. Run new measurements only in fresh directories, using the documented
s2_e1.py, s2_e2.py or s2_e3.py options, one controller at a time. They do not train
models. Severe/red memory pressure is a recorded local intervention. Counts are
conditional on the fixed corpora and declared protocols; longer limits are not
mathematical ground truth and no training benefit has been measured.

## Manuscript metadata

The publication object in package_manifest.json contains the title, author and
the exact plain-text abstract (also under arXiv's 1,920-character limit).
The manuscript is shared through GitHub and has not been peer reviewed.
Further server submission and endorsement are paused for the application
season; retained source files do not imply a pending submission.
Manuscript licence: CC BY 4.0. Original code: Apache-2.0. The source archive
contains this zip under anc/. Local packaging does not update a public copy;
the GitHub version and file hashes must be checked separately.
