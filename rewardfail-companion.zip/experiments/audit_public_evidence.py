"""Read-only reconstruction from public derived records; never reruns scoring.

Exit 0: supported checks match, with disclosed evidence gaps. Exit 1: mismatch.
A successful exit is not full reproducibility or independent raw-event validation.
Requires only Python's standard library. No repository modules are imported.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def member(root, name):
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("manifest path escapes archive root")
    return path


def count_rows(path):
    classes, scores, ids = Counter(), Counter(), set()
    events = event_ones = warmups = outer = 0
    max_wall = 0.0
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            if row.get("warm"):
                warmups += 1
                continue
            if row["id"] in ids:
                raise ValueError("duplicate answer id: " + row["id"])
            ids.add(row["id"])
            classes[row["class"]] += 1
            scores[str(row["score"])] += 1
            kinds = [category for attempt in row["attempts"]
                     for step in attempt["steps"] for category in step[3]]
            event = any(x.startswith(("Error", "Timeout")) for x in kinds)
            events += event
            event_ones += event and row["score"] == 1
            outer += any(a["outcome"] == "outer_timeout" for a in row["attempts"])
            max_wall = max(max_wall, row["wall"] or 0.0)
    return {"n": len(ids), "warmups_excluded": warmups, "classes": dict(classes),
            "scores": dict(scores), "library_event_rows": events,
            "library_event_score_one": event_ones, "outer_timeout_rows": outer,
            "max_wall_seconds": max_wall}


def inspect(root):
    issues = []
    manifest = read_json(root / "package_manifest.json")
    checked = 0
    for entry in manifest["files"]:
        path = member(root, entry["path"])
        if not path.is_file():
            issues.append("missing file: " + entry["path"])
            continue
        data = path.read_bytes()
        if len(data) != entry["bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
            issues.append("fingerprint mismatch: " + entry["path"])
        checked += 1
    main = count_rows(root / "records/main-20261007-202545/default/rows.jsonl")
    complement = count_rows(root / "records/e2-complement-20261008-codex/default/rows.jsonl")
    main_report = read_json(root / "results/s2_main/report.json")
    extension_report = read_json(root / "results/s2_e2/report.json")
    combined_classes = dict(Counter(main["classes"]) + Counter(complement["classes"]))
    comparisons = {
        "main_n": main["n"] == main_report["main_metric"]["n"] == 93733,
        "main_table_2": main["classes"] == main_report["default_classes"],
        "complement_n": complement["n"] == extension_report["extension"]["n"] == 100034,
        "combined_n": main["n"] + complement["n"] == extension_report["all_answers"]["n"] == 193767,
        "combined_classes": combined_classes == extension_report["question_descriptions"]["default_classes"],
        "main_events": main["library_event_rows"] == 54 and main["library_event_score_one"] == 9,
        "combined_events": main["library_event_rows"] + complement["library_event_rows"] == 103,
        "combined_event_ones": main["library_event_score_one"] + complement["library_event_score_one"] == 18,
        "default_outer_timeouts": main["outer_timeout_rows"] == complement["outer_timeout_rows"] == 0,
    }
    contract = read_json(root / "results/s2_e1/aggregation_contract.json")
    cases = contract["cases"]
    exceptions = sum("exception" in c["baseline"] for c in cases)
    omitted = sum("columns" in c["baseline"] and set(c["baseline"]["columns"]) != set(c["proposal"]["columns"]) for c in cases)
    comparisons["recorded_contract_cases"] = len(cases) == contract["n"] == 21
    comparisons["recorded_contract_outcomes"] = exceptions == contract["baseline_exceptions"] == 3 and omitted == contract["baseline_omitted_columns"] == 16
    comparisons["recorded_contract_pass_flags"] = all(c["pass"] for c in cases) and contract["passed"] == 21
    issues.extend("reconstruction mismatch: " + name for name, ok in comparisons.items() if not ok)
    return {
        "status": "fail" if issues else "supported_checks_pass_with_evidence_gaps",
        "fingerprinted_files_checked": checked, "main_default": main, "complement_default": complement,
        "comparisons": comparisons, "issues": issues,
        "reported_not_independently_reconstructed": {
            "main_recoveries_k": main_report["main_metric"]["k"],
            "main_unresolved_u": main_report["main_metric"]["u"],
            "reason": "Public archive omits corrected main reference rows and complete raw events; historical reanalysis also needs unpublished execution history."
        },
        "boundaries": [
            "Counts reconstruct distributed derived records, not original scorer events or mathematical ground truth.",
            "Recorded fixture checks inspect saved outcomes; no fixture or scoring code was executed.",
            "Fingerprints check consistency with the supplied manifest, not authenticity or chronology.",
            "No claim of fresh-machine, Linux, full-trainer, or independent experimental replication."
        ]
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    try:
        result = inspect(args.root.resolve())
    except (OSError, ValueError, KeyError, TypeError) as exc:
        result = {"status": "fail", "issues": [str(exc)]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return int(result["status"] == "fail")


if __name__ == "__main__":
    raise SystemExit(main())
