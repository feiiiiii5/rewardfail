"""C1a：默认参数下，Math-Verify 库内的超时能不能走到 #8015 包装的 timeout_score 分支。

把 timeout_score 设成哨兵值 -7.0：返回 -7.0 说明走到了包装的超时分支；返回 0.0/1.0 说明超时在库里就被折成了普通结果。
被测：verl PR #8015 head 的 verl/utils/reward_score/math_verify.py（真实进程池、spawn 子进程、主线程里的库计时器）。
注入：rewardfail/inject_timeout.py（只让库内被计时的步骤变慢，库的计时器与捕获层不动）。
另在本进程主线程直接调用库函数，对比默认协议（raise_on_error=False）与诊断协议（raise_on_error=True）。

用法：.venv/bin/python experiments/c1a_timeout_layers.py run1.json 2> results/c1a/run1.stderr.log   （约 1 分钟）
"""

import json
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
OUT = os.path.join(ROOT, "results", "c1a")
SENTINEL = -7.0

# (情形, 标准答案, 回答, 包装外层等待秒数, 运行前写下的预测)
CASES = [
    ("T0_control", "\\frac{1}{2}", "The answer is \\boxed{0.5}.", 30.0, "1.0（正常判对）"),
    ("T1_ref", "\\frac{3}{4}", "\\boxed{0.75}", 30.0, "1.0（T1 不注入时的健康判决）"),
    ("T1_parse_timeout", "\\frac{3}{4}", "\\boxed{0.75} [[SLOW_PARSE]]", 30.0, "0.0，约 5 秒；不是 -7"),
    ("T2a_ref", "\\frac{1}{4}", "\\boxed{0.25}", 30.0, "1.0"),
    ("T2a_verify_timeout", "\\frac{1}{4}", "\\boxed{0.25} [[SLOW_VERIFY]]", 30.0, "0.0；不是 -7"),
    ("T2b_ref", "7", "\\boxed{7}", 30.0, "1.0"),
    ("T2b_verify_timeout_string_pair_matches", "7", "\\boxed{7} [[SLOW_VERIFY]]", 30.0,
     "1.0：符号比较那一对超时，但字符串那一对判等，整体仍判对；不是 -7"),
    ("T4_shell_positive_control", "\\frac{1}{2}", "[[RAISE_TIMEOUT]]", 30.0,
     "-7.0，立即（TimeoutException 分支）；进程池不替换"),
    ("T3_outer_timeout", "\\frac{1}{2}", "\\boxed{0.5} [[SLOW_OUTSIDE]]", 4.0,
     "-7.0，约 4 秒（外层等待超时分支）；进程池被替换"),
]


def run_wrapper_cases():
    from rewardfail import inject_timeout
    from verl.utils.reward_score import math_verify as wrapper

    wrapper._verify_in_subprocess = inject_timeout.verify_with_injection
    # 预热：让 4 个子进程都先导入 verl 与 Math-Verify（本机约 7 秒），之后各情形的耗时只反映被测步骤
    t0 = time.time()
    pool = wrapper._get_pool()
    futs = [pool.submit(inject_timeout.verify_with_injection, "\\boxed{1}", "\\boxed{1}") for _ in range(8)]
    warm = [f.result(timeout=120) for f in futs]
    print(json.dumps({"warmup_seconds": round(time.time() - t0, 2), "warmup_results": warm}), flush=True)
    out = []
    for name, gt, resp, outer, pred in CASES:
        sys.stderr.write(f"\n===== CASE {name} =====\n")
        sys.stderr.flush()
        pool_before = wrapper._pool
        t0 = time.time()
        try:
            val = wrapper.compute_score(resp, gt, timeout_score=SENTINEL, timeout=outer)
            exc = None
        except BaseException as e:  # noqa: BLE001
            val, exc = None, f"{type(e).__name__}: {e}"
        dt = time.time() - t0
        time.sleep(0.3)  # 让子进程的告警先写完
        out.append({
            "case": name, "ground_truth": gt, "response": resp, "outer_timeout_s": outer,
            "prediction": pred, "returned": val, "exception": exc, "seconds": round(dt, 2),
            "reached_wrapper_timeout_branch": val == SENTINEL,
            "pool_replaced": (pool_before is not None and wrapper._pool is not pool_before),
        })
        print(json.dumps(out[-1], ensure_ascii=False), flush=True)
    return out


def run_library_protocol_contrast():
    """本进程主线程直接调用 parse：同一个慢步骤，默认协议与诊断协议的区别（C2b 式对照，不是缺陷预测）。"""
    import math_verify.parser as P
    from math_verify import LatexExtractionConfig, parse
    from math_verify.errors import TimeoutException

    orig = P.latex2sympy

    def slow(*a, **k):
        time.sleep(8.0)
        return orig(*a, **k)

    res = []
    for raise_on_error in (False, True):
        sys.stderr.write(f"\n===== LIBRARY parse raise_on_error={raise_on_error} =====\n")
        sys.stderr.flush()
        P.latex2sympy = slow
        P.parse_latex_cached.cache_clear()
        P.extract_latex.cache_clear()
        t0 = time.time()
        try:
            r = parse("\\boxed{0.75}", (LatexExtractionConfig(),), raise_on_error=raise_on_error)
            outcome = {"returned": repr(r), "exception": None}
        except TimeoutException as e:
            outcome = {"returned": None, "exception": f"TimeoutException: {e}"}
        finally:
            P.latex2sympy = orig
            P.parse_latex_cached.cache_clear()
            P.extract_latex.cache_clear()
        outcome.update({"raise_on_error": raise_on_error, "seconds": round(time.time() - t0, 2)})
        res.append(outcome)
        print(json.dumps(outcome, ensure_ascii=False), flush=True)
    return res


def main():
    os.makedirs(OUT, exist_ok=True)
    import importlib.metadata as md
    import platform

    result = {
        "started": time.strftime("%Y-%m-%d %H:%M:%S %z"),
        "environment": {"python": sys.version.split()[0], "platform": platform.platform(),
                        "math-verify": md.version("math-verify"), "sympy": md.version("sympy")},
        "wrapper_cases": run_wrapper_cases(),
        "library_protocol_contrast": run_library_protocol_contrast(),
    }
    result["finished"] = time.strftime("%Y-%m-%d %H:%M:%S %z")
    out_name = sys.argv[1] if len(sys.argv) > 1 else "results.json"
    with open(os.path.join(OUT, out_name), "w") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
