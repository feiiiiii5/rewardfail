"""C1b（已知缺陷对照，不计入新主张）：复跑 verl #7437 自带的 CPU 测试，分别对修复前、修复后的代码。

修复前：third_party/verl-pr8015（其 prime_math/grader.py 与固定 main 8718ca3 逐字相同，见 README）。
修复后：third_party/verl-pr7437（#7437 head 1403781f1ae88b50c7544adc2d4bc2ddb1c178af）。
测试文件：#7437 head 的 tests/utils/reward_score/test_prime_math_grader_on_cpu.py，各次运行用同一个文件。

两种子进程启动方式各跑一遍：本机 macOS 默认 spawn（子进程要重新导入 verl，本机约 7 秒）；fork 与 Linux 上
Python 3.12 的默认方式相同（子进程直接继承已导入的模块）。#7437 的修复用子进程计时，测试给的期限是 2 秒。

用法：.venv/bin/python experiments/c1b_pr7437_control.py run1   （约 1 分钟；结果写到 results/c1b/run1/）
"""

import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results", "c1b")
TEST = os.path.join(ROOT, "third_party", "verl-pr7437", "tests", "utils", "reward_score",
                    "test_prime_math_grader_on_cpu.py")
TREES = {
    "unfixed_pr8015_head": os.path.join(ROOT, "third_party", "verl-pr8015"),
    "fixed_pr7437_head": os.path.join(ROOT, "third_party", "verl-pr7437"),
}


def main():
    out = os.path.join(OUT, sys.argv[1]) if len(sys.argv) > 1 else OUT
    os.makedirs(out, exist_ok=True)
    summary = {}
    for label, tree, method in [(lb, tr, m) for lb, tr in TREES.items() for m in ("default", "fork")]:
        label = f"{label}__{method}"
        env = {**os.environ, "PYTHONPATH": tree}
        which = subprocess.run(
            [sys.executable, "-c", "import verl.utils.reward_score.prime_math.grader as g; print(g.__file__)"],
            env=env, capture_output=True, text=True,
        ).stdout.strip()
        xml_path = os.path.join(out, f"{label}.junit.xml")
        boot = "import multiprocessing as mp, sys, pytest; "
        if method == "fork":
            boot += "mp.set_start_method('fork', force=True); "
        boot += "print('start_method=' + mp.get_start_method(), file=sys.stderr); "
        boot += f"sys.exit(pytest.main(['-q', '-p', 'no:cacheprovider', '--junitxml={xml_path}', {TEST!r}]))"
        proc = subprocess.run([sys.executable, "-c", boot], env=env, capture_output=True, text=True, cwd=ROOT)
        with open(os.path.join(out, f"{label}.log"), "w") as f:
            f.write(proc.stdout + "\n----- stderr -----\n" + proc.stderr)
        cases = {}
        for tc in ET.parse(xml_path).getroot().iter("testcase"):
            status = "passed"
            if tc.find("failure") is not None or tc.find("error") is not None:
                status = "failed"
            elif tc.find("skipped") is not None:
                status = "skipped"
            cases[tc.get("name")] = status
        start = [ln for ln in proc.stderr.splitlines() if ln.startswith("start_method=")]
        summary[label] = {"grader_file_imported": which, "start_method": start[0].split("=", 1)[1] if start else None,
                          "pytest_returncode": proc.returncode, "tests": cases}
        print(json.dumps({label: summary[label]}, ensure_ascii=False), flush=True)
    with open(os.path.join(out, "results.json"), "w") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
