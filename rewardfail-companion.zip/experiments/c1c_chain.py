"""C1c：判分持续失败的记录，经真实管理器和两条汇总路径之后，会不会丢掉失败标记、或让整批报错。

被测代码：verl PR #8015 head 0c4c3d40d46d5f47d1918c905641eea969b7fa09（third_party/verl-pr8015）。
真实运行的部分：Ray 打分进程（RewardLoopWorker）+ rate_limited 管理器 + #8015 的 Math-Verify 包装与进程池
+ 路径 A（AgentLoopWorker._postprocess 及 AgentLoopManager 的跨进程合并）
+ 路径 B（RewardLoopManager.compute_rm_score）+ 训练器读取奖励的 extract_reward。
替身：生成环节（rewardfail/fixed_agent_loop.py，固定回答文本）；故障来源（rewardfail/inject.py，子进程退出）。

用法：
  .venv/bin/python experiments/c1c_chain.py --all          # 每个情形在独立进程、独立 Ray 会话里跑
  .venv/bin/python experiments/c1c_chain.py --case A1_row1  # 只跑一个情形
"""

import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
import time
import traceback

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VERL = os.path.join(ROOT, "third_party", "verl-pr8015")
TINY = os.path.join(ROOT, "artifacts", "tiny_model")
AGENT_YAML = os.path.join(ROOT, "artifacts", "agent_loops.yaml")
OUT = os.path.join(ROOT, "results", "c1c")
PINNED = "0c4c3d40d46d5f47d1918c905641eea969b7fa09"

sys.path.insert(0, ROOT)
from rewardfail.inject import LEDGER_ENV, MARKER  # noqa: E402

# 8 行；前 4 行进第 0 个生成进程，后 4 行进第 1 个（DataProto.chunk 连续切块）
ROWS = [
    ("1+3=?", "4", "The answer is \\boxed{4}."),
    ("2+3=?", "5", "I think it is \\boxed{6}."),
    ("Write 1/2 as a decimal.", "\\frac{1}{2}", "\\boxed{0.5}"),
    ("3*3=?", "9", "\\boxed{8}"),
    ("10-3=?", "7", "\\boxed{7}"),
    ("2^3=?", "8", "\\boxed{9}"),
    ("sqrt(16)=?", "4", "\\boxed{4}"),
    ("6/2=?", "3", "\\boxed{3}"),
]
ALL = list(range(len(ROWS)))

# 情形 -> (路径, 失败行, 运行前写下的预测[, 管理器])；管理器默认 rate_limited（#8015 说会标记失败行的那个）
# 失败行都选本来答对（1 分）的行，这样“记 0”能和“答错记 0”区分开；第 0、2、4、6、7 行答对
CASES = {
    "A0_none": ("A", [], "完成；没有 error 列"),
    "A1_row2": ("A", [2], "完成；第 2 行由 1 变 0，训练器读到的列里没有 error"),
    "A2_row0": ("A", [0], "第 0 个生成进程的汇总 KeyError，整批中止"),
    "A3_row4": ("A", [4], "第 1 个生成进程的汇总 KeyError，整批中止"),
    "A4_all": ("A", ALL, "完成；8 行都有 error 列"),
    "A5_rows4to7": ("A", [4, 5, 6, 7], "两个生成进程键名不同，跨进程合并时报错"),
    "A6_rows0to3": ("A", [0, 1, 2, 3], "两个生成进程键名不同，跨进程合并时报错或列长度不齐"),
    "B0_none": ("B", [], "完成；没有 error 列"),
    "B1_row2": ("B", [2], "完成；第 2 行由 1 变 0，训练器读到的列里没有 error"),
    "B2_row0": ("B", [0], "汇总 KeyError，整批中止"),
    "B3_all": ("B", ALL, "完成；8 行都有 error 列"),
    # 补充对照：verl 默认的 naive 管理器不接异常
    "N1_naive_A_row2": ("A", [2], "naive 不接异常：整批中止，报的是真实原因 BrokenProcessPool", "naive"),
    "N2_naive_B_row2": ("B", [2], "同上", "naive"),
}


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def environment():
    import importlib.metadata as md

    pkgs = {}
    for name in ["torch", "ray", "transformers", "tensordict", "math-verify", "latex2sympy2_extended", "sympy",
                 "numpy", "omegaconf", "hydra-core", "tokenizers"]:
        try:
            pkgs[name] = md.version(name)
        except md.PackageNotFoundError:
            pkgs[name] = None
    head = subprocess.run(["git", "-C", VERL, "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip()
    dirty = subprocess.run(["git", "-C", VERL, "status", "--porcelain"], capture_output=True, text=True).stdout
    code = {}
    for rel in ["rewardfail/inject.py", "rewardfail/reward_fn.py", "rewardfail/fixed_agent_loop.py",
                "rewardfail/tiny_model.py", "experiments/c1c_chain.py"]:
        code[rel] = sha256_file(os.path.join(ROOT, rel))
    return {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": pkgs,
        "verl_head": head,
        "verl_head_is_pinned": head == PINNED,
        "verl_worktree_clean": dirty == "",
        "requirements_lock_sha256": sha256_file(os.path.join(ROOT, "requirements.lock")),
        "code_sha256": code,
        "rows_sha256": hashlib.sha256(json.dumps(ROWS, ensure_ascii=False).encode()).hexdigest(),
    }


def ensure_artifacts():
    if not os.path.exists(os.path.join(TINY, "config.json")):
        from rewardfail.tiny_model import build

        build(TINY)
    with open(AGENT_YAML, "w") as f:
        f.write("- name: fixed_response_agent\n  _target_: rewardfail.fixed_agent_loop.FixedResponseAgentLoop\n")


def make_config(manager="rate_limited"):
    from hydra import compose, initialize_config_dir

    with initialize_config_dir(config_dir=os.path.join(VERL, "verl", "trainer", "config"), version_base=None):
        config = compose(config_name="ppo_trainer")
    config.actor_rollout_ref.model.path = TINY
    config.actor_rollout_ref.rollout.name = "vllm"  # 只是配置里的必填名；本实验不启动任何推理引擎
    config.actor_rollout_ref.rollout.prompt_length = 64
    config.actor_rollout_ref.rollout.response_length = 64
    config.actor_rollout_ref.rollout.agent.num_workers = 2
    config.actor_rollout_ref.rollout.agent.default_agent_loop = "fixed_response_agent"
    config.actor_rollout_ref.rollout.agent.agent_loop_config_path = AGENT_YAML
    config.reward.num_workers = 2
    config.reward.reward_manager.name = manager
    config.reward.custom_reward_function.path = os.path.join(ROOT, "rewardfail", "reward_fn.py")
    config.reward.custom_reward_function.name = "compute_score"
    return config


def make_batch(failing):
    import numpy as np

    from verl.protocol import DataProto

    raw_prompt, data_source, reward_model, extra_info = [], [], [], []
    for i, (prompt, gt, resp) in enumerate(ROWS):
        if i in failing:
            resp = resp + " " + MARKER + f"#row={i}"
        raw_prompt.append([{"role": "user", "content": prompt}])
        data_source.append("rewardfail_c1c")
        reward_model.append({"ground_truth": gt, "style": "rule"})
        extra_info.append({"index": i, "fixed_response": resp})
    raw = np.empty(len(ROWS), dtype=object)
    raw[:] = raw_prompt
    return DataProto.from_dict(
        non_tensors={
            "raw_prompt": raw,
            "data_source": np.array(data_source, dtype=object),
            "reward_model": np.array(reward_model, dtype=object),
            "extra_info": np.array(extra_info, dtype=object),
            "index": np.arange(len(ROWS)),
        }
    )


def summarize(batch):
    """训练器在这一步之后实际能看到的东西：extract_reward 的返回值。"""
    from verl.trainer.ppo.reward import extract_reward

    reward_tensor, extra = extract_reward(batch)
    scores = reward_tensor.sum(dim=-1).tolist()
    cols = {}
    for k, v in extra.items():
        cols[k] = [x if isinstance(x, (int, float, str, bool)) or x is None else repr(x) for x in v.tolist()]
    # 路径 A 另把每行打分附加信息的原字典放在 non_tensor_batch["reward_extra_info"]（来自 extra_fields），
    # 不经 reward_extra_keys；这里单独记录它，免得把“训练器读不到”说成“哪里都没有”
    raw_col = batch.non_tensor_batch.get("reward_extra_info")
    raw_rows_with_error = None
    if raw_col is not None:
        raw_rows_with_error = [i for i, d in enumerate(raw_col.tolist()) if isinstance(d, dict) and "error" in d]
    return {
        "row_scores": scores,
        "raw_reward_extra_info_column_present": raw_col is not None,
        "raw_reward_extra_info_rows_with_error": raw_rows_with_error,
        "reward_extra_keys": list(batch.meta_info.get("reward_extra_keys", [])),
        "non_tensor_keys": sorted(batch.non_tensor_batch.keys()),
        "extract_reward_columns": cols,
        "has_error_column": "error" in extra,
    }


def run_case(name):
    import ray

    path, failing, prediction, *rest = CASES[name]
    manager = rest[0] if rest else "rate_limited"
    ensure_artifacts()
    ray.init(
        num_cpus=6,
        include_dashboard=False,
        logging_level="ERROR",
        runtime_env={
            "env_vars": {
                "PYTHONPATH": os.pathsep.join([ROOT, VERL]),
                "TOKENIZERS_PARALLELISM": "false",
                "VERL_LOGGING_LEVEL": "WARN",
                LEDGER_ENV: os.environ.get(LEDGER_ENV, ""),
            }
        },
    )
    from verl.experimental.agent_loop import AgentLoopManager
    from verl.experimental.reward_loop import RewardLoopManager

    config = make_config(manager)
    record = {"case": name, "path": path, "manager": manager, "failing_rows": failing, "prediction": prediction}
    t0 = time.time()
    try:
        rlm = RewardLoopManager(config)
        batch = make_batch(failing)
        if path == "A":
            # 路径 A：不用奖励模型时，打分在生成阶段逐条做（ray_trainer L949 的条件）
            alm = AgentLoopManager.create(
                config=config, llm_client=None, reward_loop_worker_handles=rlm.reward_loop_workers
            )
            out = alm.generate_sequences(prompts=batch)
        else:
            # 路径 B：生成时不打分，之后整批切块交给打分进程（ray_trainer L1564 的 _compute_reward_colocate）。
            # 生产里只在“用奖励模型且没有单独资源池”时走这条；本机没有奖励模型，直接调用同一个汇总函数，
            # compute_rm_score 在 reward_model_manager 为 None 时只是跳过 wake_up/sleep。
            alm = AgentLoopManager.create(config=config, llm_client=None, reward_loop_worker_handles=None)
            gen = alm.generate_sequences(prompts=batch)
            out = gen.union(rlm.compute_rm_score(gen))
        record["outcome"] = "completed"
        record.update(summarize(out))
    except BaseException as e:  # noqa: BLE001 — 记录任何中止
        record["outcome"] = "aborted"
        record["exception_type"] = type(e).__name__
        record["exception_mro"] = [c.__name__ for c in type(e).__mro__]
        record["exception_message_head"] = str(e).strip().splitlines()[-1][:500] if str(e).strip() else ""
        record["traceback"] = traceback.format_exc()
        # 报错发生在被测代码的哪一行：取远端与本地堆栈里最后一个 verl/ 源文件位置
        import re

        sites = re.findall(r'File "[^"]*/(verl/[^"]+)", line (\d+)', str(e) + "\n" + record["traceback"])
        record["raise_site"] = f"{sites[-1][0]}:{sites[-1][1]}" if sites else None
    record["seconds"] = round(time.time() - t0, 2)
    ray.shutdown()
    return record


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--case")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--out", default=OUT, help="结果目录（复跑时另给一个目录，便于逐项对比）")
    args = ap.parse_args()
    if args.case:
        print("RESULT_JSON " + json.dumps(run_case(args.case), ensure_ascii=False))
        return
    out_dir = args.out
    os.makedirs(out_dir, exist_ok=True)
    env = environment()
    summary = {"environment": env, "started": time.strftime("%Y-%m-%d %H:%M:%S %z"), "cases": []}
    for name in CASES:
        log_path = os.path.join(out_dir, f"{name}.log")
        ledger_path = os.path.join(out_dir, f"{name}.ledger.jsonl")
        if os.path.exists(ledger_path):
            os.remove(ledger_path)
        proc = subprocess.run(
            [sys.executable, os.path.abspath(__file__), "--case", name],
            capture_output=True, text=True, timeout=900, cwd=ROOT,
            env={**os.environ, "RAY_DEDUP_LOGS": "0", LEDGER_ENV: ledger_path},
        )
        with open(log_path, "w") as f:
            f.write(proc.stdout)
            f.write("\n----- stderr -----\n")
            f.write(proc.stderr)
        line = [ln for ln in proc.stdout.splitlines() if ln.startswith("RESULT_JSON ")]
        rec = json.loads(line[-1][len("RESULT_JSON "):]) if line else {"case": name, "outcome": "runner_failed",
                                                                         "returncode": proc.returncode}
        rec["worker_log_lines_reward_failed"] = [
            ln.strip()[:300] for ln in proc.stderr.splitlines() if "Reward computation failed" in ln
        ]
        deaths = {}
        if os.path.exists(ledger_path):
            for ln in open(ledger_path):
                r = json.loads(ln)["row"]
                deaths[str(r)] = deaths.get(str(r), 0) + 1
        rec["injected_worker_deaths_by_row"] = deaths
        with open(os.path.join(out_dir, f"{name}.json"), "w") as f:
            json.dump(rec, f, ensure_ascii=False, indent=2)
        brief = {k: rec.get(k) for k in ["case", "manager", "outcome", "exception_type", "raise_site",
                                         "exception_message_head",
                                         "has_error_column", "reward_extra_keys", "row_scores",
                                         "raw_reward_extra_info_rows_with_error"]}
        brief["n_failed_log_lines"] = len(rec["worker_log_lines_reward_failed"])
        brief["injected_worker_deaths_by_row"] = deaths
        summary["cases"].append(brief)
        print(json.dumps(brief, ensure_ascii=False), flush=True)
    summary["finished"] = time.strftime("%Y-%m-%d %H:%M:%S %z")
    with open(os.path.join(out_dir, "summary.json"), "w") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
