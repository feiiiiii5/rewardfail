"""C2a：外壳在同一进程主线程里用 signal.alarm 给每题设期限，再调用 Math-Verify；库内设置/清除 SIGALRM 后，外层期限还在不在。

外壳是标准库替身，只模仿“每题 alarm(N)、超时由处理函数抛异常”这一做法（2609.01354 作者外壳的同类写法），
不是作者代码本身。Math-Verify 是真实库（0.9.0，与固定提交 ba3d3aa 逐字相同）。

用法：.venv/bin/python experiments/c2a_alarm_nesting.py run1.json   （约 15 秒）
"""

import json
import os
import signal
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results", "c2a")


class ShellDeadline(Exception):
    pass


def shell_handler(signum, frame):
    raise ShellDeadline("shell per-item deadline fired")


def run(name, outer_seconds, library_call, work_after_s, prediction):
    signal.signal(signal.SIGALRM, shell_handler)
    t0 = time.time()
    fired_at = None
    remaining_after_library = None
    handler_restored = None
    try:
        signal.alarm(outer_seconds)
        if library_call is not None:
            library_call()
            # 读出并恢复：alarm(0) 返回剩余秒数；0 表示外层期限已经没有了
            remaining_after_library = signal.alarm(0)
            handler_restored = signal.getsignal(signal.SIGALRM) is shell_handler
            if remaining_after_library:
                signal.alarm(remaining_after_library)
        time.sleep(work_after_s)  # 外壳在这一题里还要做的事（或卡住）
        signal.alarm(0)
    except ShellDeadline:
        fired_at = round(time.time() - t0, 2)
    rec = {
        "case": name, "outer_deadline_s": outer_seconds, "work_after_library_s": work_after_s,
        "prediction": prediction, "shell_deadline_fired_at_s": fired_at,
        "remaining_outer_alarm_after_library_s": remaining_after_library,
        "shell_handler_still_installed": handler_restored, "total_s": round(time.time() - t0, 2),
    }
    print(json.dumps(rec, ensure_ascii=False), flush=True)
    return rec


def main():
    import math_verify.parser as P
    from math_verify import LatexExtractionConfig, parse, verify

    def fast_parse():
        parse("\\boxed{\\frac{1}{2}}", (LatexExtractionConfig(),))

    def fast_verify():
        verify(parse("\\boxed{\\frac{1}{2}}"), parse("\\boxed{0.5}"))

    def slow_parse_3s():
        orig = P.latex2sympy

        def slow(*a, **k):
            time.sleep(3.0)
            return orig(*a, **k)

        P.latex2sympy = slow
        P.parse_latex_cached.cache_clear()
        P.extract_latex.cache_clear()
        try:
            parse("\\boxed{0.125}", (LatexExtractionConfig(),))
        finally:
            P.latex2sympy = orig
            P.parse_latex_cached.cache_clear()
            P.extract_latex.cache_clear()

    os.makedirs(OUT, exist_ok=True)
    recs = [
        run("S0_control_no_library", 2, None, 4, "外层期限在约 2 秒触发"),
        run("S1_fast_parse_then_work", 2, fast_parse, 4, "外层期限被库的 alarm(0) 清除，不再触发；剩余秒数读出为 0"),
        run("S2_fast_verify_then_work", 2, fast_verify, 4, "同 S1"),
        run("S3_slow_parse_longer_than_outer", 1, slow_parse_3s, 0, "库把期限改写成自己的 5 秒，外层 1 秒期限不触发，这一题跑满约 3 秒"),
    ]
    out_name = sys.argv[1] if len(sys.argv) > 1 else "results.json"
    with open(os.path.join(OUT, out_name), "w") as f:
        import importlib.metadata as md
        import platform

        json.dump({"finished": time.strftime("%Y-%m-%d %H:%M:%S %z"), "cases": recs,
                   "environment": {"python": sys.version.split()[0], "platform": platform.platform(),
                                   "math-verify": md.version("math-verify")}},
                  f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
