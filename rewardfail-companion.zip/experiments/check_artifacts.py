"""Read-only fingerprint and report-value checks, with relocatable roots.

This never scores an answer, downloads a file, or changes a run. A complete
pass confirms the indexed bytes and frozen report values, not their scientific
validity or replication on another machine. Missing roots are partial, not pass.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def resolve_member(root: Path, name: str) -> Path:
    """Reject ambiguous paths and symlinks that escape the caller's root."""
    if (not isinstance(name, str) or not name or "\\" in name
            or ":" in name or any(x in ("", ".", "..") for x in name.split("/"))
            or PurePosixPath(name).is_absolute()):
        raise ValueError("invalid relative member")
    base = root.resolve()
    target = (base / name).resolve()
    if not target.is_relative_to(base):
        raise ValueError("member escapes root")
    return target


def pointer(document, address: str):
    if address == "":
        return document
    if not isinstance(address, str) or not address.startswith("/"):
        raise ValueError("invalid JSON pointer")
    for encoded in address[1:].split("/"):
        key = encoded.replace("~1", "/").replace("~0", "~")
        document = document[int(key)] if isinstance(document, list) else document[key]
    return document


def verify(index: dict, roots: dict[str, Path]) -> dict:
    issues, omitted = [], []
    checked = 0
    if index.get("schema") != 1:
        return {"status": "fail", "issues": ["unsupported index schema"]}
    declared = set(index.get("roots", {}))
    seen = set()
    members = index.get("files", [])
    if not declared or not members:
        return {"status": "fail", "issues": ["empty roots or file inventory"]}
    for entry in members:
        label, name = entry.get("root"), entry.get("path")
        ident = f"{label}:{name}"
        try:
            if label not in declared or (label, name) in seen:
                raise ValueError("unknown root or duplicate member")
            seen.add((label, name))
            if not re.fullmatch(r"[0-9a-f]{64}", entry.get("sha256", "")):
                raise ValueError("invalid SHA-256")
            size = entry.get("bytes")
            if type(size) is not int or size < 0:
                raise ValueError("invalid size")
            # Validate the member even when its root was not supplied.
            resolve_member(Path("/unused-artifact-root"), name)
            if label not in roots:
                omitted.append(ident)
                continue
            path = resolve_member(roots[label], name)
            if not path.is_file():
                raise ValueError("missing regular file")
            if path.stat().st_size != size or digest(path) != entry["sha256"]:
                raise ValueError("fingerprint mismatch")
            checked += 1
        except (ValueError, TypeError, OSError) as error:
            issues.append(f"{ident}: {error}")

    # A run set denotes the entire directory at indexing time. Extra files
    # cannot silently change the meaning of a supposedly frozen directory.
    for run in index.get("run_sets", []):
        label, directory = run["root"], run["path"]
        if label not in roots:
            continue
        try:
            parent = resolve_member(roots[label], directory)
            actual = {p.relative_to(roots[label].resolve()).as_posix()
                      for p in parent.rglob("*") if p.is_file() or p.is_symlink()}
            expected = {name for tag, name in seen
                        if tag == label and name.startswith(directory + "/")}
            if actual != expected:
                raise ValueError(f"directory membership changed: extra={len(actual-expected)}, "
                                 f"missing={len(expected-actual)}")
        except (ValueError, OSError) as error:
            issues.append(f"{label}:{directory}: {error}")

    matched, skipped = 0, 0
    documents = {}
    for check in index.get("report_checks", []):
        label, name = check["root"], check["path"]
        if label not in roots:
            skipped += 1
            continue
        try:
            if (label, name) not in seen:
                raise ValueError("report is not fingerprinted")
            if (label, name) not in documents:
                documents[label, name] = json.loads(resolve_member(roots[label], name).read_text())
            value = pointer(documents[label, name], check["pointer"])
            if check.get("transform") == "len":
                value = len(value)
            elif check.get("transform") is not None:
                raise ValueError("unsupported transform")
            if type(value) is not type(check["expected"]) or value != check["expected"]:
                raise ValueError("frozen report value differs")
            matched += 1
        except (ValueError, KeyError, IndexError, TypeError, OSError) as error:
            issues.append(f"report {label}:{name}{check['pointer']}: {error}")
    status = "fail" if issues else "partial" if omitted or skipped else "pass"
    return {"status": status, "files_checked": checked, "files_not_checked": len(omitted),
            "reports_matched": matched, "reports_not_checked": skipped,
            "missing_roots": sorted({x.split(":", 1)[0] for x in omitted}), "issues": issues,
            "boundary": "Indexed bytes and frozen report values only; no rescoring or independent replication."}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--index", type=Path)
    parser.add_argument("--root", action="append", default=[], metavar="NAME=PATH")
    args = parser.parse_args()
    repo = Path(__file__).resolve().parents[1]
    roots = {"repo": repo}
    supplied = set()
    for spec in args.root:
        name, separator, value = spec.partition("=")
        if not separator or not name or not value or name in supplied:
            parser.error("each root must appear once as NAME=PATH")
        supplied.add(name)
        roots[name] = Path(value).expanduser().resolve()
    try:
        index_path = args.index or roots["repo"] / "results/artifact_manifest.json"
        index = json.loads(index_path.read_text())
        unknown = set(roots) - set(index["roots"])
        if unknown:
            parser.error("root names are not declared in the index")
        result = verify(index, roots)
    except (ValueError, TypeError, KeyError, OSError) as error:
        result = {"status": "fail", "issues": [str(error)]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return {"pass": 0, "partial": 2, "fail": 1}[result["status"]]


if __name__ == "__main__":
    sys.exit(main())
