"""逐项比较两轮复跑的结果，并打印 README 用的结果表。

用法：.venv/bin/python experiments/compare_runs.py
比较的字段：结局、异常类型、报错位置、extract_reward 返回的附加列、各行分数、原样附加信息里带 error 的行、注入触发的行集合。
注入次数（每行 1 次还是 2 次）取决于失败行先后落到哪个打分进程，不要求两轮相同，只要求每个失败行至少触发一次。
"""

import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = os.path.join(ROOT, "results")

C1C_FIELDS = ["outcome", "exception_type", "raise_site", "exception_message_head", "has_error_column",
              "reward_extra_keys", "row_scores", "raw_reward_extra_info_rows_with_error"]


def load_c1c(run):
    d = os.path.join(R, "c1c", run)
    summary = json.load(open(os.path.join(d, "summary.json")))
    return {c["case"]: json.load(open(os.path.join(d, c["case"] + ".json"))) for c in summary["cases"]}, summary


def main():
    problems = []
    r1, s1 = load_c1c("run1")
    r2, s2 = load_c1c("run2")
    assert list(r1) == list(r2)
    for k in ["verl_head", "verl_head_is_pinned", "verl_worktree_clean", "requirements_lock_sha256", "code_sha256",
              "rows_sha256", "packages"]:
        if s1["environment"][k] != s2["environment"][k]:
            problems.append(f"environment.{k} differs")
    print("| 情形 | 管理器 | 失败行 | 运行前预测 | 结局 | 报错位置 | extract_reward 返回的附加列 | 各行分数 | 原样附加信息里带 error 的行 | 注入触发的行 |")
    print("|---|---|---|---|---|---|---|---|---|---|")
    for case, a in r1.items():
        b = r2[case]
        for f in C1C_FIELDS:
            if a.get(f) != b.get(f):
                problems.append(f"c1c {case}.{f}: {a.get(f)!r} != {b.get(f)!r}")
        rows_a = sorted(int(x) for x in a["injected_worker_deaths_by_row"])
        rows_b = sorted(int(x) for x in b["injected_worker_deaths_by_row"])
        if rows_a != sorted(a["failing_rows"]) or rows_b != sorted(b["failing_rows"]):
            problems.append(f"c1c {case}: injected rows {rows_a}/{rows_b} != failing {a['failing_rows']}")
        outcome = "完成" if a["outcome"] == "completed" else f"中止：{a['exception_type']} {a.get('exception_message_head', '')}"
        cols = ", ".join(a["reward_extra_keys"]) if a.get("reward_extra_keys") is not None else "—"
        scores = " ".join(f"{x:g}" for x in a["row_scores"]) if a.get("row_scores") else "—"
        raw = a.get("raw_reward_extra_info_rows_with_error")
        raw = "—" if raw is None else (str(raw) if raw else "无")
        print(f"| {case} | {a.get('manager')} | {a['failing_rows'] or '无'} | {a['prediction']} | {outcome} | "
              f"{a.get('raise_site') or '—'} | {cols} | {scores} | {raw} | {rows_a or '无'} |")

    for name in ["c1a", "c2a"]:
        p1, p2 = os.path.join(R, name, "run1.json"), os.path.join(R, name, "run2.json")
        if not (os.path.exists(p1) and os.path.exists(p2)):
            problems.append(f"{name}: missing run")
            continue
        a, b = json.load(open(p1)), json.load(open(p2))
        if name == "c1a":
            for x, y in zip(a["wrapper_cases"], b["wrapper_cases"], strict=True):
                for f in ["case", "returned", "exception", "reached_wrapper_timeout_branch", "pool_replaced"]:
                    if x[f] != y[f]:
                        problems.append(f"c1a {x['case']}.{f}: {x[f]!r} != {y[f]!r}")
            for x, y in zip(a["library_protocol_contrast"], b["library_protocol_contrast"], strict=True):
                for f in ["raise_on_error", "returned", "exception"]:
                    if x[f] != y[f]:
                        problems.append(f"c1a library.{f}: {x[f]!r} != {y[f]!r}")
        else:
            for x, y in zip(a["cases"], b["cases"], strict=True):
                for f in ["case", "shell_deadline_fired_at_s", "remaining_outer_alarm_after_library_s",
                          "shell_handler_still_installed"]:
                    xv, yv = x[f], y[f]
                    if isinstance(xv, float) and isinstance(yv, float):
                        same = abs(xv - yv) < 0.5
                    else:
                        same = xv == yv
                    if not same:
                        problems.append(f"c2a {x['case']}.{f}: {xv!r} != {yv!r}")
    print()
    print("两轮不一致项：" + ("无" if not problems else ""))
    for p in problems:
        print(" - " + p)


if __name__ == "__main__":
    main()
