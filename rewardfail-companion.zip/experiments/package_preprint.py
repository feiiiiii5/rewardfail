"""Prepare local final files; never submit, score, download or alter raw records.

Public JSON copies substitute path labels. Their own digest manifest is distinct
from results/artifact_manifest.json, which describes retained original bytes.
"""
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
HOME = Path.home()
BASE = HOME / ".local/share/rewardfail"
AUDIT = BASE / "codex-audit/20261008-t40-handoff"
STAGE2 = BASE / "stage2"
PATH_LABELS = [(str(ROOT), "<REPO>"), (str(AUDIT), "<AUDIT>"),
               (str(STAGE2), "<STAGE2>"), (str(BASE / "data"), "<DATA>"),
               (str(BASE / "venv"), "<VENV>"), (str(HOME), "<HOME>")]
PRIVATE = re.compile(r"/Users/[A-Za-z0-9._-]+/|/(?:private/)?var/folders/[A-Za-z0-9_-]+/|"
                     r"gh[pousr]_[A-Za-z0-9]{25,}|sk-[A-Za-z0-9]{30,}")
FIXED_TIME = (2026, 10, 9, 0, 0, 0)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def labels(s):
    for old, new in PATH_LABELS:
        s = s.replace(old, new)
    return re.sub(r"/(?:private/)?(?:var/folders|tmp)/[^\s\"'`<>]+", "<TEMP>", s)


def scrub(value):
    if isinstance(value, str):
        return labels(value)
    if isinstance(value, list):
        return [scrub(x) for x in value]
    if isinstance(value, dict):
        return {labels(k): scrub(v) for k, v in value.items()}
    return value


def json_bytes(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode()


def info(name):
    parts = PurePosixPath(name)
    if (not name or parts.is_absolute() or "\\" in name or ":" in name
            or any(p in ("", ".", "..") for p in name.split("/"))):
        raise ValueError("unsafe archive member")
    z = zipfile.ZipInfo(name, FIXED_TIME)
    z.compress_type = zipfile.ZIP_DEFLATED
    z.external_attr = 0o100644 << 16
    return z


def abstract(tex):
    body = tex.split(r"\begin{abstract}", 1)[1].split(r"\end{abstract}", 1)[0]
    body = body.replace(r"\%", "%").replace(r"\,", " ")
    body = body.replace(r"$2.97\times10^{-4}$", "2.97e-4")
    body = " ".join(body.split())
    if len(body) > 1920 or "\\" in body:
        raise ValueError("submission abstract is too long or has unresolved macros")
    return body


def verify(path):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError("duplicate archive member")
        for name in names:
            info(name)
            if z.getinfo(name).external_attr >> 16 & 0o170000 == 0o120000:
                raise ValueError("archive contains a symlink")
        manifest_raw = z.read("package_manifest.json")
        if PRIVATE.search(manifest_raw.decode("utf-8")):
            raise ValueError("private path or credential pattern in manifest")
        manifest = json.loads(manifest_raw)
        if manifest.get("schema") != 1 or set(manifest.get("roots", {})) != {"repo"}:
            raise ValueError("unsupported distribution manifest")
        expected = {f["path"] for f in manifest["files"]} | {"package_manifest.json"}
        if len(expected) != len(manifest["files"]) + 1 or set(names) != expected:
            raise ValueError("archive inventory mismatch")
        for f in manifest["files"]:
            raw = z.read(f["path"])
            if len(raw) != f["bytes"] or digest(raw) != f["sha256"]:
                raise ValueError("archive fingerprint mismatch: " + f["path"])
            if PRIVATE.search(raw.decode("utf-8")):
                raise ValueError("private path or credential pattern: " + f["path"])
        for c in manifest["report_checks"]:
            value = json.loads(z.read(c["path"]))
            for key in c["pointer"][1:].split("/") if c["pointer"] else []:
                key = key.replace("~1", "/").replace("~0", "~")
                value = value[int(key)] if isinstance(value, list) else value[key]
            if c.get("transform") == "len":
                value = len(value)
            elif c.get("transform") is not None:
                raise ValueError("unsupported report transform")
            if value != c["expected"] or type(value) is not type(c["expected"]):
                raise ValueError("frozen report value changed")
    return {"files": len(manifest["files"]), "report_checks": len(manifest["report_checks"]),
            "bytes": path.stat().st_size, "sha256": digest(path.read_bytes()),
            "abstract_characters": len(manifest["publication"]["abstract"])}


def prepare(pdf, bbl, out):
    if out.resolve() != ROOT / "paper":
        raise ValueError("final outputs must be in this repository's paper directory")
    if not pdf.read_bytes().startswith(b"%PDF-") or b"thebibliography" not in bbl.read_bytes():
        raise ValueError("missing compiled PDF or bibliography")
    tex = (ROOT / "paper/main.tex").read_text()
    publication = {"title": "When the Verifier Cannot Decide: Tracing Math-Verify Failures Through an RLVR Reward Pipeline",
                   "author": "Yufeiyang Chen", "abstract": abstract(tex),
                   "status": "Prepared manuscript; submission and publication status must be checked on the platform",
                   "manuscript_licence": "CC BY 4.0",
                   "manuscript_licence_url": "https://creativecommons.org/licenses/by/4.0/",
                   "affiliation": "School of Cyber Science and Technology, Sun Yat-sen University, Shenzhen, China",
                   "correspondence": "fei76161@gmail.com", "target_platform": "arXiv",
                   "code_licence": "Apache-2.0", "primary_category_suggestion": "cs.LG",
                   "cross_list_suggestion": "cs.SE", "local_compiler": "Tectonic (XeTeX)",
                   "server_preview": "Check the platform-generated PDF during the actual submission"}
    original = json.loads((ROOT / "results/artifact_manifest.json").read_text())
    manifest = {"schema": 1, "scope": "Distributed code, compact reports and selected derived records; not all original raw logs",
                "roots": {"repo": "Extracted companion archive"}, "run_sets": [],
                "source_base_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
                "publication": publication, "files": [],
                "report_checks": [c for c in original["report_checks"] if c["root"] == "repo"],
                "boundaries": ["Original complete-record fingerprints are in results/artifact_manifest.json.",
                               "Public path-substituted copies have different hashes from the originals.",
                               "No raw datasets, models, environment, Git directory or full 2 GB event archive included.",
                               "Historical measurement drivers retain their documented macOS/layout dependence."]}
    companion = out / "rewardfail-companion.zip"
    names = set()
    with zipfile.ZipFile(companion, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        def put(name, raw, origin=None):
            if name in names:
                raise ValueError("duplicate output: " + name)
            if PRIVATE.search(raw.decode("utf-8")):
                raise ValueError("private path or credential pattern: " + name)
            names.add(name)
            z.writestr(info(name), raw, compresslevel=9)
            row = {"root": "repo", "path": name, "bytes": len(raw), "sha256": digest(raw)}
            if origin:
                row.update(origin)
            manifest["files"].append(row)

        tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT).decode().split("\0")
        tracked += ["LICENSE", "NOTICE", "experiments/package_preprint.py"]
        singles = {"setup.sh", "get_data.sh", "requirements.in", "requirements.lock", "data_manifest.tsv", "LICENSE", "NOTICE"}
        for name in sorted(set(tracked) - {""}):
            p = ROOT / name
            if name not in singles and not name.startswith(("experiments/", "rewardfail/", "tests/", "plan/", "results/")):
                continue
            if not p.is_file() or p.is_symlink():
                continue
            raw = p.read_bytes()
            public = json_bytes(scrub(json.loads(raw))) if p.suffix == ".json" else labels(raw.decode()).encode()
            put(name, public, {"original_sha256": digest(raw), "origin": "repo:" + name})

        main_source = (AUDIT / "sources/main-wrapper.py").read_bytes()
        source_entry = original["source_catalog"]["main-wrapper.py"]
        if digest(main_source) != source_entry["sha256"] or len(main_source) != source_entry["bytes"]:
            raise ValueError("fixed upstream wrapper changed")
        put("sources/main-wrapper.py", main_source,
            {"upstream_url": source_entry["url"], "original_sha256": digest(main_source)})
        for f in original["files"]:
            if f["root"] == "audit" and f["path"].endswith(".json") and not f["path"].startswith("editorial/"):
                p = AUDIT / f["path"]
                raw = p.read_bytes()
                if digest(raw) != f["sha256"]:
                    raise ValueError("original audit changed")
                put("audits/" + f["path"], json_bytes(scrub(json.loads(raw))),
                    {"original_sha256": digest(raw), "origin": "audit:" + f["path"]})

        for f in original["files"]:
            path = f["path"]
            scores = f["root"] == "stage2" and path.endswith("/rows.jsonl") and (
                path in ("runs/main-20261007-202545/default/rows.jsonl", "runs/e2-complement-20261008-codex/default/rows.jsonl")
                or path.startswith("runs/e3-20261008-codex/") or path.startswith("runs/u18-20261008-104342/"))
            traces = f["root"] == "stage2" and path.endswith(".jsonl") and path.startswith((
                "runs/e1-core-20261008-codex/", "runs/e1-eight-20261008-codex/",
                "runs/e1-repeat-20261008-codex/", "runs/e1-controls-20261008-codex/"))
            if not scores and not traces:
                continue
            p = STAGE2 / path
            name = "records/" + path.removeprefix("runs/")
            original_hash, public_hash = hashlib.sha256(), hashlib.sha256()
            size, lines = 0, 0
            with p.open("rb") as src, z.open(info(name), "w", force_zip64=True) as dst:
                for line in src:
                    original_hash.update(line)
                    obj = scrub(json.loads(line))
                    public = (json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n").encode()
                    if PRIVATE.search(public.decode()):
                        raise ValueError("private path in selected record")
                    dst.write(public); public_hash.update(public); size += len(public); lines += 1
            if original_hash.hexdigest() != f["sha256"]:
                raise ValueError("original record changed: " + path)
            names.add(name)
            manifest["files"].append({"root": "repo", "path": name, "bytes": size,
                                      "sha256": public_hash.hexdigest(), "lines": lines,
                                      "original_sha256": f["sha256"], "origin": "stage2:" + path})

        readme = """# When the Verifier Cannot Decide: companion materials

This archive contains original code (Apache-2.0), compact reports, default-pass
derived score records, supplementary score records and selected shared-pool event
traces. It is not the complete original raw-log archive. Paths in public copies
are replaced by <REPO>, <HOME>, <STAGE2>, <DATA>, <AUDIT>, <VENV> or <TEMP> labels.
Reported scores, counts and numerical values are unchanged. Original fingerprints
remain in results/artifact_manifest.json; distributed-file fingerprints and exact
upstream URLs are recorded separately in package_manifest.json. See NOTICE for
third-party attribution and the distinction between code and manuscript licences.

## Inspect without installing dependencies or downloading data

From the extracted archive root:

    python3 -B experiments/check_artifacts.py --index package_manifest.json
    python3 -B experiments/compare_runs.py

The first command verifies this distributed snapshot, not the omitted complete
original-record inventory. Default classification records in records/ cover
93,733 main and 100,034 complement answers. The retained main reference rows
predate the audited budget-attribution correction and are deliberately omitted;
results/s2_main/report.json is the audited formal report. Supplementary score and
shared-pool traces are selected evidence, not independent replications. The audit
JSON files document the already completed separate reconstructions.

## Replay scope and prerequisites

Measured environment: macOS arm64, CPython 3.12.8; exact dependencies and upstream
revisions are in requirements.lock and setup.sh. Historical drivers require the
documented ~/.local/share/rewardfail layout, the fixed data files and upstream
checkouts. Linux and a newly installed machine have not been experimentally
validated. setup.sh prepares code/dependencies and a synthetic tokenizer/config;
it does not download model weights. Do not run setup.sh in a working measurement
environment: it recreates its selected virtual environment.

get_data.sh and data_manifest.tsv identify the fixed upstream data. Obtaining
those datasets is a separate action; data are not included here. Recreate the
fixed sample_map.tsv with plan/sample_map.py and compare its digest with
plan/sample_map.json. Full raw events and the original Git history are required
for the historical s2_main_reanalyze.py workflow; this zip is not that history.

For E1's original input selection, place the distributed default rows at
~/.local/share/rewardfail/stage2/runs/main-20261007-202545/default/rows.jsonl on a
fresh host, and the unchanged sources/main-wrapper.py at
~/.local/share/rewardfail/codex-audit/20261008-t40-handoff/sources/main-wrapper.py.
These derived records are sufficient for the selection scan, not for verification
against the omitted original-directory hashes. Never overwrite retained original
records. Run new measurements only in fresh directories, using the documented
s2_e1.py, s2_e2.py or s2_e3.py options, one controller at a time. They do not train
models. Severe/red memory pressure is a recorded local intervention. Counts are
conditional on the fixed corpora and declared protocols; longer limits are not
mathematical ground truth and no training benefit has been measured.

## Submission metadata

The publication object in package_manifest.json contains the title, author and
the exact plain-text abstract (also under arXiv's 1,920-character limit). The
current target is arXiv; the suggested classification is cs.LG, with an
optional cs.SE cross-list, subject to author choice and moderation. Manuscript licence:
CC BY 4.0. Original code: Apache-2.0. The paper's source archive contains this zip
under anc/. Local compilation and checks do not constitute a public submission;
submission and publication status must be checked on the platform.
"""
        put("README.md", readme.encode())
        manifest["files"].sort(key=lambda x: x["path"])
        z.writestr(info("package_manifest.json"), json_bytes(manifest), compresslevel=9)

    checked = verify(companion)
    source = out / "arxiv-source.zip"
    with zipfile.ZipFile(source, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, p in (("main.tex", ROOT / "paper/main.tex"), ("refs.bib", ROOT / "paper/refs.bib"), ("main.bbl", bbl)):
            z.writestr(info(name), p.read_bytes(), compresslevel=9)
        z.writestr(info("anc/rewardfail-companion.zip"), companion.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(source) as z:
        if set(z.namelist()) != {"main.tex", "refs.bib", "main.bbl", "anc/rewardfail-companion.zip"}:
            raise ValueError("source archive includes extraneous files")
        assert z.read("main.tex") == (ROOT / "paper/main.tex").read_bytes()
        assert z.read("anc/rewardfail-companion.zip") == companion.read_bytes()
    final_pdf = out / "main.pdf"
    if final_pdf.resolve() != pdf.resolve():
        shutil.copyfile(pdf, final_pdf)
    return {"companion": checked,
            "source": {"bytes": source.stat().st_size, "sha256": digest(source.read_bytes())},
            "pdf": {"bytes": final_pdf.stat().st_size, "sha256": digest(final_pdf.read_bytes())},
            "scope": "Local final files only; not publicly submitted"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", type=Path)
    parser.add_argument("--bbl", type=Path)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "paper")
    parser.add_argument("--verify", type=Path)
    args = parser.parse_args()
    if args.verify:
        result = verify(args.verify)
    else:
        if not args.pdf or not args.bbl:
            parser.error("provide --pdf and --bbl, or --verify")
        result = prepare(args.pdf, args.bbl, args.output_dir)
    print(json.dumps(result, ensure_ascii=False, indent=2))
