"""Bounded aggregation-only regression, not verifier replay or training.

The pinned real aggregation method runs unchanged and with two local AST
assignment replacements. Scoring outputs/Ray transport are fixed substitutes.
The proposed change preserves heterogeneous extra-info columns, filling absent
values with None; it chooses no reward/loss policy and fixes no silent library
failure or naive-manager exception. Upstream source is read-only.
"""
import ast
import hashlib
import inspect
import json
import sys
import textwrap
from collections import Counter
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "experiments")]
import s2_e1 as e1
from rewardfail.s2.stepguard import StepGuard, write_atomic


def local_patch(original):
    tree = ast.parse(textwrap.dedent(inspect.getsource(original)))
    substitutions = {
        "reward_extra_keys": "reward_extra_keys = sorted({key for info in reward_extra_infos for key in info})",
        "non_tensor_batch": "non_tensor_batch[key] = np.array([info.get(key, None) for info in reward_extra_infos], dtype=object)",
    }
    counts = Counter()
    class Replace(ast.NodeTransformer):
        def visit_Assign(self, node):
            target = node.targets[0]
            name = (target.id if isinstance(target, ast.Name) else
                    target.value.id if isinstance(target, ast.Subscript) and isinstance(target.value, ast.Name) else None)
            if name == "reward_extra_keys":
                if ast.unparse(node.value) != "list(reward_extra_infos[0].keys())":
                    raise ValueError("pinned key-selection expression changed")
            elif name == "non_tensor_batch" and isinstance(target, ast.Subscript):
                if ast.unparse(node.value) != "np.array([info[key] for info in reward_extra_infos])":
                    raise ValueError("pinned column-building expression changed")
            else:
                return self.generic_visit(node)
            counts[name] += 1
            return ast.copy_location(ast.parse(substitutions[name]).body[0], node)
    tree = Replace().visit(tree)
    if counts != {"reward_extra_keys": 1, "non_tensor_batch": 1}:
        raise ValueError("patch must replace exactly two assignments")
    ast.fix_missing_locations(tree)
    namespace = dict(original.__globals__)
    exec(compile(tree, "<local-aggregation-proposal>", "exec"), namespace)
    return namespace[original.__name__], hashlib.sha256(ast.dump(tree, include_attributes=False).encode()).hexdigest()


def cases():
    def normal(n=8):
        return [{"reward_score": 1.0, "reward_extra_info": {"acc": 1.0}} for _ in range(n)]
    out = [{"name": "normal", "outputs": normal(), "workers": 1},
           {"name": "empty-extras", "outputs": [{"reward_score": 1.0} for _ in range(8)], "workers": 1}]
    for kind, value in (("error", "persistent scoring failure"), ("timeout", True)):
        for pos in range(8):
            rows = normal(); rows[pos] = {"reward_score": 0.0, "reward_extra_info": {"acc": 0.0, kind: value}}
            out.append({"name": f"{kind}-position-{pos+1}", "outputs": rows, "workers": 1})
    for reverse in (False, True):
        rows = normal(); rows[0 if reverse else 6] = {"reward_score": 0.0, "reward_extra_info": {"acc": 0.0, "error": "failure"}}
        rows[1 if reverse else 7] = {"reward_score": 0.0, "reward_extra_info": {"acc": 0.0, "timeout": True}}
        out.append({"name": "mixed-first" if reverse else "mixed-later", "outputs": rows, "workers": 2})
    rows = normal(7);rows[-1] = {"reward_score": 0.0, "reward_extra_info": {"acc": 0.0, "error": "failure"}}
    out.append({"name": "padding-trim", "outputs": rows, "workers": 2})
    return out


def invoke(method, outputs, workers):
    from verl.experimental.reward_loop import reward_loop as R
    from verl.experimental.reward_loop.reward_manager.naive import NaiveRewardManager
    from verl.trainer.ppo.reward import extract_reward
    batch = e1.make_batch([{"id": str(i), "gt": "2", "out": "2"} for i in range(len(outputs))])
    control = object.__new__(R.RewardLoopManager)
    control.reward_model_manager, control.reward_manager_cls = None, NaiveRewardManager
    n = len(outputs); pad = (-n) % workers
    padded = outputs + outputs[:pad]
    size = len(padded) // workers
    chunks = [padded[i*size:(i+1)*size] for i in range(workers)]
    control.reward_loop_workers = [SimpleNamespace(compute_score_batch=SimpleNamespace(remote=lambda chunk, rows=rows: rows))
                                   for rows in chunks]
    original_get = R.ray.get
    try:
        R.ray.get = lambda values: values
        result = method(control, batch)
        score, extras = extract_reward(result)
        return {"scores": score.sum(dim=-1).tolist(), "columns": {key: value.tolist() for key, value in extras.items()}}
    except Exception as exc:
        return {"exception": type(exc).__name__, "message": str(exc)}
    finally:
        R.ray.get = original_get


def main():
    from verl.experimental.reward_loop import reward_loop as R
    original = R.RewardLoopManager.compute_rm_score
    source_path = Path(inspect.getsourcefile(original))
    source_sha = e1.s2_main.file_sha(source_path)
    patched, patch_sha = local_patch(original)
    audit = Path.home() / ".local/share/rewardfail/codex-audit/20261008-t40-handoff"
    audit.mkdir(parents=True, exist_ok=True)
    records = []
    with StepGuard(audit / "guard-contract.jsonl", "local aggregation regression") as sg:
        for c in cases():
            sg.tick()
            baseline, proposal = (invoke(fn, c["outputs"], c["workers"]) for fn in (original, patched))
            expected_keys = sorted({key for r in c["outputs"] for key in r.get("reward_extra_info", {})})
            expected_cols = {key: [r.get("reward_extra_info", {}).get(key) for r in c["outputs"]] for key in expected_keys}
            expected_scores = [r["reward_score"] for r in c["outputs"]]
            if proposal != {"scores": expected_scores, "columns": expected_cols}:
                raise RuntimeError(f"proposal fails {c['name']}")
            records.append({"name": c["name"], "workers": c["workers"], "n": len(c["outputs"]),
                            "baseline": baseline, "proposal": proposal, "pass": True})
        assert e1.s2_main.file_sha(source_path) == source_sha
        result = {"source_path": str(source_path), "source_sha256": source_sha,
                  "local_patch_ast_sha256": patch_sha, "patch": "union of all extra keys; missing values None; dtype object",
                  "n": len(records), "passed": len(records),
                  "baseline_exceptions": sum("exception" in r["baseline"] for r in records),
                  "baseline_omitted_columns": sum("columns" in r["baseline"] and set(r["baseline"]["columns"]) != set(r["proposal"]["columns"]) for r in records),
                  "cases": records, "upstream_unchanged": True,
                  "boundary": "Fixed scoring outputs and local Ray transport; actual pinned batch assembly/extraction. No verifier, model or training run; no downstream masking policy verified."}
        write_atomic(ROOT / "results/s2_e1/aggregation_contract.json", json.dumps(result, ensure_ascii=False, indent=1))
    print(json.dumps({k: v for k, v in result.items() if k != "cases"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
