"""E1 matched scenes, one scene process at a time; upstream files are unchanged.

Run with nohup. A scene uses the real wrapper, manager.run_single, batch entry
and reward aggregation. Text/tokenizer and Ray transport are local substitutes;
there is no model, Ray cluster, generation or training. Threads/pool members
inside a scene are the declared experimental condition, not parallel experiments.
The core matrix is naive/64 rows: pure normal, bfc8 at positions 1/33, one IMO
at position 1, followed by normal rows. Three repeats of each heavy scene.
--eight adds matched eight-row naive/limited controls and three-heavy batches.
These scenes are separately recorded; never claim an unrun matrix.
"""
import argparse
import asyncio
import concurrent.futures as futures
import fcntl
import hashlib
import importlib
import json
import logging
import os
import signal
import sys
import threading
import time
import traceback
from collections import Counter
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "experiments"))
import s2_main
import s2_u18_diag as diag
from rewardfail.s2 import data, guard
from rewardfail.s2.stepguard import StepGuard, StepStop, write_atomic

MAIN_SHA = "1242011cddc041ea6cb19fc9a1872ebab742d8ae7e8ebd3342f6b3b8b6e2ba15"
PR_SHA = "f04f57d5cdc08d80197577c77d0bb9d47c2ddc6b4f8e80389ddf7ad3c71c8713"
MAIN_SOURCE = Path.home() / ".local/share/rewardfail/codex-audit/20261008-t40-handoff/sources/main-wrapper.py"
CHILD_CFG, CHILD_CTX = {}, {}
WRITER, TL, GENERATIONS = None, threading.local(), iter(range(1, 100000))


class Recorder:
    def __init__(self, path):
        self.f = open(path, "a", encoding="utf-8"); self.lock = threading.Lock()

    def __call__(self, ev, **kw):
        with self.lock:
            self.f.write(json.dumps({"ev": ev, "t": time.time(), "pid": os.getpid(), **kw}, ensure_ascii=False) + "\n")
            self.f.flush()


def init_child(cfg):
    global CHILD_CFG, WRITER
    CHILD_CFG = cfg
    WRITER = Recorder(Path(cfg["dir"]) / f"child-{os.getpid()}.jsonl")
    import math_verify.parser as parser
    import math_verify.grader as grader
    if cfg.get("synthetic_slow"):
        orig_extract = parser.extract_target_from_pred
        def extract(*args, **kw):
            if CHILD_CTX.get("id", "").endswith("slow"):
                time.sleep(cfg["synthetic_slow"])
            return orig_extract(*args, **kw)
        parser.extract_target_from_pred = extract
    for mod, name, param in ((parser, "parse", "parsing_timeout"), (grader, "verify", "timeout_seconds")):
        original = getattr(mod, name)
        def wrapped(*args, __orig=original, __param=param, __name=name, **kw):
            if cfg["lib"] is not None:
                kw[__param] = cfg["lib"]
            t, cpu = time.time(), time.process_time()
            if cfg["observe"]:
                WRITER("step_begin", id=CHILD_CTX.get("id"), attempt=CHILD_CTX.get("attempt"), kind=__name,
                       limit=kw.get(__param, 5), gen=CHILD_CTX.get("gen"))
            try:
                result = __orig(*args, **kw)
            except BaseException as e:
                if cfg["observe"]:
                    WRITER("step_end", id=CHILD_CTX.get("id"), attempt=CHILD_CTX.get("attempt"), kind=__name,
                           wall=time.time()-t, cpu=time.process_time()-cpu, exc=type(e).__name__)
                raise
            if cfg["observe"]:
                WRITER("step_end", id=CHILD_CTX.get("id"), attempt=CHILD_CTX.get("attempt"), kind=__name,
                       wall=time.time()-t, cpu=time.process_time()-cpu, result_type=type(result).__name__,
                       result=result if isinstance(result, (bool, int, float)) else None)
            return result
        setattr(mod, name, wrapped)
    if cfg["observe"]:
        class Handler(logging.Handler):
            def emit(self, record):
                WRITER("library_log", id=CHILD_CTX.get("id"), attempt=CHILD_CTX.get("attempt"),
                       level=record.levelname, message=str(record.msg)[:500],
                       argument_types=[type(x).__name__ for x in record.args] if isinstance(record.args, tuple) else [])
        for name in ("math_verify.parser", "math_verify.grader"):
            logger = logging.getLogger(name); logger.addHandler(Handler()); logger.setLevel(logging.DEBUG)
    WRITER("initializer", library_limit=cfg["lib"], observed=cfg["observe"])


def traced_task(ctx, fn, args, kwargs):
    global CHILD_CTX
    CHILD_CTX = ctx
    WRITER("task_begin", **ctx)
    try:
        res = fn(*args, **kwargs)
    except BaseException as e:
        WRITER("task_end", **ctx, exc=type(e).__name__); raise
    WRITER("task_end", **ctx, result=res)
    return res


def install_pool(W, cfg, rec):
    """Replace the constructor, not upstream source; the submitted scorer stays original."""
    class Pool(futures.ProcessPoolExecutor):
        def __init__(self, *args, **kw):
            kw.update(initializer=init_child, initargs=(cfg,))
            super().__init__(*args, **kw)
            self.e1_gen = next(GENERATIONS)
            rec("pool_created", gen=self.e1_gen)

        def submit(self, fn, /, *args, **kw):
            TL.attempt = getattr(TL, "attempt", 0) + 1
            ctx = {"id": getattr(TL, "rid", None), "attempt": TL.attempt, "gen": self.e1_gen}
            rec("submit", **ctx)
            fut = (super().submit(traced_task, ctx, fn, args, kw) if cfg["observe"]
                   else super().submit(fn, *args, **kw))
            original = fut.result
            def result(timeout=None):
                t = time.time(); rec("wait_begin", **ctx, timeout=timeout)
                try:
                    out = original(timeout=timeout)
                except BaseException as e:
                    rec("wait_end", **ctx, wall=time.time()-t, exc=type(e).__name__); raise
                rec("wait_end", **ctx, wall=time.time()-t, result=out)
                return out
            fut.result = result
            return fut
    W.ProcessPoolExecutor = Pool
    if hasattr(W, "_reset_pool"):
        original = W._reset_pool
        def reset(pool):
            rec("pool_reset", gen=getattr(pool, "e1_gen", None), id=getattr(TL, "rid", None))
            return original(pool)
        W._reset_pool = reset


def load_wrapper(which, source_dir):
    if which == "pr":
        from verl.utils.reward_score import math_verify as W
        if s2_main.file_sha(Path(W.__file__)) != PR_SHA:
            raise ValueError("PR source hash mismatch")
    else:
        path = Path(source_dir) / "verl_main_acad987.py"
        if s2_main.file_sha(path) != MAIN_SHA:
            raise ValueError("main source hash mismatch")
        sys.path.insert(0, str(path.parent))
        W = importlib.import_module("verl_main_acad987")
    return W


def make_batch(rows):
    import numpy as np
    import torch
    from verl.protocol import DataProto
    n = len(rows)
    values = {"data_source": np.array(["e1_fixed"]*n, dtype=object),
              "reward_model": np.array([{"ground_truth": r["gt"]} for r in rows], dtype=object),
              "extra_info": np.array([{"rid": r["id"]} for r in rows], dtype=object)}
    return DataProto.from_dict(tensors={"responses": torch.arange(n).reshape(n, 1), "prompts": torch.zeros(n, 1, dtype=torch.long),
                                       "attention_mask": torch.ones(n, 2, dtype=torch.long)}, non_tensors=values)


async def batch_score(rows, manager, W, cfg, rec):
    def score(data_source, solution_str, ground_truth, extra_info, **kw):
        TL.rid, TL.attempt = extra_info["rid"], 0
        t = time.time(); rec("score_begin", id=TL.rid)
        try:
            val = W.compute_score(solution_str, ground_truth, timeout=cfg["outer"])
        except BaseException as e:
            rec("score_end", id=TL.rid, wall=time.time()-t, exc=type(e).__name__); raise
        rec("score_end", id=TL.rid, wall=time.time()-t, score=val)
        return val
    if manager == "direct":
        return [{"reward_score": score("e1_fixed", r["out"], r["gt"], {"rid": r["id"]}),
                 "reward_extra_info": {}} for r in rows]
    from omegaconf import OmegaConf
    from verl.experimental.reward_loop.reward_manager.naive import NaiveRewardManager
    from verl.experimental.reward_loop.reward_manager.limited import RateLimitedRewardManager
    from verl.experimental.reward_loop.reward_loop import RewardLoopWorker
    class TextTokenizer:
        def decode(self, ids, **kw):
            return rows[int(ids[0])]["out"]
    config = OmegaConf.create({"reward": {"max_concurrent": 1, "timeout": 300,
                                         "custom_reward_function": {"path": "fixed local callback"}}})
    # A fresh manager per batch; the scene retains its event loop/executor and
    # wrapper pool. Following batches probe the scorer state, not manager-state recovery.
    cls = NaiveRewardManager if manager == "naive" else RateLimitedRewardManager
    mgr = cls(config, TextTokenizer(), score)
    worker = object.__new__(RewardLoopWorker)
    worker.config, worker.reward_manager = config, mgr
    batch = make_batch(rows)
    try:
        outputs = await worker.compute_score_batch(batch)
    finally:
        # The real gather can raise while sibling requests still run. Finish
        # those existing requests before the controlled following batch; log this boundary.
        left = [t for t in asyncio.all_tasks() if t is not asyncio.current_task() and not t.done()]
        if left:
            rec("drain_started_requests", n=len(left)); await asyncio.gather(*left, return_exceptions=True)
    # Execute the unchanged batch aggregation; only the Ray transport is a local result substitute.
    from verl.experimental.reward_loop import reward_loop as R
    from verl.trainer.ppo.reward import extract_reward
    control = object.__new__(R.RewardLoopManager)
    control.reward_model_manager, control.reward_manager_cls = None, cls
    control.reward_loop_workers = [SimpleNamespace(compute_score_batch=SimpleNamespace(remote=lambda chunk: outputs))]
    old_get = R.ray.get
    try:
        R.ray.get = lambda values: values
        aggregate = control.compute_rm_score(batch)
        rewards, columns = extract_reward(aggregate)
        rec("aggregate", row_ids=[r["id"] for r in rows], scores=rewards.sum(dim=-1).tolist(),
            keys=list(columns), raw_extra=[o.get("reward_extra_info", {}) for o in outputs])
    finally:
        R.ray.get = old_get
    return outputs


def scene(spec):
    d = Path(spec["dir"]); d.mkdir(parents=True, exist_ok=True)
    rec = Recorder(d / "parent.jsonl")
    W = load_wrapper(spec["wrapper"], spec["sources"])
    install_pool(W, spec, rec)
    result = {"spec": spec, "batches": []}
    for r in spec["warm"]:
        TL.rid, TL.attempt = r["id"], 0
        if W.compute_score(r["out"], r["gt"], timeout=30) != 1:
            raise RuntimeError("warmup did not score one")
    async def execute():
        asyncio.get_running_loop().set_default_executor(futures.ThreadPoolExecutor(max_workers=8))
        for name, rows in (("test", spec["rows"]), ("following", spec["following"])):
            try:
                outputs = await batch_score(rows, spec["manager"], W, spec, rec)
                result["batches"].append({"name": name, "scores": [o["reward_score"] for o in outputs],
                                          "extras": [o.get("reward_extra_info", {}) for o in outputs]})
            except BaseException as e:
                result["batches"].append({"name": name, "exception": type(e).__name__, "traceback": traceback.format_exc()})
            rec("batch_end", name=name)
    asyncio.run(execute())
    write_atomic(d / "result.json", json.dumps(result, ensure_ascii=False, indent=1))
    if W._pool is not None:
        W._pool.shutdown(wait=True)
    rec("scene_end")


def prepare(base):
    reader = data.Reader()
    # Selection depends only on previously fixed default-one IDs, not E1 results.
    old = Path.home() / ".local/share/rewardfail/stage2/runs/main-20261007-202545/default/rows.jsonl"
    ids = [r["id"] for r in s2_main.scan(old.parent) if r["class"] == "1 分"]
    chosen = sorted(ids, key=lambda i: hashlib.sha256(b"20261008\0e1normal\0" + i.encode()).digest())[:68]
    indexed = diag.tasks_for([*chosen, *diag.D1_IDS])
    def inline(i):
        t = indexed[i]; gt, outs = reader.get(t["shard"], t["row"])
        return {"id": i, "gt": gt, "out": outs[t["idx"]], "origin": t}
    inputs = {"normal": [inline(i) for i in chosen[:64]], "warm": [inline(i) for i in chosen[64:]],
              "heavy": {i: inline(i) for i in diag.D1_IDS}}
    return inputs


def specs(base, inputs, selftest=False, eight=False, repeat_three=False, controls=False):
    cases = []
    for wrapper in ("pr", "main"):
        if selftest:
            for observe in (False, True):
                cases.append(dict(wrapper=wrapper, lib=None, outer=30, observe=observe, variant=f"switch-{observe}",
                                  manager="naive", rows=[{"id": f"normal-{i}", "gt": "2", "out": "\\boxed{2}"} for i in range(8)]))
            for lib in (None, 60):
                cases.append(dict(wrapper=wrapper, lib=lib, outer=30, observe=True, variant=f"slow-{lib}", manager="direct",
                                  synthetic_slow=8, rows=[{"id": "syn-slow", "gt": "2", "out": "\\boxed{2}"}]))
            cases.append(dict(wrapper=wrapper, lib=60, outer=0.25, observe=True, variant="outer", manager="direct",
                              synthetic_slow=2, rows=[{"id": "syn-slow", "gt": "2", "out": "\\boxed{2}"}]))
        elif controls:
            # S1: sequential direct calls; C2: only change the outer deadline.
            # One bounded scene of each, not a frequency or training experiment.
            for manager, lib, outer, variants in (
                ("direct", None, 30, ("normal", "three-IMO-first")),
                ("direct", 60, 30, ("normal", "three-IMO-first")),
                ("naive", 60, 300, ("normal", "imo-first", "three-IMO-first")),
            ):
                for variant in variants:
                    rs = [dict(r) for r in inputs["normal"][:8]]
                    if variant == "imo-first":
                        rs[0] = dict(inputs["heavy"][diag.D1_IDS[0]])
                    elif variant == "three-IMO-first":
                        rs[:3] = [dict(inputs["heavy"][i]) for i in diag.D1_IDS[:3]]
                    cases.append(dict(wrapper=wrapper, lib=lib, outer=outer, observe=True,
                                      variant=variant, repeat=1, manager=manager, rows=rs))
        elif repeat_three:
            for repeat, observe in ((2, True), (3, True), (1, False)):
                rs = [dict(r) for r in inputs["normal"][:8]]
                rs[:3] = [dict(inputs["heavy"][i]) for i in diag.D1_IDS[:3]]
                cases.append(dict(wrapper=wrapper, lib=60, outer=30, observe=observe,
                                  variant="three-IMO-first", repeat=repeat, manager="naive", rows=rs))
        elif eight:
            for lib in (None, 60):
                for manager in ("naive", "limited"):
                    for variant in ("normal", "three-IMO-first"):
                        rs = [dict(r) for r in inputs["normal"][:8]]
                        if variant != "normal":
                            rs[:3] = [dict(inputs["heavy"][i]) for i in diag.D1_IDS[:3]]
                        cases.append(dict(wrapper=wrapper, lib=lib, outer=30, observe=True,
                                          variant=variant, repeat=1, manager=manager, rows=rs))
        else:
            for lib in (None, 60):
                for variant, pos, hid, repeats in (("normal", 0, None, 1), ("bfc8-first", 0, diag.D1_IDS[-1], 3),
                                                  ("bfc8-later", 32, diag.D1_IDS[-1], 3), ("imo-first", 0, diag.D1_IDS[0], 3)):
                    for repeat in range(repeats):
                        rs = [dict(r) for r in inputs["normal"]]
                        if hid: rs[pos] = inputs["heavy"][hid]
                        cases.append(dict(wrapper=wrapper, lib=lib, outer=30, observe=True, variant=variant,
                                          repeat=repeat+1, manager="naive", rows=rs))
    for n, spec in enumerate(cases):
        normals = inputs["normal"][:8] if eight or repeat_three or controls else inputs["normal"]
        spec.update(dir=str(base / f"case-{n:03d}"), sources=str(base / "source"), warm=inputs["warm"],
                    following=[{**r, "id": "following-" + r["id"]} for r in normals])
    return cases


def compact_scene(result):
    """Keep the result index small; complete strings/events stay in the raw run."""
    spec = result["spec"]
    raw = Path(spec["dir"]) / "result.json"
    assert json.loads(raw.read_text()) == result
    scalar = {k: v for k, v in spec.items() if k not in ("rows", "following", "warm")}
    scalar.update(row_count=len(spec["rows"]), following_count=len(spec["following"]), warm_count=len(spec["warm"]),
                  heavy_positions=[n+1 for n, r in enumerate(spec["rows"]) if r["id"] in diag.D1_IDS])
    batches = []
    for batch in result["batches"]:
        if "scores" in batch:
            batches.append({"name": batch["name"], "score_counts": dict(Counter(str(float(x)) for x in batch["scores"])),
                            "extra_key_counts": dict(Counter(k for extra in batch["extras"] for k in extra))})
        else:
            batches.append({"name": batch["name"], "exception": batch["exception"], "traceback": batch["traceback"]})
    return {"spec": scalar, "batches": batches, "raw_result": {"path": str(raw), "sha256": s2_main.file_sha(raw)}}


def wait_clear(read=guard.pressure, now=time.monotonic, sleep=time.sleep):
    since = None
    while True:
        pr = read()
        if pr is not None and pr != 4:
            if since is None: since = now()
            if now()-since >= 30: return
        else: since = None
        sleep(1)


def monitor(spec, require_clear=False):
    import subprocess
    d = Path(spec["dir"]); d.mkdir(parents=True, exist_ok=True)
    path = d / "spec.json"; write_atomic(path, json.dumps(spec, ensure_ascii=False, indent=1))
    g = guard.Guard(d / "guard.jsonl")
    if require_clear or guard.pressure() in (None, 4): wait_clear()
    with open(d / "scene.log", "ab") as log:
        p = subprocess.Popen([sys.executable, "-I", "-B", str(Path(__file__)), "--scene", str(path)],
                             stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
        started = time.time(); intervention = None
        while p.poll() is None:
            sample = g.sample([p.pid]); g.log("status", **sample)
            if sample["pressure"] in (None, 4):
                intervention = "pressure unreadable" if sample["pressure"] is None else "critical memory pressure"
            elif time.time()-started > 630:
                intervention = "declared 630s scene observation endpoint"
            if intervention:
                g.log("scene_intervention", why=intervention)
                os.killpg(p.pid, signal.SIGKILL); p.wait(); break
            time.sleep(0.5)
        p.wait()
    # Reap our own scene's leftover children only; never touch an unrelated process.
    orphans = s2_main.supervise._kill_group(p.pid, leader_alive=False)
    item = {"exit": p.returncode, "intervention": intervention, "seconds": time.time()-started, "orphans_killed": max(0, orphans)}
    write_atomic(d / "completion.json", json.dumps(item, indent=1))
    g.fh.close()
    return item


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--run-dir", type=Path)
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--eight", action="store_true", help="separate 16-scene eight-row manager comparison")
    ap.add_argument("--repeat-three", action="store_true", help="two traced repetitions and one child-observation-off pair")
    ap.add_argument("--controls", action="store_true", help="14 separate S1 and C2 mechanism controls")
    ap.add_argument("--scene", type=Path)
    a = ap.parse_args()
    if sum((a.selftest, a.eight, a.repeat_three, a.controls)) > 1:
        ap.error("selftest, eight-row, repetition and control measurements are distinct runs")
    if a.scene:
        return scene(json.loads(a.scene.read_text()))
    if a.run_dir is None or not a.run_dir.name.startswith("e1-"):
        ap.error("use a new e1- run directory")
    base = a.run_dir.expanduser().resolve(); base.mkdir(parents=True, exist_ok=True)
    control_lock = open(base / "control.lock", "a")
    fcntl.flock(control_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    with StepGuard(base / "guard-steps.jsonl", "E1 preparation and lock") as sg:
        if s2_main.file_sha(MAIN_SOURCE) != MAIN_SHA: raise ValueError("main source hash mismatch")
        (base / "source").mkdir(exist_ok=True)
        (base / "source/verl_main_acad987.py").write_bytes(MAIN_SOURCE.read_bytes())
        inputs = {"normal": [{"id": "n", "gt": "2", "out": "\\boxed{2}"}],
                  "warm": [{"id": f"w{i}", "gt": "1", "out": "\\boxed{1}"} for i in range(4)]} if a.selftest else prepare(base)
        cases = specs(base, inputs, a.selftest, a.eight, a.repeat_three, a.controls)
        lock = s2_main.current_lock({"what": "E1 selftest" if a.selftest else "E1 S1/C2 controls" if a.controls else "E1 repetition" if a.repeat_three else "E1 eight-row" if a.eight else "E1 core", "specs_sha256": hashlib.sha256(json.dumps(cases, sort_keys=True, ensure_ascii=False).encode()).hexdigest(),
                                    "main_sha256": MAIN_SHA, "D135": True}, sg.tick)
        lock["code_sha256"]["experiments/s2_e1.py"] = s2_main.file_sha(Path(__file__))
        lock["code_sha256"]["experiments/s2_u18_diag.py"] = s2_main.file_sha(ROOT / "experiments/s2_u18_diag.py")
        s2_main.check_lock(base, lock)
        write_atomic(base / "specs.json", json.dumps(cases, ensure_ascii=False, indent=1))
    done = []
    for n, spec in enumerate(cases):
        d = Path(spec["dir"])
        completed = d / "completion.json"
        if completed.exists():
            old = json.loads(completed.read_text())
            if old["exit"] == 0 and not old["intervention"]:
                done.append(old); continue
            raise SystemExit(f"incomplete scene {n}: retain all records; review before retrying")
        print(f"{time.strftime('%H:%M:%S')} E1 {n+1}/{len(cases)} {spec['wrapper']} {spec['variant']} lib={spec['lib']}", flush=True)
        previous = sorted(d.glob("attempt-*/completion.json"))
        interventions = sum(json.loads(p.read_text()).get("intervention") in ("pressure unreadable", "critical memory pressure") for p in previous)
        if interventions >= 2:
            raise SystemExit(f"scene {n} already had two resource interventions; review before retrying")
        attempt_n = len(list(d.glob("attempt-*"))) + 1
        while True:
            attempt = d / f"attempt-{attempt_n:02d}"
            actual = dict(spec, dir=str(attempt))
            item = monitor(actual, require_clear=interventions > 0)
            item["attempt_dir"] = str(attempt)
            if item["intervention"] in ("pressure unreadable", "critical memory pressure"):
                interventions += 1
                if interventions >= 2:
                    raise SystemExit(f"scene {n}: two recorded resource interventions; stop for review, no natural conclusion")
                print(f"scene {n}: resource intervention; wait for 30s continuously non-red before retry", flush=True)
                attempt_n += 1
                continue
            if item["intervention"] or item["exit"] != 0:
                raise SystemExit(f"scene {n} ended: {item}; retained, not treated as a natural result")
            write_atomic(completed, json.dumps(item, indent=1))
            done.append(item)
            break
    results = [json.loads((Path(c["attempt_dir"])/"result.json").read_text()) for c in done]
    output = {"run_dir": str(base), "lock": lock, "completion": done, "scenes": results,
              "boundary": "One locally invoked reward actor; fixed text/tokenizer and Ray transport substitutes. No training, no frequency estimate. Resource intervention is not a natural pool failure."}
    if a.selftest:
        checks = {}
        for w in ("pr", "main"):
            rs = [r for r in results if r["spec"]["wrapper"] == w]
            scores = {r["spec"]["variant"]: r["batches"][0].get("scores") for r in rs}
            checks[w+"-switch"] = scores["switch-False"] == scores["switch-True"] == [1.0]*8
            checks[w+"-default-timeout"] = scores["slow-None"] == [0.0]
            checks[w+"-diagnostic-completes"] = scores["slow-60"] == [1.0]
            checks[w+"-outer-timeout"] = scores["outer"] == [0.0]
            outer = next(r for r in rs if r["spec"]["variant"] == "outer")
            events = [json.loads(x) for x in (Path(outer["spec"]["dir"])/"parent.jsonl").read_text().splitlines()]
            checks[w+"-pool-policy"] = any(e["ev"] == "pool_reset" for e in events) == (w == "pr")
        output["checks"] = checks
    out = ROOT / "results/s2_e1" / ("selftest.json" if a.selftest else "report_controls.json" if a.controls else "report_repeat.json" if a.repeat_three else "report_eight.json" if a.eight else "report.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    write_atomic(base / "report.json", json.dumps(output, ensure_ascii=False, indent=1))
    index = output if a.selftest else {**output, "scenes": [compact_scene(r) for r in results],
                                     "record_layout": "compact index; full inputs and row vectors in raw report/results",
                                     "raw_report": {"path": str(base / "report.json"), "sha256": s2_main.file_sha(base / "report.json")}}
    write_atomic(out, json.dumps(index, ensure_ascii=False, indent=1))
    if a.selftest and not all(output["checks"].values()):
        raise SystemExit("E1 synthetic selftest failed")
    print(f"E1 finished: {out}", flush=True)


if __name__ == "__main__":
    try:
        main()
    except StepStop as e:
        print(e, flush=True); sys.exit(7)
