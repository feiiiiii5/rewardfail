"""E2: replay only the 100,034 answers outside the locked one-answer sample.

Original code, data and main run/report are read-only. The finite-corpus result
joins the audited main metric, not its obsolete raw reference classifications.
Question-cluster descriptions have explicit denominators, no binomial CI and
no claim about eight-answer training groups. One controller, P=1, D135, nohup.
"""
import argparse
import fcntl
import hashlib
import json
import os
import sys
from collections import Counter
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "experiments")]
import s2_main as main_run
from s2_e3 import failure_event, recover_interrupts
from rewardfail.s2 import data, report
from rewardfail.s2.stepguard import StepGuard, StepStop, write_atomic

FORMAL = ROOT / "results/s2_main/report.json"
ORIGINAL = data.STAGE2 / "runs/main-20261007-202545"
SEED = b"rewardfail-e2-2026-10-08"


def build(mapping):
    tasks, meta, main_ids, keys, positions = [], {}, set(), set(), set()
    for r in mapping:
        key, k, pick = r["key"], r["k"], r["pick"]
        if len(bytes.fromhex(key)) != 32 or key in keys or (r["shard"], r["row"]) in positions:
            raise ValueError("duplicate or malformed question identity")
        if not 1 <= k <= 6 or not 0 <= pick < k or r["row"] < 0:
            raise ValueError("invalid locked answer inventory")
        keys.add(key); positions.add((r["shard"], r["row"]))
        for idx in range(k):
            rid = f"m-{key[:16]}" if idx == pick else f"e2-{key[:16]}-{idx}"
            if rid in meta:
                raise ValueError("answer identifier collision")
            meta[rid] = {"key": key, "idx": idx, "k": k}
            if idx == pick:
                main_ids.add(rid)
            else:
                tasks.append({"id": rid, "shard": r["shard"], "row": r["row"], "idx": idx})
    return tasks, meta, main_ids


def reference_ids(ids, dcls, meta, control_n=1000):
    ones = [i for i in ids if report.default_verdict(dcls.get(i)) == 1]
    def rank(i):
        m = meta[i]
        return hashlib.sha256(SEED + b"\0refone\0" + bytes.fromhex(m["key"]) + bytes([m["idx"]])).digest()
    controls = sorted(ones, key=lambda i: (rank(i), i))[:control_n]
    control_set = set(controls)
    return [i for i in ids if report.default_verdict(dcls.get(i)) != 1 or i in control_set], controls


def metric(ids, dcls, rcls):
    flips, undecided, reasons = [], [], Counter()
    for i in ids:
        dv = report.default_verdict(dcls.get(i))
        rv = report.ref_verdict(rcls.get(i))
        if dv is None:
            undecided.append(i); reasons["default: " + str(dcls.get(i))] += 1
        elif dv == 0 and rv is None:
            undecided.append(i); reasons["reference: " + str(rcls.get(i))] += 1
        elif dv == 0 and rv == 1:
            flips.append(i)
    n, k, u = len(ids), len(flips), len(undecided)
    return {"n": n, "k": k, "u": u, "k_over_n": k / n if n else None,
            "k_plus_u_over_n": (k + u) / n if n else None,
            "k_ids": flips, "u_ids": undecided, "u_reasons": dict(reasons)}


def group_description(rows, meta, tick=lambda: None):
    """Observed events; missing/invalid observations cannot count as no-event.

    The conditional answer denominator counts directed pairs whose anchor is
    an observed failure, excluding singleton questions. Unknown other endpoints
    bound the descriptive numerator only. This is not a correlation estimator.
    """
    groups, seen, cls, events = {}, set(), Counter(), Counter()
    for pos, row in enumerate(rows):
        if pos % 2000 == 0: tick()
        rid = row["id"]
        if rid in seen or rid not in meta:
            raise ValueError("duplicate/unmapped observed answer")
        seen.add(rid); m = meta[rid]
        g = groups.setdefault(m["key"], {"n": 0, "expected": m["k"], "events": [], "unknown": []})
        if g["expected"] != m["k"]:
            raise ValueError("inconsistent question size")
        g["n"] += 1; cls[row["class"]] += 1
        event = failure_event(row)
        unknown = bool(row.get("problems")) or report.default_verdict(row["class"]) is None
        if event:
            g["events"].append(rid)
            timed, errors, _slow, outcomes = report.features(row)
            for kind in timed: events["timeout:" + kind] += 1
            for kind in errors: events["error:" + kind] += 1
            for kind in set(outcomes) & {"outer_timeout", "lib_timeout_exc", "broken_pool"}: events[kind] += 1
        elif unknown:
            g["unknown"].append(rid)
    if seen != set(meta) or any(g["n"] != g["expected"] for g in groups.values()):
        raise ValueError("incomplete finite-corpus default observations")
    eligible, affected, multi, denom, numer, uncertain = 0, 0, 0, 0, 0, 0
    sizes, cases = Counter(), []
    for key, g in groups.items():
        n, e, q = g["n"], len(g["events"]), len(g["unknown"])
        sizes[str(n)] += 1
        if e or q:
            cases.append({"key": key, "n": n, "event_ids": g["events"], "unknown_no_event_ids": g["unknown"]})
        if n < 2: continue
        eligible += 1; affected += e > 0; multi += e >= 2
        denom += e * (n - 1); numer += e * (e - 1); uncertain += e * q
    return {"n_answers": len(seen), "n_questions": len(groups), "question_sizes": dict(sizes),
            "default_classes": dict(cls), "event_types_overlapping": dict(events),
            "observed_event_answers": sum(len(g["events"]) for g in groups.values()),
            "unknown_no_event_answers": sum(len(g["unknown"]) for g in groups.values()),
            "eligible_multi_answer_questions": eligible, "event_questions_among_eligible": affected,
            "multiple_event_questions": multi,
            "multiple_event_question_fraction": multi / affected if affected else None,
            "directed_other_answer_pairs": denom, "observed_both_event_pairs": numer,
            "unknown_other_endpoint_pairs": uncertain,
            "other_answer_event_descriptive_range": [numer / denom, (numer + uncertain) / denom] if denom else None,
            "affected_questions": cases}


def checked_rows(d, wanted, tick=lambda: None):
    seen = set()
    for row in main_run.scan(d, tick):
        rid = row["id"]
        if rid not in wanted or rid in seen:
            raise ValueError("unexpected or repeated result row")
        seen.add(rid)
        yield row
    if seen != set(wanted):
        raise ValueError("missing final result rows")


def synthetic():
    tasks = [{"id": "syn-one", "gt": "2", "out": "\\boxed{2}"},
             {"id": "syn-zero", "gt": "2", "out": "\\boxed{3}"},
             {"id": "syn-slow", "gt": "2", "out": "\\boxed{2}", "inject": {"slow": "pred_parse", "sec": 8}}]
    meta = {t["id"]: {"key": hashlib.sha256(t["id"].encode()).hexdigest(), "idx": 0, "k": 1} for t in tasks}
    return tasks, meta


def execute(base, out, selftest=False):
    opts = SimpleNamespace(P=1, child_limit=None)
    with StepGuard(base / "guard-steps.jsonl", "E2 input and version lock") as sg:
        if selftest:
            tasks, meta = synthetic(); main_ids = set()
        else:
            tasks, meta, main_ids = build(data.load_map())
            if (len(tasks), len(main_ids), len(meta)) != (100034, 93733, 193767):
                raise ValueError("fixed complement inventory changed")
        tasks_sha = hashlib.sha256(json.dumps(tasks, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
        baseline = {"formal_sha256": main_run.file_sha(FORMAL),
                    "default_rows_sha256": main_run.file_sha(ORIGINAL / "default/rows.jsonl")}
        old = json.loads(FORMAL.read_text())
        if (old["main_metric"]["n"], old["main_metric"]["k"], old["main_metric"]["u"]) != (93733, 1, 18):
            raise ValueError("audited baseline changed; review before joining")
        pre = {"experiment": "E2 synthetic" if selftest else "E2 complement", "tasks_sha256": tasks_sha,
               "n": len(tasks), "seed": SEED.decode(), "P": 1, "reference_control_n": 1000,
               "metric": "finite-corpus counts; no pooled independent-binomial confidence bounds", "baseline": baseline}
        lock = main_run.current_lock(pre, sg.tick)
        for name in ("s2_e2.py", "s2_e3.py"):
            lock["code_sha256"]["experiments/" + name] = main_run.file_sha(ROOT / "experiments" / name)
        main_run.check_lock(base, lock)
    by_id = {t["id"]: t for t in tasks}; ids = list(by_id)
    recover_interrupts(base / "default")
    passes = {"default": main_run.run_pass(base, "default", tasks, "observe", [], opts)}
    with StepGuard(base / "guard-steps.jsonl", "E2 reference selection") as sg:
        dcls = {r["id"]: r["class"] for r in checked_rows(base / "default", by_id, sg.tick)}
        refs, controls = reference_ids(ids, dcls, meta)
    recover_interrupts(base / "reference")
    passes["reference"] = main_run.run_pass(base, "reference", [by_id[i] for i in refs], "reference", [], opts)
    with StepGuard(base / "guard-steps.jsonl", "E2 finite-corpus analysis") as sg:
        rrows = {r["id"]: r for r in checked_rows(base / "reference", refs, sg.tick)}
        rcls = {i: r["class"] for i, r in rrows.items()}
        extension = metric(ids, dcls, rcls)
        check = {"n": len(controls), "score_one": sum(report.ref_verdict(rcls[i]) == 1 for i in controls),
                 "not_one_ids": [i for i in controls if report.ref_verdict(rcls[i]) != 1]}
        if selftest:
            rows = list(checked_rows(base / "default", by_id, sg.tick))
            checks = {"n": extension["n"] == 3, "k": extension["k"] == 1, "u": extension["u"] == 0,
                      "reference_controls": check["n"] == 1 and check["score_one"] == 1,
                      "observations_complete": all(not r["problems"] for r in [*rows, *rrows.values()])}
            result = {"run_dir": str(base), "lock": lock, "passes": passes, "checks": checks,
                      "extension": extension, "groups": group_description(rows, meta, sg.tick)}
            if not all(checks.values()): raise RuntimeError("E2 synthetic mechanism failed")
        else:
            if (len(old["k_ids"]) != 1 or len(old["u_detail"]) != 18
                    or not (set(old["k_ids"]) | set(old["u_detail"])) <= main_ids):
                raise ValueError("formal baseline identities do not match mapping")
            def all_defaults():
                original_counts = Counter()
                for r in checked_rows(ORIGINAL / "default", main_ids, sg.tick):
                    original_counts[r["class"]] += 1
                    yield r
                if dict(original_counts) != old["default_classes"]:
                    raise ValueError("baseline default class counts differ from audited report")
                yield from checked_rows(base / "default", by_id, sg.tick)
            groups = group_description(all_defaults(), meta, sg.tick)
            k, u, n = 1 + extension["k"], 18 + extension["u"], len(meta)
            result = {"run_dir": str(base), "lock": lock, "passes": passes, "extension": extension,
                      "reference_control": check, "formal_main_metric_reused": old["main_metric"],
                      "all_answers": {"n": n, "k": k, "u": u, "k_over_n": k / n, "k_plus_u_over_n": (k + u) / n},
                      "question_descriptions": groups,
                      "boundaries": ["Finite selected/filtered corpus, no population or training failure rate.",
                                     "Original sample and complement replayed at different times; load/cache and shared references confound dependence.",
                                     "Reference is the same verifier at longer limits, not mathematical truth.",
                                     "All-answer counts do not change the original main report or decision thresholds."]}
        if baseline != {"formal_sha256": main_run.file_sha(FORMAL),
                        "default_rows_sha256": main_run.file_sha(ORIGINAL / "default/rows.jsonl")}:
            raise RuntimeError("original baseline changed during extension")
        write_atomic(base / "report.json", json.dumps(result, ensure_ascii=False, indent=1))
        write_atomic(out, json.dumps(result, ensure_ascii=False, indent=1))
    print(json.dumps({"extension": result["extension"], "checks": result.get("checks"),
                      "all_answers": result.get("all_answers")}, ensure_ascii=False), flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--run-dir", type=Path, required=True)
    ap.add_argument("--out", type=Path, default=ROOT / "results/s2_e2/report.json")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args(); base, out = a.run_dir.expanduser().resolve(), a.out.expanduser().resolve()
    if not base.is_relative_to(data.STAGE2 / "runs") or not base.name.startswith("e2-"):
        ap.error("use a new e2-* run under the stage2 runs directory")
    if not out.is_relative_to(ROOT / "results/s2_e2") or out.suffix != ".json":
        ap.error("output must be inside the new results/s2_e2 directory")
    base.mkdir(parents=True, exist_ok=True); out.parent.mkdir(parents=True, exist_ok=True)
    with (base / "controller.lock").open("a+") as fh:
        try: fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError: ap.error("the same measurement already has a running controller")
        fh.seek(0); fh.truncate(); fh.write(str(os.getpid()) + "\n"); fh.flush()
        execute(base, out, a.selftest)


if __name__ == "__main__":
    try: main()
    except StepStop as e:
        print(f"resource intervention: {e}", flush=True); sys.exit(7)
