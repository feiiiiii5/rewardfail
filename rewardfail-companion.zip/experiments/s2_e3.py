"""E3: selected human-labelled extracted answers, not full generated responses.

The existing, locked s2_worker already accepts inline gt/out tasks. No worker,
scorer, observation or old-analysis file is changed. Raw/boxed presentations and
default/reference limits are separate, exhaustive passes; already boxed answers
reuse the corresponding raw result with an explicit alias, not an extra trial.
One scoring worker; D135 guard; launch with nohup. Results cannot update s2_main.
"""
import argparse
import csv
import hashlib
import io
import json
import re
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments"))
import psutil
import s2_main as main_run
from rewardfail.s2 import report
from rewardfail.s2.stepguard import StepGuard, StepStop, write_atomic

CSV = Path.home() / ".local/share/rewardfail/data/rlvr_group_correlation/data/gold/gold_set_1p5b_manual_labeled.csv"
CSV_SHA = "90fca106cb07f031a7ac169e009e6ab9cc0839126912218d0763b0ab6e037005"


def read_csv(path, *, locked=True):
    raw = Path(path).read_bytes()
    if locked and hashlib.sha256(raw).hexdigest() != CSV_SHA:
        raise ValueError("CSV differs from the downloaded fixed source")
    rows = list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig"), newline="")))
    required = {"group_id", "prompt_id", "cid", "gt_answer", "raw_answer", "human_label", "primary_cat", "model",
                "double_annotate", "annotator2_label"}
    if not rows or not required <= rows[0].keys():
        raise ValueError("missing CSV fields or empty input")
    keys, prompts = set(), {}
    for n, row in enumerate(rows):
        if None in row or any(row[k] is None for k in required):
            raise ValueError(f"malformed CSV row {n}")
        key = row["group_id"], row["cid"]
        if key in keys or row["human_label"] not in ("0", "1"):
            raise ValueError(f"duplicate answer or invalid label at row {n}")
        if row["double_annotate"] not in ("True", "False") or (row["double_annotate"] == "True" and
                                                              row["annotator2_label"] not in ("0", "1")):
            raise ValueError(f"invalid second annotation at row {n}")
        if row["group_id"] in prompts and prompts[row["group_id"]] != row["prompt_id"]:
            raise ValueError("a group refers to different prompts")
        prompts[row["group_id"]] = row["prompt_id"]
        keys.add(key)
        row["id"] = f"e3-{n:05d}"
    if locked and (len(rows), len(prompts), sum(r["human_label"] == "1" for r in rows)) != (5556, 3041, 2822):
        raise ValueError("fixed input inventory does not match")
    return rows


def tasks_for(rows, presentation):
    if presentation not in ("raw", "boxed"):
        raise ValueError("unknown presentation")
    out, aliases = [], []
    for r in rows:
        answer = r["raw_answer"]
        if presentation == "boxed" and "\\boxed" in answer:
            aliases.append(r["id"])
            continue
        out.append({"id": r["id"], "gt": r["gt_answer"],
                    "out": answer if presentation == "raw" else "\\boxed{" + answer + "}"})
    return out, aliases


def recover_interrupts(d, alive=None):
    """Count an unfinished attempt even if the previous supervisor itself died.

    Compare progress/results within each launch, not across launches. An earlier
    unfinished attempt remains an interruption after a later attempt succeeds.
    Persist a launch identity inside interrupts.json to make recovery idempotent.
    Never classify an active worker as interrupted. No old run is passed here.
    """
    d = Path(d)
    def is_alive(name):
        for p in psutil.process_iter(["cmdline"]):
            args = p.info.get("cmdline") or []
            if "--worker" in args and args[args.index("--worker") + 1] == name and str(d) in args:
                return True
        return False
    alive = alive or is_alive
    path = d / "interrupts.json"
    state = json.loads(path.read_text()) if path.exists() else {}
    recovered = []
    for f in sorted(d.glob("progress-*.jsonl")):
        name = f.stem[len("progress-"):]
        if alive(name):
            raise RuntimeError(f"worker {name} is still running; cannot resume")
        done_file = d / f"results-{name}.jsonl"
        done = {json.loads(x)["id"] for x in done_file.read_text().splitlines() if x.strip()} if done_file.exists() else set()
        started = {json.loads(x)["id"] for x in f.read_text().splitlines() if x.strip()}
        launch = re.sub(r"w\d+$", "", name)
        for rid in sorted(started - done):
            prev = state.setdefault(rid, [])
            if any(x.get("launch") == launch for x in prev):
                continue
            prev.append({"launch": launch, "why": "previous supervisor ended before recording this unfinished attempt",
                         "recovered_from": f.name})
            recovered.append({"id": rid, "launch": launch})
    if recovered:
        write_atomic(path, json.dumps(state, ensure_ascii=False, indent=1))
    return recovered


def failure_event(row):
    timed, errs, _slow, outcomes = report.features(row)
    return bool(timed or errs or set(outcomes) & {"outer_timeout", "lib_timeout_exc", "broken_pool"})


def tally(rows, results):
    total, by_cat, affected = Counter(), defaultdict(Counter), []
    for r in rows:
        s = results.get(r["id"])
        if s is None:
            raise ValueError("a final answer is missing")
        cls, label = s["class"], int(r["human_label"])
        complete = (not s["problems"] and s["score"] in (0, 1) and s.get("exc") is None and
                    cls not in ("观测不完整（未裁定）", "本机预算终止（未裁定）") and not cls.startswith("未裁定"))
        event = failure_event(s)
        obs = complete and cls in ("1 分", "正常 0")
        counts = {"n": 1, "human_positive": label, "failure_event": int(event),
                  "incomplete_or_intervened": int(not complete),
                  "fallback_one": int(event and complete and s["score"] == 1),
                  "failure_zero_human_one": int(event and complete and s["score"] == 0 and label == 1),
                  "normal_disagreement": int(obs and s["score"] != label),
                  "normal_false_negative": int(obs and s["score"] == 0 and label == 1),
                  "normal_false_positive": int(obs and s["score"] == 1 and label == 0)}
        total.update(counts)
        by_cat[r["primary_cat"]].update(counts)
        if event or not complete:
            affected.append({"id": r["id"], "label": label, "category": r["primary_cat"], "result": s})
    return {"counts": dict(total), "by_sampling_category": {k: dict(v) for k, v in sorted(by_cat.items())},
            "failure_cost_per_all": total["failure_zero_human_one"] / total["n"],
            "failure_cost_per_human_positive": total["failure_zero_human_one"] / total["human_positive"] if total["human_positive"] else None,
            "affected_rows": affected}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--run-dir", type=Path, required=True)
    ap.add_argument("--out", type=Path, default=ROOT / "results/s2_e3/report.json")
    ap.add_argument("--selftest", action="store_true", help="only synthetic worker/control checks")
    a = ap.parse_args()
    a.out = a.out.expanduser().resolve()
    if "s2_main" in a.out.parts or "s2_u18" in a.out.parts:
        ap.error("old reports are read-only")
    base = a.run_dir.expanduser().resolve()
    if base.name.startswith(("main-", "u18-", "pilot-", "selftest-")):
        ap.error("old measurement directory is read-only; use a new e3 directory")
    base.mkdir(parents=True, exist_ok=True)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    opts = SimpleNamespace(P=1, child_limit=None)
    with StepGuard(base / "guard-steps.jsonl", "E3 input and lock") as sg:
        rows = read_csv(CSV)
        tasks, aliases = {p: tasks_for(rows, p)[0] for p in ("raw", "boxed")}, tasks_for(rows, "boxed")[1]
        if a.selftest:
            tasks = {"raw": [{"id": "syn-one", "gt": "2", "out": "2"}, {"id": "syn-zero", "gt": "2", "out": "3"},
                             {"id": "syn-slow", "gt": "2", "out": "The answer is \\boxed{2}",
                              "inject": {"slow": "pred_parse", "sec": 8}}]}
        pre = {"experiment": "E3 selftest" if a.selftest else "E3", "csv_sha256": main_run.file_sha(CSV),
               "tasks_sha256": {p: hashlib.sha256(json.dumps(t, ensure_ascii=False, sort_keys=True).encode()).hexdigest() for p, t in tasks.items()},
               "boxed_aliases": aliases, "P": 1, "modes": ["observe", "reference"]}
        lock = main_run.current_lock(pre, sg.tick)
        lock["code_sha256"]["experiments/s2_e3.py"] = main_run.file_sha(Path(__file__))
        main_run.check_lock(base, lock)
    passes = {}
    for p, ts in tasks.items():
        for mode in ("observe", "reference"):
            name = f"{p}-{mode}"
            recover_interrupts(base / name)
            passes[name] = main_run.run_pass(base, name, ts, mode, [], opts)
        if a.selftest:
            off = base / "off"
            recover_interrupts(off)
            from rewardfail.s2 import supervise
            simple = tasks["raw"][:2]
            result = supervise.run_phase(off, simple, 1, worker_args=["--mode", "off"], label="off", row_limit=150)
            if result.get("aborted"):
                raise RuntimeError("observation-off control aborted")
            scored = {json.loads(x)["id"]: json.loads(x)["score"] for f in off.glob("results-*.jsonl") for x in f.read_text().splitlines()}
            obs = {r["id"]: r for r in main_run.scan(base / "raw-observe")}
            ref = {r["id"]: r for r in main_run.scan(base / "raw-reference")}
            checks = {"inline_and_off_control": scored == {"syn-one": 1.0, "syn-zero": 0.0} and all(obs[i]["score"] == s for i, s in scored.items()),
                      "slow_default_zero": obs["syn-slow"]["score"] == 0 and "超时" in obs["syn-slow"]["class"],
                      "slow_reference_one": ref["syn-slow"]["score"] == 1,
                      "complete_observation": all(not r["problems"] for r in [*obs.values(), *ref.values()])}
            result = {"run_dir": str(base), "lock": lock, "checks": checks, "passes": passes}
            write_atomic(a.out, json.dumps(result, ensure_ascii=False, indent=1))
            if not all(checks.values()):
                raise RuntimeError("synthetic mechanism selftest failed")
            print(json.dumps(checks), flush=True)
            return
    with StepGuard(base / "guard-steps.jsonl", "E3 analysis") as sg:
        results = {name: {r["id"]: r for r in main_run.scan(base / name, sg.tick)} for name in passes}
        for mode in ("observe", "reference"):
            for rid in aliases:
                results[f"boxed-{mode}"][rid] = results[f"raw-{mode}"][rid]
        groups = Counter(r["group_id"] for r in rows)
        dbl = [r for r in rows if r["double_annotate"] == "True"]
        result = {"run_dir": str(base), "lock": lock, "inventory": {"n": len(rows), "groups": len(groups), "full_eight_groups": sum(v == 8 for v in groups.values()),
                   "already_boxed_reused": len(aliases), "double_annotations": len(dbl), "double_disagreements": sum(r["human_label"] != r["annotator2_label"] for r in dbl)},
                  "passes": passes, "analysis": {name: tally(rows, rs) for name, rs in results.items()},
                  "boundaries": ["Selected and stratified extracted answers; not natural full-response prevalence.",
                                 "Human labels and the longer-time reference are separate comparators, not mathematical proof.",
                                 "Counts overlap; unknown/intervened rows are reported separately.", "No GRPO training or population group-error estimate."]}
        write_atomic(base / "report.json", json.dumps(result, ensure_ascii=False, indent=1))
        write_atomic(a.out, json.dumps(result, ensure_ascii=False, indent=1))
    print(json.dumps({k: v["counts"] for k, v in result["analysis"].items()}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    try:
        main()
    except StepStop as e:
        print(f"resource intervention: {e}", flush=True)
        sys.exit(7)
