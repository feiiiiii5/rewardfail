"""主测量的调度包装：按段设定并发（申请季 D132，用户 2026-10-07：按实际运行表现充分使用本机资源，
不因静态公式算出零并发或保守预算停工）。接替 experiments/s2_main_userP1.py（只做“公式 P=0 时取 P=1”）。

为什么另写包装而不改 s2_main.py：执行文件在版本锁里，Codex 审过的是 9a88991 的版本；这里只替换调度用的
choose_P，判分、种子、样本、指标、门槛、未裁定规则与续跑核对全部沿用原文件。

各段的并发（Claude 的中间决定，理由记在方案里）：
- reference：P=REF_P。参照给每行 300 秒宽时限，用来得出参照裁定，CPU 竞争对它的影响远小于对计时口径的影响；
- 其他各段（default、limit2s、limit10s、replay1–3、retest）：P=1。这几段量的就是超时与异常，并发引入的 CPU 竞争
  会混进被测量本身；保持与默认段（P=1）同一条件，结果才可比。
方案第 6 节公式的值照常算出并记在 P_info（formula_P），只作记录，不再拦停；每段的 P_info 另记 override 与
schedule，写进 pass_done.json 和报告。整机保护（guard.py、stepguard.py）照常：内存压力、交换区增长、可用内存过低等
仍会暂停或停止，停止后从断点续跑，必要时降低 REF_P（环境变量 S2_REF_P）。
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import s2_main  # noqa: E402

REF_P = int(os.environ.get("S2_REF_P", "3"))
NOTE = "申请季 D132：按段设定并发，公式值只记录不拦停；整机保护照常（experiments/s2_main_sched.py）"
_choose, _run_pass = s2_main.choose_P, s2_main.run_pass
_current = {"name": None}


def choose_P(a):
    _, info = _choose(a)
    P = REF_P if _current["name"] == "reference" else 1
    return P, dict(info, override=NOTE, schedule={"reference": REF_P, "其他各段": 1})


def run_pass(base, name, tasks, mode, extra, a):
    _current["name"] = name
    return _run_pass(base, name, tasks, mode, extra, a)


s2_main.choose_P, s2_main.run_pass = choose_P, run_pass

if __name__ == "__main__":
    s2_main.main()
