"""主测量的调度包装：方案第 6 节公式算出 P=0 时仍按 P=1 开一条（用户 2026-10-07 21:2x 指示：
“apple有内存管理机制，先跑试一下，我会来监控”）。

为什么另写包装而不改 s2_main.py：s2_main.py 等执行文件在版本锁里，Codex 审过的是 9a88991 的版本；这里只替换
调度用的 choose_P，判分、种子、样本、指标、门槛、未裁定规则与续跑核对全部沿用原文件。
- 公式给出 P≥1 时不干预，结果与直接运行 s2_main.py 相同；
- 公式给出 P=0 时取 P=1（--P 仍是上限），并在 P_info 里记 override 与原公式值，写进每段的 pass_done.json 和报告；
- 整机保护（guard.py、stepguard.py）照常运行：内存压力、交换区增长、可用内存过低等条件照样暂停或停止。
这偏离了 Codex 第 17.5 节“公式给出 P=0 就停”的继续条件，须交 Codex 审核时说明。
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import s2_main  # noqa: E402

NOTE = "用户 2026-10-07 指示：公式 P=0 时仍按 P=1 试跑，用户自行监控；整机保护照常（experiments/s2_main_userP1.py）"
_choose = s2_main.choose_P


def choose_P(a):
    P, info = _choose(a)
    if P < 1 <= a.P:
        P, info = 1, dict(info, override=NOTE)
    return P, info


s2_main.choose_P = choose_P

if __name__ == "__main__":
    s2_main.main()
