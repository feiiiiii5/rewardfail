"""第二阶段资源试跑与真实回答上的开关对照（方案第 4–6 节；Codex 复核第 11.2 节第 1、3 条）。

只估资源、只核观测层不改分：结果单列，不并入主样本，不据此改样本量、种子或判分规则。只用主样本以外的回答
（rewardfail/s2/data.py 的 pilot_set：按分片和答案类型分层，每片约 100 条，按种子哈希排好）。

阶段（各一个运行目录，原始记录在 ~/.local/share/rewardfail/stage2/runs/pilot-时间/）：
 on   前 500 条，观测开启，P=1。量一条流水线（测量进程加它的进程池子进程）的常驻内存、每行耗时、新池启动开销。
 off  同样 500 条，观测关闭，P=1。方案第 4 节的开关对照：逐行分数或异常必须完全相同，耗时差别照报。
 par  其余各条，观测开启，P 按 on 段实测的内存用方案第 6 节的公式算（guard.plan_parallel）；
      量 P 条流水线同时跑时的合计内存、交换区、负载与吞吐。算出来 P 小于 1 就不跑，照报。
 ref  on、par 两段里默认得 0 或以异常结束的行，用参照设置（库内解析、比较各 60 秒，外层 300 秒）再判一次。
最后按实测估主测量各段耗时；合计超过 24 小时照报，按方案第 6 节分批、检查点续跑，不改研究规则。
长尾只给带假设的情景，不是主测量的上界（Codex 10-07 审核第 13.2 节第 6 项，见 estimate）。
结果写 results/s2_rev1/pilot/report.json（10-07 修订后；修订前的 results/s2_pilot/report.json 原样保留）。
"""
import json
import statistics
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import psutil  # noqa: E402

from rewardfail.s2 import analyze, data, guard as guard_mod, report as report_mod, supervise  # noqa: E402
from rewardfail.s2.envinfo import env  # noqa: E402

GiB, MiB = 1 << 30, 1 << 20
N_SWITCH = 500
MAIN_N = 93_733  # 主样本题数（方案第 5 节；plan/sample_map.json）
CHILD_LIMIT = 3 * GiB
STATUS_EVERY = 2  # 试跑时整机保护每 2 秒记一次分角色内存（主测量用默认 10 秒）
FOLLOW_RANDOM = 0.01  # 方案第 4 节：时限敏感度的随机 1%、重测的随机 1%
REF_CHECK_ONES = 1000  # 方案第 4 节：预先随机抽 1,000 条默认得 1 的行跑参照


def q(xs, p):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, max(0, round(p * (len(xs) - 1))))] if xs else None


def dist(xs, nd=4):
    xs = [x for x in xs if x is not None]
    if not xs:
        return {"n": 0}
    r = lambda v: round(v, nd)  # noqa: E731
    return {"n": len(xs), "mean": r(statistics.fmean(xs)), "p50": r(q(xs, .5)), "p90": r(q(xs, .9)),
            "p99": r(q(xs, .99)), "max": r(max(xs))}


def gib(v):
    return None if v is None else round(v / GiB, 3)


def roles(run_dir):
    """从整机保护的状态记录里取分角色常驻内存：调度、各测量进程、各测量进程的进程池子进程。"""
    out = []
    for f in sorted(Path(run_dir).glob("guard-*.jsonl")):
        for e in analyze._jsonl(f):
            if e["ev"] == "status" and e.get("roles") and e["roles"]["workers"]:
                out.append(e)
    return out


def memory(run_dir):
    st = roles(run_dir)
    pipe, child, worker, sup, total, n_child = [], [], [], [], [], []
    for e in st:
        r = e["roles"]
        sup.append(r["sup"])
        total.append(e["total"])
        for wpid, wrss in r["workers"]:
            kids = [rss for pid, ppid, rss in r["pool"] if ppid == wpid]
            worker.append(wrss)
            child += kids
            n_child.append(len(kids))
            pipe.append(wrss + sum(kids))
    return {"samples": len(st), "pipeline": dist(pipe, 0), "worker": dist(worker, 0), "pool_child": dist(child, 0),
            "pool_children_per_worker": dist(n_child, 2), "supervisor": dist(sup, 0), "total": dist(total, 0),
            "load1": dist([e.get("load1") for e in st], 2),
            "swap": dist([e.get("swap") for e in st], 0), "avail": dist([e.get("avail") for e in st], 0),
            "pressure": dict(Counter(str(e.get("pressure")) for e in st))}


def stage(base, name, tasks, P, mode, label):
    run_dir = base / name
    t0 = time.time()
    res = supervise.run_phase(run_dir, tasks, P, worker_args=["--mode", mode], label=label,
                              guard_kw={"child_limit": CHILD_LIMIT, "status_every": STATUS_EVERY})
    elapsed = time.time() - t0
    run = analyze.load_run(run_dir)
    rows = {k: v for k, v in analyze.summarize(run).items() if not str(k).startswith("warm-")}
    done = [v for v in rows.values() if v["result"] is not None]
    warms = [w for w in run["warms"] if str(w["id"]).startswith("warm-")]
    starts = [w for w in run["warms"] if w.get("ev") == "worker_start"]
    old_alive = []
    for e in run["parent"]:
        if e["ev"] == "worker_end":
            old_alive += [pid for pid, code in e["procs"].items() if code is None]
    child_steps = [s for v in done for a in v["attempts"] for s in ((a.get("child") or {}).get("steps") or [])]
    info = {
        "mode": mode, "P": P, "tasks": len(tasks), "done": len(done), "supervise": res,
        "elapsed_s": round(elapsed, 1), "rows_per_hour": round(len(done) / elapsed * 3600, 1) if elapsed else None,
        "row_wall_s": dist([v["result"].get("wall") for v in done]),
        "row_parent_cpu_s": dist([v["result"].get("parent_cpu") for v in done]),
        "child_task_wall_s": dist([a["child"]["task_end"]["wall"] for v in done for a in v["attempts"]
                                   if a.get("child") and a["child"].get("task_end")]),
        "child_task_cpu_s": dist([a["child"]["task_end"]["cpu"] for v in done for a in v["attempts"]
                                  if a.get("child") and a["child"].get("task_end")]),
        "step_wall_s": {k: dist([s.get("wall") for s in child_steps if s["kind"] == k and s.get("end")])
                        for k in ("gold_parse", "pred_parse", "compare")},
        "steps_over_1s": sum(1 for s in child_steps if s.get("end") and s["wall"] > 1),
        "child_fp_at_start": dist([a["child"]["task_start"].get("fp") for v in done for a in v["attempts"]
                                   if a.get("child") and a["child"].get("task_start")], 0),
        "child_peak_fp": dist([a["child"]["task_end"].get("fp_max") for v in done for a in v["attempts"]
                               if a.get("child") and a["child"].get("task_end")], 0),
        "child_peak_rss": dist([a["child"]["task_end"].get("maxrss") for v in done for a in v["attempts"]
                                if a.get("child") and a["child"].get("task_end")], 0),
        "worker_fp": dist([v["result"].get("parent_fp") for v in done], 0),
        "worker_peak_fp": dist([v["result"].get("parent_fp_max") for v in done], 0),
        "flags": {k: v["flags"] for k, v in rows.items() if v.get("flags")},
        "worker_import_s": [s.get("import_s") for s in starts],
        "warmups": {"n": len(warms), "wall_s": dist([w.get("wall") for w in warms]),
                    "first_per_worker_s": [w.get("wall") for w in warms if str(w["id"]).endswith("-1")]},
        "classes": dict(Counter(v["class"] for v in rows.values())),
        "problems": {k: v["problems"] for k, v in rows.items() if v["problems"]},
        "old_pool_procs_without_exit": old_alive,
        "stats": analyze.run_stats(run, rows),
        "memory": memory(run_dir),
    }
    return info, rows


def switch_compare(on, off):
    diff, paired = [], []
    for k, a in on.items():
        b = off.get(k)
        ra, rb = a["result"], (b or {}).get("result")
        if ra is None or rb is None:
            diff.append({"id": k, "on": ra and (ra["score"], ra["exc"]), "off": rb and (rb["score"], rb["exc"])})
            continue
        if (ra["score"], ra["exc"]) != (rb["score"], rb["exc"]):
            diff.append({"id": k, "on": (ra["score"], ra["exc"]), "off": (rb["score"], rb["exc"])})
        paired.append(ra["wall"] - rb["wall"])
    return {"rows": len(on), "mismatch": diff, "pass": not diff and len(on) == len(off),
            "wall_on_minus_off_s": dist(paired)}


def tail_scenarios(warm, events, n, P):
    """长尾只作带假设的情景，不是上界（Codex 10-07 审核第 13.2 节第 6 项）。试跑回答按分片和题型定额抽自主样本以外，
    不含只有一条回答的题，零事件的单侧 95% 模型界不能直接当成主样本的事件率上界；这里另外假设主总体与试跑同分布、
    各行独立。每条事件行在七段里各跑一次（默认、参照、重放 3 次、时限 2 秒与 10 秒），按各段外层时限等满：
      情景一：每段一次等待，各计一次新池预热（修订前少计一次，写成 6 次）；
      情景二：固定包装在池损坏后重试一次，等待可以再走满，每次尝试各计一次新池启动。
    两种情景都没有给导入、读数据、保护暂停和人工续跑时间设界。"""
    waits = 30 + 300 + 3 * 30 + 2 * 30
    share_up = report_mod.upper(events, n)
    out = {"event_share_model_bound_one_sided_95": round(share_up, 5), "events": events, "rows": n, "P": P,
           "warmup_s": warm, "pass_waits_s": waits}
    for key, worst in (("one_wait_per_pass", waits + 7 * warm), ("retry_after_broken_pool", 2 * waits + 14 * warm)):
        out[key] = {"seconds_per_event_row": round(worst, 1), "extra_h": round(MAIN_N * share_up * worst / max(1, P) / 3600, 1)}
    out["note"] = ("带假设的规划情景，不是主测量的上界或预计：事件比例取试跑的单侧 95% 模型界，要另外假设主总体与试跑"
                   "同分布、各行独立（试跑定额抽自主样本以外、不含单回答题）；每条事件行七段各按外层时限等满。情景一每段"
                   "一次等待加一次新池预热；情景二池损坏后重试、再等满，每次尝试各计一次新池启动。导入、读数据、保护暂停"
                   "与人工续跑都没有设界。")
    return out


def estimate(on, par, ref, P, rows_all):
    """按实测估主测量各段耗时（小时）。事件比例取自试跑（主样本以外的回答，只作资源估计）。"""
    n = len(rows_all)
    zero_or_exc = sum(1 for v in rows_all.values() if v["result"] and (v["result"]["exc"] or v["result"]["score"] == 0))
    events = sum(1 for v in rows_all.values() if v["class"] not in ("1 分", "正常 0"))
    slow = sum(1 for v in rows_all.values() if any(
        s.get("end") and (s["wall"] > 1 or any(lg["cat"].startswith("Timeout") for lg in s["logs"]))
        for a in v["attempts"] for s in ((a.get("child") or {}).get("steps") or [])))
    thr = (par or on)["rows_per_hour"]
    per_row_ref = ref["elapsed_s"] / max(1, ref["done"]) if ref else None
    f0, fe, fs = zero_or_exc / n, events / n, slow / n
    main_h = MAIN_N / thr if thr else None
    ref_rows = MAIN_N * f0 + REF_CHECK_ONES
    ref_h = ref_rows * per_row_ref / max(1, P) / 3600 if per_row_ref else None
    follow_rows = MAIN_N * fe * 3 + (MAIN_N * fs + (MAIN_N - MAIN_N * fs) * FOLLOW_RANDOM) * 2 + MAIN_N * FOLLOW_RANDOM
    follow_h = follow_rows / thr if thr else None
    total = sum(x for x in (main_h, ref_h, follow_h) if x)
    warm = max([w for s in (on, par, ref) if s for w in s["warmups"]["first_per_worker_s"]] or [0])
    tail = tail_scenarios(warm, events, n, P)
    return {"based_on": f"试跑 {n} 行（主样本以外的回答）；吞吐取 {'par' if par else 'on'} 段，P={P}",
            "share_default_zero_or_exc": round(f0, 4), "share_with_events": round(fe, 4),
            "share_slow_or_lib_timeout": round(fs, 4),
            "main_default_h": main_h and round(main_h, 1), "reference_rows": round(ref_rows),
            "reference_h": ref_h and round(ref_h, 1), "followup_rows": round(follow_rows),
            "followup_h": follow_h and round(follow_h, 1), "total_h": round(total, 1),
            "over_24h": total > 24,
            "tail_scenarios": tail,
            "note": "跟进按方案第 4 节：重放 3 次的行按有事件的比例估（修订后时限敏感变化与单行超过 10 秒的行也进重放，"
                    "这里没有单列）；慢步骤或库超时的行加其余行随机 1% 各跑 2 秒、10 秒两种时限；随机 1% 重测；参照覆盖默认"
                    "得 0 或异常的行，另加 1,000 条默认得 1 的行。比例取自试跑，只作资源估计。"}


def main():
    stamp = time.strftime("%Y%m%d-%H%M%S")
    base = Path.home() / ".local/share/rewardfail/stage2/runs" / f"pilot-{stamp}"
    base.mkdir(parents=True)
    t0 = time.time()
    rows_map = data.load_map()
    answers = data.answers_by_row()
    pilot = data.pilot_set(rows_map, answers)
    del rows_map, answers
    picked = {(t["shard"], t["row"]) for t in pilot}
    report = {"what": "第二阶段资源试跑与真实回答上的开关对照（只估资源，不并入主样本）", "run_dir": str(base),
              "env": env(), "pilot": {"n": len(pilot), "questions": len(picked),
                                      "by_shard": dict(Counter(t["shard"] for t in pilot)),
                                      "by_type": dict(Counter(t["atype"] for t in pilot))}}
    first, rest = pilot[:N_SWITCH], pilot[N_SWITCH:]
    on, on_rows = stage(base, "on", first, 1, "observe", "on")
    off, off_rows = stage(base, "off", first, 1, "off", "off")
    report["on"], report["off"] = on, off
    report["switch"] = switch_compare(on_rows, off_rows)

    vm = psutil.virtual_memory()
    budget = min(8 * GiB, max(1 * GiB, vm.available - int(1.5 * GiB)))
    mem = on["memory"]
    pipeline = mem["pipeline"].get("max") or 0
    child_base = on["child_fp_at_start"].get("p50") or 0  # 只取真正的进程池子进程（子侧日志）；状态记录的“pool”里还有资源跟踪进程
    sup = mem["supervisor"].get("max") or psutil.Process().memory_info().rss
    P = guard_mod.plan_parallel(budget - sup, pipeline, child_base, CHILD_LIMIT)
    report["plan_P"] = {"budget": gib(budget), "available_now": gib(vm.available), "supervisor": gib(sup),
                        "pipeline_max": gib(pipeline), "child_base_p50": gib(child_base), "child_limit": gib(CHILD_LIMIT),
                        "P": P, "formula": "P = min(4, ⌊(预算 − 调度 − (单子进程上限 − 子进程常驻中位)) ÷ 流水线 footprint 采样最大值⌋)，"
                                           "小于 1 不开；内存一律按 footprint"}

    par, par_rows = (None, {})
    if P >= 1 and rest:
        par, par_rows = stage(base, "par", rest, P, "observe", "par")
    report["par"] = par if par else {"skipped": f"P={P}" if P < 1 else "试跑集没有剩余行"}

    zero = [t for t in pilot if (r := (on_rows.get(t["id"]) or par_rows.get(t["id"]) or {}).get("result"))
            and (r["exc"] or r["score"] == 0)]
    ref, ref_rows = (None, {})
    if zero and P >= 1:
        ref, ref_rows = stage(base, "ref", zero, P, "reference", "ref")
        flips = []
        for t in zero:
            d = (on_rows.get(t["id"]) or par_rows.get(t["id"]))["result"]
            r = (ref_rows.get(t["id"]) or {}).get("result") or {}
            flips.append({"id": t["id"], "default": (d["score"], d["exc"]), "reference": (r.get("score"), r.get("exc")),
                          "ref_class": (ref_rows.get(t["id"]) or {}).get("class")})
        ref["default_vs_reference"] = dict(Counter(f"{f['default']}→{f['reference']}" for f in flips))
    report["ref"] = ref if ref else {"skipped": "没有默认得 0 或异常的行" if not zero else f"P={P}"}

    rows_all = dict(on_rows, **par_rows)
    report["estimate"] = estimate(on, par, ref, max(P, 1), rows_all)
    report["seconds"] = round(time.time() - t0, 1)
    gates = {"开关对照逐行一致": report["switch"]["pass"],
             "on 段没有观测不完整的行": not on["problems"],
             "par 段没有观测不完整的行": not (par or {}).get("problems"),
             "没有整机保护终止或整项停止": all(not (s or {}).get("stats", {}).get("budget_kills")
                                        and not (s or {}).get("stats", {}).get("hard_stops") for s in (on, off, par, ref)),
             "旧池子进程都已退出": all(not (s or {}).get("old_pool_procs_without_exit") for s in (on, off, par, ref))}
    report["gates"] = gates
    out = ROOT / "results/s2_rev1/pilot/report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, indent=1, default=str)
    out.write_text(text, encoding="utf-8")
    (base / "report.json").write_text(text, encoding="utf-8")
    print(json.dumps({"gates": gates, "plan_P": report["plan_P"], "estimate": report["estimate"],
                      "seconds": report["seconds"]}, ensure_ascii=False, indent=1))
    sys.exit(0 if all(gates.values()) else 1)


if __name__ == "__main__":
    main()
