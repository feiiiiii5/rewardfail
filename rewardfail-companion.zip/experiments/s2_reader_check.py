"""核对 rewardfail/s2/data.py 的 Reader 改了读法以后读出的文字不变，并比较两种读法的测量进程内存（只读数据，不判分）。

旧读法（10-07 以前）：每读一个行组，把 answer 和 generations 两列整组转成 Python 列表。
新读法：行组留在 Arrow 里，只把要用的那一行转成 Python；换行组时把 Arrow 内存池里不用的内存还给系统。
1. 逐条比对：十个分片的每一行，标准答案和全部回答两种读法逐条相同；另记全部文字的 sha256。
2. 内存：各起一个新进程，先导入与测量进程相同的模块，再按主测量的顺序读前 3 个分片的每一行，记 footprint。
结果写 results/s2_pilot/reader_check.json。
"""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import pyarrow.parquet as pq  # noqa: E402

from rewardfail.s2 import data  # noqa: E402

MiB = 1 << 20


class OldReader(data.Reader):
    """10-07 以前的读法，原样保留作对照。"""

    def get(self, shard, row):
        pf, starts = self._file(shard)
        rg = max(i for i, s in enumerate(starts) if s <= row)
        if self.cache_key != (shard, rg):
            t = pf.read_row_group(rg, columns=["answer", "generations"])
            self.cache_key, self.cache = (shard, rg), (t.column("answer").to_pylist(), t.column("generations").to_pylist())
        answers, gens = self.cache
        return answers[row - starts[rg]], gens[row - starts[rg]]


def shards():
    return sorted(p.name for p in data.SHARDS.glob("train-*.parquet"))


def identity():
    old, new = OldReader(), data.Reader()
    h_old, h_new = hashlib.sha256(), hashlib.sha256()
    n = gens = 0
    mismatch = []
    for sh in shards():
        for row in range(pq.ParquetFile(data.SHARDS / sh).metadata.num_rows):
            a = old.get(sh, row)
            b = new.get(sh, row)
            for h, (ans, gs) in ((h_old, a), (h_new, b)):
                h.update(json.dumps([ans, gs], ensure_ascii=False).encode("utf-8"))
            if a != b or type(a[0]) is not type(b[0]):
                mismatch.append([sh, row])
            n += 1
            gens += len(b[1] or [])
    return {"rows": n, "generations": gens, "mismatch": mismatch[:20], "n_mismatch": len(mismatch),
            "sha256_old": h_old.hexdigest(), "sha256_new": h_new.hexdigest()}


def memory(which):
    from verl.utils.reward_score import math_verify  # noqa: F401  与测量进程相同的导入（连带 torch）

    from rewardfail.s2 import mem
    r = OldReader() if which == "old" else data.Reader()
    out = {"reader": which, "after_import_MiB": mem.usage()[0] // MiB, "per_shard": []}
    for sh in shards()[:3]:
        for row in range(pq.ParquetFile(data.SHARDS / sh).metadata.num_rows):
            r.get(sh, row)
        fp, fp_max, _ = mem.usage()
        out["per_shard"].append({"shard": sh, "fp_MiB": fp // MiB, "fp_max_MiB": fp_max // MiB})
    return out


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--memory":
        print(json.dumps(memory(sys.argv[2])))
        return
    t0 = time.time()
    res = {"what": "Reader 改读法前后的逐条比对与内存（只读数据，不判分）", "identity": identity()}
    res["memory"] = {}
    for which in ("old", "new"):
        p = subprocess.run([sys.executable, "-I", __file__, "--memory", which], capture_output=True, text=True, check=True)
        res["memory"][which] = json.loads(p.stdout.strip().splitlines()[-1])
    res["seconds"] = round(time.time() - t0, 1)
    ok = res["identity"]["n_mismatch"] == 0 and res["identity"]["sha256_old"] == res["identity"]["sha256_new"]
    res["pass"] = ok
    out = ROOT / "results/s2_pilot/reader_check.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(res, ensure_ascii=False, indent=1))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
