"""用修订后的完整性检查复核 10-07 修订前的全部原始运行（Codex 10-07 审核第 13.2 节第 1 项）。

旧记录没有序号、没有 row_begin、任务结束行不记信号总数，所以按 strict=False 复核：跳过这三项，结构、关联、
结果复现、结局等其余检查照查。逐行对照修订前的检查器（实验仓提交 42e4d63 的 rewardfail/s2/analyze.py，
从 git 原样取出）：问题列表与分类有任何不同都列出来，逐条说明是不是误报。只读原始记录，不改、不回写。
只取修订开始（10-07 15:54）之前的运行目录（按目录名里的时间）；修订后的运行用新格式，另由自检、试跑与主测量脚本测试
按 strict=True 检查，其中自检的负对照副本是故意改坏的，不能混进这里。
结果写 results/s2_rev1/legacy_recheck.json。
"""
import importlib.util
import json
import re
import subprocess
import sys
import tempfile
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from rewardfail.s2 import analyze as new  # noqa: E402

RUNS = Path.home() / ".local/share/rewardfail/stage2/runs"
OLD_COMMIT = "42e4d63"
OUT = ROOT / "results/s2_rev1/legacy_recheck.json"
OLD_FLAG, NEW_FLAG = "计时信号被吞", new.FLAG_NO_LOG
CUTOFF = "20261007-155400"  # 修订开始；Codex 审核用到的运行都在这之前


def load_old():
    src = subprocess.run(["git", "-C", str(ROOT), "show", f"{OLD_COMMIT}:rewardfail/s2/analyze.py"],
                         capture_output=True, text=True, check=True).stdout
    d = Path(tempfile.mkdtemp())
    (d / "analyze_old.py").write_text(src, encoding="utf-8")
    spec = importlib.util.spec_from_file_location("analyze_old", d / "analyze_old.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def coverage(rows):
    """新检查实际用到了多少：有子侧记录的尝试、正常结束的任务、两侧都解析出东西（按循环复现比较）、以异常结束的任务。"""
    c = Counter()
    for r in rows.values():
        for a in r["attempts"]:
            ch = a.get("child")
            if not ch:
                c["无子侧记录的尝试"] += 1
                continue
            c["有子侧记录的尝试"] += 1
            te, st = ch.get("task_end"), ch["steps"]
            if te is None:
                c["子任务没结束"] += 1
            elif te.get("exc"):
                c["子任务以异常结束"] += 1
            else:
                c["子任务正常结束"] += 1
                if len(st) >= 2 and st[0].get("res") and st[1].get("res"):
                    c["两侧都解析出东西（复现比较序列）"] += 1
                    c["复现的比较步数"] += len(st) - 2
                else:
                    c["有一侧没解析出东西（应无比较、得 0）"] += 1
    return dict(c)


def main():
    t0 = time.time()
    old = load_old()
    def stamp(d):
        m = re.search(r"(\d{8}-\d{6})", d.relative_to(RUNS).parts[0])
        return m.group(1) if m else None

    every = sorted({f.parent for f in RUNS.rglob("obs-*.jsonl")})
    dirs = [d for d in every if (stamp(d) or "99999999") < CUTOFF]
    skipped = sorted({d.relative_to(RUNS).parts[0] for d in every if d not in dirs})
    report, n_rows, n_diff, cov = [], 0, 0, Counter()
    for d in dirs:
        o_rows = old.summarize(old.load_run(d))
        n_rows_d = len(o_rows)
        n_rows += n_rows_d
        n_new = new.summarize(new.load_run(d, strict=False))
        diffs = []
        for rid in sorted(set(o_rows) | set(n_new), key=str):
            a, b = o_rows.get(rid), n_new.get(rid)
            if a is None or b is None:
                diffs.append({"id": rid, "only_in": "old" if b is None else "new"})
                continue
            flags_old = [f.replace(OLD_FLAG, NEW_FLAG) for f in a["flags"]]
            if a["problems"] != b["problems"] or a["class"] != b["class"] or flags_old != b["flags"]:
                diffs.append({"id": rid, "old_problems": a["problems"], "new_problems": b["problems"],
                              "old_class": a["class"], "new_class": b["class"], "old_flags": a["flags"],
                              "new_flags": b["flags"]})
        n_diff += len(diffs)
        cv = coverage(n_new)
        cov.update(cv)
        report.append({"run": str(d.relative_to(RUNS)), "rows": n_rows_d,
                       "classes": dict(Counter(r["class"] for r in n_new.values())),
                       "rows_with_problems_old": sum(bool(r["problems"]) for r in o_rows.values()),
                       "rows_with_problems_new": sum(bool(r["problems"]) for r in n_new.values()),
                       "coverage": cv, "diffs": diffs})
        print(d.relative_to(RUNS), n_rows_d, "行，不同", len(diffs), flush=True)
    out = {"what": "修订后的完整性检查（strict=False）复核修订前的全部原始运行，逐行对照修订前的检查器",
           "old_checker": f"实验仓 {OLD_COMMIT}:rewardfail/s2/analyze.py", "runs_root": str(RUNS),
           "cutoff": CUTOFF, "skipped_after_cutoff": skipped, "run_dirs": len(dirs), "rows": n_rows, "rows_differing": n_diff, "coverage": dict(cov), "runs": report,
           "seconds": round(time.time() - t0, 1)}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    print(json.dumps(dict(cov), ensure_ascii=False))
    print(f"{len(dirs)} 个运行目录、{n_rows} 行；新旧检查结论不同的 {n_diff} 行；写 {OUT}")


if __name__ == "__main__":
    main()
