"""开关对照的重复（10-07 修订后）：试跑的前 500 行按相反的顺序（先关后开）再跑一遍，看耗时差是观测层的开销还是噪声。

修订后的试跑（results/s2_rev1/pilot/report.json）里逐行分数仍完全相同，但每行耗时差（开 − 关）的 p99 从修订前的
1.3 毫秒变成 9.6 毫秒。这里：
1. 同样 500 行，先 off 后 on（试跑是先 on 后 off），逐行分数照样必须相同，耗时差照报；
2. 把观测开启时每行的墙钟拆成两部分：子进程里记录的库调用各步骤（两次解析与各次比较）的墙钟之和，与其余部分。
   其余部分只是“记录的库步骤之外的耗时”（观测记录、进程间通信、父进程本身的一部分），不是全部观测开销：
   日志处理与计时信号记录可以发生在被计时的库调用内部，DEBUG 级别在调用期间也生效（Codex 10-07 修订复核第 15.3 节）。
   所以这个拆分只能看结果与库计算波动的解释是否相容，不能隔离或排除库调用内部的观测开销。
   对修订前试跑、修订后试跑和这次重复的 on 段用同一口径算（修订前的记录用 strict=False 读）。
只用主样本以外的回答，不判主样本。结果写 results/s2_rev1/pilot/switch_repeat.json；
原始记录在 ~/.local/share/rewardfail/stage2/runs/switch-时间/。
"""
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments"))

import s2_pilot  # noqa: E402
from rewardfail.s2 import analyze, data  # noqa: E402
from rewardfail.s2.envinfo import env  # noqa: E402

RUNS = Path.home() / ".local/share/rewardfail/stage2/runs"
EARLIER = {"修订前试跑（pilot-20261007-141920，先开后关）": ("pilot-20261007-141920", False),
           "修订后试跑（pilot-20261007-164337，先开后关）": ("pilot-20261007-164337", True)}
OUT = ROOT / "results/s2_rev1/pilot/switch_repeat.json"


def split(rows):
    """观测开启的行：(记录的库调用各步骤墙钟之和, 其余部分) 两个分布，另给步骤数为 0 的行数。"""
    lib, rest, no_steps = [], [], 0
    for v in rows.values():
        r = v["result"]
        if r is None or r.get("wall") is None:
            continue
        steps = [s for a in v["attempts"] for s in ((a.get("child") or {}).get("steps") or []) if s.get("end")]
        no_steps += not steps
        w = sum(s["wall"] for s in steps)
        lib.append(w)
        rest.append(r["wall"] - w)
    return {"rows": len(lib), "rows_without_steps": no_steps, "library_steps_s": s2_pilot.dist(lib),
            "outside_library_s": s2_pilot.dist(rest)}


def paired(on_rows, off_rows):
    """逐行配对的开 − 关墙钟差最大的 5 行，附观测开启时那行库调用步骤的墙钟。观测关闭时没有子侧记录，
    关的一侧拆不出库调用的部分，所以配对只能给总差。"""
    out = []
    for k, a in on_rows.items():
        b = off_rows.get(k)
        if not b or a["result"] is None or b["result"] is None:
            continue
        steps = [s for x in a["attempts"] for s in ((x.get("child") or {}).get("steps") or []) if s.get("end")]
        out.append({"id": k, "diff": round(a["result"]["wall"] - b["result"]["wall"], 4), "on": a["result"]["wall"],
                    "off": b["result"]["wall"], "on_library_steps": round(sum(s["wall"] for s in steps), 4)})
    out.sort(key=lambda x: -x["diff"])
    return out[:5]


def main():
    stamp = time.strftime("%Y%m%d-%H%M%S")
    base = RUNS / f"switch-{stamp}"
    base.mkdir(parents=True)
    t0 = time.time()
    rows_map = data.load_map()
    answers = data.answers_by_row()
    pilot = data.pilot_set(rows_map, answers)
    del rows_map, answers
    first = pilot[:s2_pilot.N_SWITCH]
    off, off_rows = s2_pilot.stage(base, "off", first, 1, "off", "off")
    on, on_rows = s2_pilot.stage(base, "on", first, 1, "observe", "on")
    sw = s2_pilot.switch_compare(on_rows, off_rows)
    report = {"what": "开关对照的重复：试跑前 500 行先关后开，拆分观测开启时的耗时", "run_dir": str(base), "env": env(),
              "order": "off → on", "switch": sw, "top_diffs": paired(on_rows, off_rows),
              "this_run_on": split(on_rows), "this_run_problems": {"on": on["problems"], "off": off["problems"]},
              "this_run_classes": {"on": on["classes"], "off": off["classes"]},
              "guard": {"on": on["supervise"]["guard"], "off": off["supervise"]["guard"]}, "earlier": {}}
    for label, (name, strict) in EARLIER.items():
        d = RUNS / name
        rows_on = {k: v for k, v in analyze.summarize(analyze.load_run(d / "on", strict=strict)).items()
                   if not str(k).startswith("warm-")}
        rows_off = {k: v for k, v in analyze.summarize(analyze.load_run(d / "off", strict=strict)).items()
                    if not str(k).startswith("warm-")}
        report["earlier"][label] = {"switch": s2_pilot.switch_compare(rows_on, rows_off), "on": split(rows_on),
                                    "top_diffs": paired(rows_on, rows_off)}
        report["earlier"][label]["switch"].pop("mismatch", None)
    report["seconds"] = round(time.time() - t0, 1)
    gates = {"逐行分数或异常相同": sw["pass"], "两段都没有观测不完整的行": not on["problems"] and not off["problems"],
             "没有整机保护终止或整项停止": all(not s["stats"].get("budget_kills") and not s["stats"].get("hard_stops")
                                        for s in (on, off))}
    report["gates"] = gates
    OUT.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(report, ensure_ascii=False, indent=1, default=str)
    OUT.write_text(text, encoding="utf-8")
    (base / "report.json").write_text(text, encoding="utf-8")
    brief = {"gates": gates, "this_run": {"diff": sw["wall_on_minus_off_s"], "on": report["this_run_on"]},
             "earlier": {k: {"diff": v["switch"]["wall_on_minus_off_s"], "outside": v["on"]["outside_library_s"]}
                         for k, v in report["earlier"].items()}, "seconds": report["seconds"]}
    print(json.dumps(brief, ensure_ascii=False, indent=1))
    sys.exit(0 if all(gates.values()) else 1)


if __name__ == "__main__":
    main()
