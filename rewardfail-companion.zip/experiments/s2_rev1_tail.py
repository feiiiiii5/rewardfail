"""按修订后的口径，从修订前的试跑报告重算长尾情景（Codex 10-07 审核第 13.2 节第 6 项）。

只读 results/s2_pilot/report.json（修订前的报告，原样保留，不回写），用 s2_pilot.tail_scenarios 重算两种带假设的情景，
并照原公式复现修订前的数字（少计一次预热的 6 次），对照写进 results/s2_rev1/tail_scenarios.json。
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments"))

import s2_pilot  # noqa: E402

OLD = ROOT / "results/s2_pilot/report.json"
OUT = ROOT / "results/s2_rev1/tail_scenarios.json"


def main():
    r = json.loads(OLD.read_text(encoding="utf-8"))
    warm = max(w for s in ("on", "par", "ref") if r.get(s) for w in r[s]["warmups"]["first_per_worker_s"])
    n = r["pilot"]["n"]
    events = round(r["estimate"]["share_with_events"] * n)
    P = r["plan_P"]["P"]
    new = s2_pilot.tail_scenarios(warm, events, n, P)
    old_worst = 30 + 300 + 3 * 30 + 2 * 30 + 6 * warm
    old = {"seconds_per_event_row": round(old_worst, 1),
           "extra_h": round(s2_pilot.MAIN_N * new["event_share_model_bound_one_sided_95"] * old_worst / max(1, P) / 3600, 1),
           "as_reported": r["estimate"]["tail_bound"]}
    out = {"what": "长尾情景按修订口径重算（输入是修订前试跑报告里的实测预热与事件数）", "source": str(OLD.relative_to(ROOT)),
           "inputs": {"warmup_s_max_first_per_worker": warm, "pilot_rows": n, "events": events, "P": P},
           "revised": new, "pre_revision_formula_6_warmups": old}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(out, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
