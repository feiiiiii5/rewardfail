"""18 条未裁定的补充诊断（申请季《RLVR第二阶段方案》第 19.2 节，运行前写定；Codex 审核后才运行）。

结果单列在 results/s2_u18/report.json：不回填 results/s2_main/report.json，不改门槛，正式判定仍以 60 秒参照为准。
输入只取主测量里的 19 行（唯一确认变化 k 与 18 条未裁定），编号先与正式报告逐一核对；读法 D0 见方案第 19.2 节。
- D3：k 行在默认设置（observe：库内 5 秒、外层 30 秒）与参照设置（reference：60 秒、300 秒）下各跑一段，每段同一输入
  10 行（编号后加 #r1…#r10），P=1，与主测量一样逐行在预热过的池上单独请求。比较耗时只统计每次比较都有结束记录的行
  （库内比较超时这类正常结束也算，按类别分开）；未进入比较、比较未完成（墙钟缺失）的行单列计数，不补 0 秒。同一预热池
  顺序重复，符号缓存状态未控制，不是 10 个独立样本：#r1 与其余重复分开报；没有跨硬件对照（Codex 审核第 20.2 节第 3 项）。
- D1：三条保护/中断（IMO 1981 第 6 题）与 m-bfc8（5 的幂塔）。不经过被测包装与进程池：每条开一个新进程（本脚本
  --d1-one），用子进程观测层（rewardfail/s2/child.py）直接调用包装在池里执行的 _verify_in_subprocess，库内时限按参照
  设置 60 秒。faulthandler 每 10 秒写一次全部线程的调用栈（C 层线程，主线程卡在 C 层计算里也能写）。
  监控每秒各自独立地查墙钟、内存压力与 footprint（任一项读不到只记录，不跳过其余检查）：
  - 取栈终点：footprint 超过 1.5 GiB 或墙钟超过 120 秒，先让它写一次调用栈（SIGUSR1）再杀掉。这是诊断取栈的终点，
    不要求跑完，不是通用资源上限。
  - 资源干预（D135）：内存压力变红或读不到，立即同样结束。这次不算完成的诊断，不缓存；停止派发，等内存压力读得到且
    不红连续 30 秒再重做这一条；同一条连续两次资源干预就停下交人，同一运行目录续跑（Codex 审核第 20.2 节第 1、2 项）。
  不算测量，不改任何类别。
- D2：其余 14 条参照自身超时，参照模式、库内 300 秒、外层 1,500 秒（s2_worker --mode reference --limits 300），
  单行上限 2×1,500+90 秒，P=1。汇总 k₃₀₀、u₃₀₀ 与上界：其余 93,714 行沿用正式报告，k 行沿用 60 秒参照的 1 分，
  D1 的 4 条仍记未裁定，所以 k₃₀₀+u₃₀₀ ≥ 5，这次的敏感性分析达不到停止门槛；它是有限的敏感性分析，不是最终真值。
  D0 是人工初判：读法不是“相同”却判 1 的只列为“与人工初判不一致，待核查”，不直接记成参照误判。
判分段用主测量同一套测量进程、整机保护（D135）、逐行合成与段参数核对（s2_main.run_pass）。运行目录在
~/.local/share/rewardfail/stage2/runs/u18-时间/；--run-dir 续跑，版本锁（主测量的锁加上本脚本的 sha256）不同就停下。
顺序 D3 → D1 → D2，一次只跑一个进程。
运行：.venv/bin/python -I experiments/s2_u18_diag.py [--run-dir 目录] [--only D3,D1,D2] [--out 报告路径]
"""
import argparse
import faulthandler
import json
import os
import signal
import statistics
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments"))

import s2_main  # noqa: E402

from rewardfail.s2 import data, guard as guard_mod, mem, report  # noqa: E402
from rewardfail.s2.envinfo import env  # noqa: E402
from rewardfail.s2.stepguard import StepGuard, write_atomic  # noqa: E402

GiB, MiB = 1 << 30, 1 << 20
MAIN_REPORT = ROOT / "results/s2_main/report.json"
OUT = ROOT / "results/s2_u18/report.json"
K_ID = "m-377a40b9adf29ef8"
D1_IDS = ("m-8364284f555502b7", "m-ac45c2e3c4109182", "m-2a2cbb703cd7d47a", "m-bfc80eaa0d4fcfda")
REPEATS = 10
D1_FP, D1_WALL, D1_DUMP = int(1.5 * GiB), 120, 10
D1_RESUME, D1_MAX_RES = 30, 2  # D135：资源干预后连续 30 秒读得到且不红才接续（同 Guard.resume_after）；同一条连续两次就停下
D2_LIMIT = 300
SELF = "experiments/s2_u18_diag.py"
# 方案第 19.2 节 D0 的人工初判（“相同”含只差写法、记号或只给出共同值的），只用来与 D2 对照，不当真值
READING = {i: "相同" for i in ("m-e53750f029aa5980", "m-696f7389aa285443", "m-f2a5f57d876d0b1e", "m-691a82a720415dbc",
                               "m-fa489af4aead097c", "m-8967f984969c2fb1", "m-6cc6536a39ab6094", "m-0be9fc848295320a",
                               "m-c2a8844f7413b247", "m-0a55a91128070c4b")}
READING.update({i: "不同" for i in (*D1_IDS, "m-f6e89bd885e1f88f", "m-3e99df52be81a4a3", "m-60f96867bd1e6c8c")})
READING["m-95674e055a0a4cb3"] = "无可判"


def log(msg):
    print(time.strftime("%H:%M:%S"), msg, flush=True)


def targets():
    """正式报告的 k 与 18 条未知要和本脚本写定的一致；返回正式报告与 D2 的编号。"""
    rep = json.loads(MAIN_REPORT.read_text(encoding="utf-8"))
    u = set(rep["u_detail"])
    if rep["k_ids"] != [K_ID] or len(u) != 18 or not set(D1_IDS) <= u or set(READING) != u:
        raise SystemExit("正式报告的 k、u 编号与本脚本写定的不同，停下")
    return rep, sorted(u - set(D1_IDS))


def tasks_for(ids):
    """从抽样映射取这几行（编号 = "m-" + key 前 16 位，同 s2_main.build），按分片、行号排序。"""
    want, out = set(ids), {}
    for r in data.load_map():
        tid = "m-" + r["key"][:16]
        if tid in want:
            out[tid] = {"id": tid, "shard": r["shard"], "row": r["row"], "idx": r["pick"]}
    if set(out) != want:
        raise SystemExit(f"抽样映射里找不到：{sorted(want - set(out))}")
    return out


def row_view(r, verdict):
    """逐行记录里这次诊断要的部分：类别、裁定、整行墙钟，以及最后一次尝试里每次比较的墙钟与是否结束。
    比较计时分三种：未进入比较；比较未完成（有一次比较没有结束记录或缺墙钟，比较耗时记缺失，不补 0）；完成（每次比较都有
    结束记录，含库内比较超时这类正常结束）。"""
    last = (r.get("attempts") or [{}])[-1]
    cmp_ = [[s[1], s[2], s[3]] for s in last.get("steps") or [] if s[0] == "compare"]
    timing = ("未进入比较" if not cmp_ else "比较未完成" if any(c[0] is None or not c[1] for c in cmp_) else "完成")
    return {"id": r["id"], "class": r["class"], "verdict": verdict(r["class"]), "wall": r.get("wall"),
            "attempts": len(r.get("attempts") or []), "compare": cmp_, "timing": timing,
            "compare_wall": round(sum(c[0] for c in cmp_), 3) if timing == "完成" else None}


def spread(xs):
    xs = [x for x in xs if x is not None]
    return {"n": len(xs), "median": statistics.median(xs), "min": min(xs), "max": max(xs)} if xs else {"n": 0}


def d3_summary(rows):
    """D3 一段的汇总。比较耗时只算计时完成的行、按类别分开；未进入比较、比较未完成只计数。#r1 是这一段的第一次请求，
    其余是同一预热池上的顺序重复，分开报（Codex 审核第 20.2 节第 3 项）。"""
    rows = sorted(rows, key=lambda r: int(r["id"].rsplit("#r", 1)[1]))

    def by_class(rs):
        done = [r for r in rs if r["timing"] == "完成"]
        return {c: spread([r["compare_wall"] for r in done if r["class"] == c]) for c in sorted({r["class"] for r in done})}

    return {"classes": dict(Counter(r["class"] for r in rows)), "timing": dict(Counter(r["timing"] for r in rows)),
            "compare_wall_by_class": by_class(rows),
            "first": {k: rows[0][k] for k in ("id", "class", "timing", "compare_wall")} if rows else None,
            "repeats_compare_wall_by_class": by_class(rows[1:]),
            "row_wall": spread([r["wall"] for r in rows]), "row_wall_missing": sum(r["wall"] is None for r in rows),
            "note": "同一预热池顺序重复，符号缓存状态未控制，不是独立样本；只在本机，没有跨硬件对照",
            "rows": rows}


def run_d3(base, a, t):
    out = {}
    for name, mode, verdict in (("d3-default", "observe", report.default_verdict),
                                ("d3-reference", "reference", report.ref_verdict)):
        tasks = [dict(t, id=f"{K_ID}#r{n}") for n in range(1, REPEATS + 1)]
        s2_main.run_pass(base, name, tasks, mode, [], a)
        out[name] = dict(mode=mode, **d3_summary([row_view(r, verdict) for r in s2_main.scan(base / name)]))
        log(f"D3 {name}：{out[name]['classes']}，计时 {out[name]['timing']}，"
            f"完成比较的墙钟 {out[name]['compare_wall_by_class']}")
    return out


def d1_one(spec):
    """D1 子进程：读输入文件，装好调用栈输出，跑一次解析与比较，结果打印到标准输出。"""
    t = json.loads(Path(spec).read_text(encoding="utf-8"))
    fh = open(t["stacks"], "a", encoding="utf-8")
    faulthandler.register(signal.SIGUSR1, file=fh, all_threads=True)
    faulthandler.dump_traceback_later(D1_DUMP, repeat=True, file=fh)
    from rewardfail.s2 import child
    ctx = {"log_dir": t["log_dir"], "mode": "reference", "limits": {"parse": 60, "compare": 60}, "inject": t.get("inject"),
           "req": t["req"], "att": t["att"], "gen": 0, "worker": "d1"}
    t0 = time.time()
    try:
        r = {"res": child.observed_verify(ctx, "\\boxed{" + t["gt"] + "}", t["out"])}
    except BaseException as e:
        r = {"exc": type(e).__name__}
    faulthandler.cancel_dump_traceback_later()
    print(json.dumps(dict(r, wall=round(time.time() - t0, 3))), flush=True)


def d1_watch(d, t, reader, att=1):
    """D1 跑一条（第 att 次，文件名与子进程记录的请求编号都带上它）。墙钟、内存压力、footprint 每秒各查各的：footprint
    读不到只计数，不跳过压力与墙钟；压力读不到按 D135 当作资源干预。
    t 带 gt、out（与可选的 inject）时直接用，只在测试里这样给（tests/test_s2_u18_diag.py）。"""
    if "gt" in t:
        gt, out = t["gt"], t["out"]
    else:
        gt, gens = reader.get(t["shard"], t["row"])
        out = gens[t["idx"]]
    tag, req = f"{t['id']}-a{att}", f"{t['id']}@a{att}"
    spec = d / f"{tag}-input.json"
    write_atomic(spec, json.dumps({"id": t["id"], "req": req, "att": att, "gt": gt, "out": out, "inject": t.get("inject"),
                                   "log_dir": str(d), "stacks": str(d / f"{tag}-stacks.txt")}, ensure_ascii=False))
    err = open(d / f"{tag}-stderr.txt", "w", encoding="utf-8")
    t0 = time.time()
    p = subprocess.Popen([sys.executable, "-I", str(ROOT / SELF), "--d1-one", str(spec)], stdout=subprocess.PIPE,
                         stderr=err, text=True, cwd=ROOT)
    curve, why, kind, fp_fail, n_pr = [], None, None, Counter(), 0
    while p.poll() is None:
        time.sleep(1)
        el = round(time.time() - t0, 1)
        try:
            fp = mem.usage(p.pid)[0]
        except (mem.Gone, OSError) as e:
            fp = None
            fp_fail[type(e).__name__] += 1
        pr = guard_mod.pressure()
        n_pr += 1
        curve.append([el, fp, pr])
        if pr is None or pr >= guard_mod.RED:
            why, kind = ("读不到内存压力（D135）" if pr is None else "内存压力变红（D135）"), "资源干预"
        elif fp is not None and fp > D1_FP:
            why, kind = f"footprint 超过 {D1_FP // MiB} MiB", "取栈终点"
        elif el > D1_WALL:
            why, kind = f"墙钟超过 {D1_WALL} 秒", "取栈终点"
        if why:
            try:
                os.kill(p.pid, signal.SIGUSR1)
                time.sleep(1)
                p.kill()
            except ProcessLookupError:
                pass
            break
    stdout, _ = p.communicate()
    err.close()
    res = None
    for line in reversed(stdout.splitlines()):  # 只认本脚本最后打印的那一行结果
        try:
            res = json.loads(line)
            break
        except ValueError:
            continue
    steps = [json.loads(x) for f in d.glob("child-*.jsonl") for x in f.read_text(encoding="utf-8").splitlines()
             if x.strip() and json.loads(x).get("req") == req]
    last = [s for s in steps if s["ev"] in ("step_start", "step_end")]
    fps = [c[1] for c in curve if c[1] is not None]
    return {"id": t["id"], "att": att, "stopped_by": why, "stop_kind": kind or "自己结束", "exit": p.returncode,
            "result": res, "seconds": round(time.time() - t0, 1),
            "fp_first_MiB": fps[0] // MiB if fps else None, "fp_max_MiB": max(fps) // MiB if fps else None,
            "fp_read_fail": dict(fp_fail), "pressure_reads": n_pr,
            "max_pressure": max((c[2] or 0 for c in curve), default=None),
            "last_step": {k: last[-1].get(k) for k in ("ev", "step", "kind", "wall")} if last else None,
            "curve": [[c[0], c[1] // MiB if c[1] is not None else None, c[2]] for c in curve[::5]],
            "stacks": f"{tag}-stacks.txt"}


def d1_clear(d, why=None):
    """D1 派下一条之前（D135）：刚有资源干预（why），或此刻内存压力红、读不到，就停止派发，等读得到且不红连续 D1_RESUME
    秒再接续；否则直接派。每次等待记在 d1/guard.jsonl。"""
    pr = guard_mod.pressure()
    if why is None and pr is not None and pr < guard_mod.RED:
        return
    gl = d / "guard.jsonl"

    def rec(ev, **kw):
        with open(gl, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(dict(kw, ev=ev, t=round(time.time(), 3)), ensure_ascii=False) + "\n")

    t0, clear, seen = time.time(), None, Counter()
    rec("pause", why=why or ("读不到内存压力" if pr is None else "内存压力变红"), pressure=pr, resume_after=D1_RESUME)
    log(f"D1 停止派发：{why or ('读不到内存压力' if pr is None else '内存压力变红')}，"
        f"等内存压力读得到且不红连续 {D1_RESUME} 秒")
    while True:
        time.sleep(1)
        pr, now = guard_mod.pressure(), time.time()
        seen["读不到" if pr is None else "红" if pr >= guard_mod.RED else "不红"] += 1
        if pr is None or pr >= guard_mod.RED:
            clear = None
            continue
        clear = clear or now
        if now - clear >= D1_RESUME:
            break
    rec("resume", waited=round(now - t0, 1), clear_for=round(now - clear, 1), reads=dict(seen))


def run_d1(base, tasks):
    """逐条串行。只有取栈终点或自己结束的结果写成 d1/编号.json（续跑时复用）；资源干预的那次只记进 d1/attempts.jsonl，
    等回落后重做；同一条在这次运行里连续 D1_MAX_RES 次资源干预就停下，同一 --run-dir 续跑。"""
    d = base / "d1"
    d.mkdir(exist_ok=True)
    reader, out, al = data.Reader(), {}, d / "attempts.jsonl"
    for i in D1_IDS:
        f, why, n_res = d / f"{i}.json", None, 0
        while not f.exists():
            prev = [json.loads(x) for x in al.read_text(encoding="utf-8").splitlines() if x.strip()] if al.exists() else []
            if why is None:
                last = next((x for x in reversed(prev) if x["id"] == i), None)
                if last and last["stop_kind"] == "资源干预":
                    why = last["stopped_by"] or "上次资源干预"
            d1_clear(d, why)
            r = d1_watch(d, tasks[i], reader, att=1 + sum(x["id"] == i for x in prev))
            with open(al, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(r, ensure_ascii=False) + "\n")
            if r["stop_kind"] != "资源干预":
                write_atomic(f, json.dumps(r, ensure_ascii=False, indent=1))
                break
            n_res, why = n_res + 1, r["stopped_by"]
            log(f"D1 {i} 第 {r['att']} 次遇到资源干预：{why}；不算完成")
            if n_res >= D1_MAX_RES:
                raise SystemExit(f"D1 {i} 连续 {n_res} 次资源干预（{why}），停下；记录在 {d}，回落后用同一 --run-dir 续跑")
        out[i] = json.loads(f.read_text(encoding="utf-8"))
        log(f"D1 {i}：{out[i]['stopped_by'] or '自己结束'}，footprint 最高 {out[i]['fp_max_MiB']} MiB，"
            f"停在 {out[i]['last_step']}")
    return out


def run_d2(base, a, tasks, ids, rep):
    name = "d2-ref300"
    s2_main.run_pass(base, name, [tasks[i] for i in ids], "reference", ["--limits", str(D2_LIMIT)], a,
                     row_limit=2 * 5 * D2_LIMIT + 90)
    rows = {r["id"]: dict(row_view(r, report.ref_verdict), reading=READING[r["id"]],
                          default=rep["u_detail"][r["id"]]["default"], ref60=rep["u_detail"][r["id"]]["reference"])
            for r in s2_main.scan(base / name)}
    n = rep["main_metric"]["n"]
    k = 1 + sum(r["verdict"] == 1 for r in rows.values())
    u = sum(r["verdict"] is None for r in rows.values()) + len(D1_IDS)
    agree = Counter(f"{r['reading']} → {r['verdict']}" for r in rows.values())
    out = {"note": "300 秒参照的有限敏感性分析，不是最终真值；单列，不回填正式报告、不改门槛。D1 的 4 条仍未裁定，"
                   "所以 k₃₀₀+u₃₀₀ ≥ 5（方案第 19.2、20.3 节）",
           "limit": D2_LIMIT, "outer": 5 * D2_LIMIT,
           "rows": rows, "k_300": k, "u_300": u, "upper_one_sided_95_k_plus_u_300": report.upper(k + u, n),
           "lower_one_sided_95_k_300": report.lower(k, n), "reading_vs_verdict": dict(agree),
           "d0_disagree_but_1": sorted(i for i, r in rows.items() if r["reading"] != "相同" and r["verdict"] == 1),
           "d0_note": "D0 是人工初判；读法不是“相同”却判 1 的只列为与人工初判不一致、待核查，不直接记参照误判"}
    log(f"D2：k₃₀₀={k}，u₃₀₀={u}，读法对照 {dict(agree)}")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", help="续跑：给上次的运行目录")
    ap.add_argument("--only", default="D3,D1,D2", help="只跑其中几项，逗号分隔")
    ap.add_argument("--out", default=str(OUT))
    ap.add_argument("--d1-one", help=argparse.SUPPRESS)
    a = ap.parse_args()
    if a.d1_one:
        return d1_one(a.d1_one)
    only = [x.strip().upper() for x in a.only.split(",") if x.strip()]
    rep, d2_ids = targets()
    base = Path(a.run_dir) if a.run_dir else s2_main.RUNS / f"u18-{time.strftime('%Y%m%d-%H%M%S')}"
    base.mkdir(parents=True, exist_ok=True)
    with StepGuard(base / s2_main.STEPS_LOG, "构建任务与版本锁") as sg:
        tasks = tasks_for([K_ID, *D1_IDS, *d2_ids])
        pre = {"what": "u18", "plan": "方案第 19.2 节", "k": K_ID, "d1": list(D1_IDS), "d2": d2_ids, "repeats": REPEATS,
               "d1_fp": D1_FP, "d1_wall": D1_WALL, "d2_limit": D2_LIMIT}
        lock = s2_main.current_lock(pre, sg.tick)
        lock["code_sha256"][SELF] = s2_main.file_sha(ROOT / SELF)
    with StepGuard(base / s2_main.STEPS_LOG, "核对版本锁"):
        resumed, allowed = s2_main.check_lock(base, lock)
    log(f"运行目录 {base}（{'续跑' if resumed else '新建'}），顺序 {only}")
    a.P, a.child_limit = 1, None
    out = {"what": "18 条未裁定的补充诊断（方案第 19.2 节）：单列，不回填正式报告，不改门槛",
           "run_dir": str(base), "main_report": str(MAIN_REPORT.relative_to(ROOT)), "lock": lock, "env": env(),
           "compat_allowed": allowed}
    t0 = time.time()
    if "D3" in only:
        out["d3"] = run_d3(base, a, tasks[K_ID])
    if "D1" in only:
        out["d1"] = run_d1(base, tasks)
    if "D2" in only:
        out["d2"] = run_d2(base, a, tasks, d2_ids, rep)
    out["seconds"] = round(time.time() - t0, 1)
    text = json.dumps(out, ensure_ascii=False, indent=1, default=str)
    write_atomic(base / "report.json", text)
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    write_atomic(Path(a.out), text)
    log(f"写 {a.out}")


if __name__ == "__main__":
    main()
