#!/usr/bin/env bash
# 第二阶段（自然发生率）用的公开数据。原定由用户本人下载（申请季 D116）；10-06 晚用户让 Claude 运行本脚本，只限这份清单（D121）。
# 清单与固定版本在 data_manifest.tsv：22 个文件，共 2,181,301,233 bytes（约 2.18 GB），每个文件核对字节数和校验值。
# 数据放在不受 iCloud 同步的 ~/.local/share/rewardfail/data，仓内的 data 只是指向那里的链接。
#
# 用法：
#   bash get_data.sh            下载并逐个核对；断了重跑同一条命令会接着下，已核对通过的文件跳过
#   bash get_data.sh --check    只核对已有文件：不下载，也不建目录或链接
#   连不上 Hugging Face 时：HF_ENDPOINT=https://hf-mirror.com bash get_data.sh（校验值不变，镜像给错文件会被查出来）
set -euo pipefail
# 输出语句里的变量一律写成 ${name}：macOS 自带的 bash 3.2 在 UTF-8 环境下，会把紧跟在变量名后的中文字节当成变量名的一部分（10-06 实测）
usage() {
  echo "用法：bash get_data.sh            下载并逐个核对（断了重跑同一条命令会接着下）"
  echo "      bash get_data.sh --check    只核对已有文件，不下载，不建目录或链接"
}
case "$#:${1:-}" in
  0:) MODE=download ;;
  1:--check) MODE=check ;;
  1:-h|1:--help) usage; exit 0 ;;
  *) echo "不认识的参数：$*" >&2; usage >&2; exit 2 ;;
esac
cd "$(dirname "$0")"
DEST="${REWARDFAIL_DATA:-$HOME/.local/share/rewardfail/data}"
HF="${HF_ENDPOINT:-https://huggingface.co}"
CURL=/usr/bin/curl; [ -x "$CURL" ] || CURL=curl   # 用系统自带的 curl，不受 conda 等环境的 PATH 影响

size() { wc -c < "$1" | tr -d ' '; }
check() {  # 文件 字节数 校验方式 校验值
  [ -f "$1" ] || return 1
  [ "$(size "$1")" = "$2" ] || return 1
  case "$3" in
    sha256) [ "$(shasum -a 256 "$1" | cut -d' ' -f1)" = "$4" ] ;;
    # --no-filters：按文件原样算。不加时 git 会按用户设置先转换换行（本机全局 core.autocrlf=input），带 CRLF 的文件就对不上（10-06 实跑暴露）
    gitblob) [ "$(git hash-object --no-filters "$1")" = "$4" ] ;;
    *) return 1 ;;
  esac
}

if [ "$MODE" = download ]; then
  mkdir -p "$DEST"
  [ -e data ] || [ -L data ] || ln -s "$DEST" data
fi
echo "数据目录：${DEST}"
if [ -L data ] && [ "$(readlink data)" != "${DEST}" ]; then echo "注意：仓内 data 链接指向 $(readlink data)，不是上面的数据目录；脚本没有改动它" >&2; fi
# 代理地址可能带用户名和密码，只显示有没有设置
if [ -n "${HTTPS_PROXY:-${https_proxy:-${ALL_PROXY:-${all_proxy:-}}}}" ]; then proxy="已设置（不显示地址）"; else proxy="未设置（直连）"; fi
[ "${MODE}" = check ] || echo "来源：${HF} 与 raw.githubusercontent.com；代理环境变量：${proxy}"
ok=0; bad=0
while IFS=$'\t' read -r rel src bytes kind digest; do
  case "$rel" in ''|'#'*) continue ;; esac
  out="$DEST/$rel"
  if check "${out}" "${bytes}" "${kind}" "${digest}"; then echo "已核对  ${rel}"; ok=$((ok + 1)); continue; fi
  if [ "${MODE}" = check ]; then echo "缺失或不符  ${rel}"; bad=$((bad + 1)); continue; fi
  mkdir -p "$(dirname "$out")"
  echo "下载    ${rel}（${bytes} bytes）"
  for attempt in 1 2 3 4 5; do
    # 已有部分且比目标小就续传；不比目标小却没通过校验，删掉重下
    if [ -f "$out" ] && [ "$(size "$out")" -ge "$bytes" ]; then rm -f "$out"; fi
    # 20 秒连不上、或连续 60 秒低于 10 KB/s 就断开，由这个循环接着下
    "$CURL" -L --fail --connect-timeout 20 --speed-limit 10240 --speed-time 60 -C - -o "$out" "${src/#hf:/$HF/}" < /dev/null || true
    if check "$out" "$bytes" "$kind" "$digest"; then break; fi
    if [ "${attempt}" -lt 5 ]; then
      if [ -f "$out" ] && [ "$(size "$out")" -ge "$bytes" ]; then echo "  下完但核对不符，3 秒后删掉重下（第 ${attempt} 次）" >&2
      else echo "  没下完整，3 秒后接着下（第 ${attempt} 次）" >&2; fi
      sleep 3
    fi
  done
  if check "${out}" "${bytes}" "${kind}" "${digest}"; then ok=$((ok + 1)); else echo "校验失败  ${rel}" >&2; bad=$((bad + 1)); fi
done < data_manifest.tsv

echo "通过 ${ok} 个，未通过 ${bad} 个；数据目录 ${DEST}"
if [ "$MODE" = download ]; then
  printf '%s\t%s\t通过 %s\t未通过 %s\n' "$(date '+%Y-%m-%d %H:%M:%S %z')" "${HF}" "${ok}" "${bad}" >> "${DEST}/下载记录.tsv"
fi
[ "$bad" -eq 0 ]
