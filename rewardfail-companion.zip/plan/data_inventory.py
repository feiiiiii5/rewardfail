"""第二阶段数据的只读清点：数行、字段、空值、重复和长度。不运行判分器，不分析回答内容（只量字符数）。

用法（数据当不受信任的输入：在数据目录之外运行，加 -I）：
  ~/.local/share/rewardfail/venv/bin/python -I plan/data_inventory.py <数据目录> [输出 json]
"""
import csv
import hashlib
import json
import resource
import sys
from collections import Counter
from pathlib import Path

import pyarrow.compute as pc
import pyarrow.parquet as pq

D = Path(sys.argv[1])
out: dict[str, object] = {"说明": "只读清点：行数、字段、空值、重复与长度；没有运行判分器，没有分析回答内容（只量字符数）"}

# ---------- OpenR1 default ----------
SAME_LEN = ("correctness_math_verify", "is_reasoning_complete", "finish_reasons")  # 每条回答各一项
COLS = ["uuid", "problem", "answer", "source", "problem_type", "question_type", "generations", *SAME_LEN]
rows = answer_missing = 0
gen_null = gen_empty = rows_with_empty_gen = eligible = 0
same_len = {c: Counter() for c in SAME_LEN}  # 与 generations 同长 / 该列为空值 / 长度不同
uuid_bad_by_src, uuid_rows, problem_hash = Counter(), {}, Counter()
n_gens, ptype, qtype, src = Counter(), Counter(), Counter(), Counter()
lengths = []

for f in sorted((D / "openr1/data").glob("train-*.parquet")):
    t = pq.read_table(f, columns=COLS)  # 一次只读一个分片
    rows += t.num_rows
    g = t.column("generations")
    glen = pc.list_value_length(g).to_pylist()
    for c in SAME_LEN:
        for k, o in zip(glen, pc.list_value_length(t.column(c)).to_pylist()):
            same_len[c]["同长" if o == k else "该列为空值" if o is None else "长度不同"] += 1
    flat = pc.utf8_length(pc.list_flatten(g)).to_pylist()  # 空值列表不占位置；单条空值记 None
    sources = t.column("source").to_pylist()
    src.update(sources)
    ptype.update(t.column("problem_type").to_pylist())
    qtype.update(t.column("question_type").to_pylist())
    pos = 0
    for k, u, p, a, s in zip(glen, t.column("uuid").to_pylist(), t.column("problem").to_pylist(),
                             t.column("answer").to_pylist(), sources):
        h = hashlib.sha256((p or "").encode("utf-8")).hexdigest()
        problem_hash[h] += 1
        if u in (None, "", "NaN"):
            uuid_bad_by_src[s] += 1
        else:
            uuid_rows.setdefault(u, set()).add(h)
        a_ok = a is not None and a.strip() != ""
        answer_missing += not a_ok
        n_gens["空值" if k is None else str(k)] += 1
        seg = flat[pos:pos + (k or 0)]
        pos += k or 0
        bad = sum(1 for x in seg if x is None or x == 0)
        gen_null += sum(1 for x in seg if x is None)
        gen_empty += sum(1 for x in seg if x == 0)
        rows_with_empty_gen += bad > 0
        lengths.extend(x for x in seg if x is not None)
        eligible += bool(p) and a_ok and bool(k) and bad == 0
    assert pos == len(flat)
    del t, g, flat

lengths.sort()
q = lambda p: lengths[min(len(lengths) - 1, int(p * len(lengths)))]
shared = [len(v) for v in uuid_rows.values() if len(v) > 1]
out["openr1"] = {
    "行数": rows,
    "题面原文两两不同": max(problem_hash.values()) == 1,
    "uuid 缺失或写成 NaN 的行（按来源）": dict(uuid_bad_by_src.most_common()),
    "被不同题面共用的 uuid：个数 / 涉及行数": [len(shared), sum(shared)],
    "各来源行数": dict(src.most_common()),
    "answer 为空或只有空白": answer_missing,
    "每题回答条数": dict(sorted(n_gens.items())),
    "同长列表核对（同长 / 该列为空值 / 长度不同）": {c: [v["同长"], v["该列为空值"], v["长度不同"]] for c, v in same_len.items()},
    "单条回答为空值 / 空串": [gen_null, gen_empty],
    "含空回答的行": rows_with_empty_gen,
    "结构完整的题（题面、answer 非空，至少一条回答且都非空）": eligible,
    "回答字符数（条数、中位、P90、P99、P99.9、最大）": [len(lengths), q(0.5), q(0.9), q(0.99), q(0.999), lengths[-1]],
    "problem_type": dict(ptype.most_common()),
    "question_type": dict(qtype.most_common()),
}
del lengths, uuid_rows, problem_hash

# ---------- 标准答案一侧的三份数据 ----------
for rel in ("math_lighteval/data/train-00000-of-00001.parquet", "math_lighteval/data/test-00000-of-00001.parquet",
            "gsm8k/main/train-00000-of-00001.parquet", "gsm8k/main/test-00000-of-00001.parquet"):
    out[rel] = {"行数": pq.ParquetFile(D / rel).metadata.num_rows, "字段": pq.read_schema(D / rel).names}
ds = json.loads((D / "deepscaler/deepscaler.json").read_text(encoding="utf-8"))
out["deepscaler/deepscaler.json"] = (
    {"行数": len(ds), "字段": sorted({k for r in ds for k in r})} if isinstance(ds, list) else {"顶层键": sorted(ds)})
del ds

# ---------- 人工标注集 ----------
csv.field_size_limit(1 << 30)
with open(D / "rlvr_group_correlation/data/gold/gold_set_1p5b_manual_labeled.csv", newline="", encoding="utf-8-sig") as fh:
    r = csv.reader(fh)
    header = next(r)
    widths = Counter(len(row) for row in r)
out["rlvr_group_correlation 人工标注集"] = {"行数（不含表头）": sum(widths.values()), "字段": header,
                                      "每行字段数": dict(widths)}

peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss  # macOS 单位是字节
out["本次清点峰值内存 MiB"] = round(peak / 2**20 if sys.platform == "darwin" else peak / 2**10)

text = json.dumps(out, ensure_ascii=False, indent=2)
if len(sys.argv) > 2:
    Path(sys.argv[2]).write_text(text + "\n", encoding="utf-8")
print(text)
