"""第二阶段主样本的抽样映射（运行任何判分之前写定）。只用题面原文和回答条数，不读回答内容，不判分。

每道题（OpenR1 default 固定版本 e4e141e 的一行）：
  key  = sha256(题面原文的 UTF-8 字节)，32 字节。题面 93,733 行两两不同，见 data_inventory.json；不用 uuid
  pick = int.from_bytes(sha256(SEED + b"\\x00pick\\x00" + key)[:8], "big") % 回答条数   主样本用的那条回答的下标（从 0 数）
  half = int.from_bytes(sha256(SEED + b"\\x00half\\x00" + key)[:8], "big") % 2         0 = 前一半（答案类型探索），1 = 后一半（确认）
64 位取模，回答条数不超过 6，取模偏差小于 1e-18。SEED 写定后不改；改了就是另一个样本，要重新经双方同意。

用法（数据当不受信任的输入：在数据目录之外运行，加 -I）：
  ~/.local/share/rewardfail/venv/bin/python -I plan/sample_map.py <数据目录> <映射输出 tsv> [摘要 json]
映射文件约 14 MB，放仓外；仓里只留摘要，摘要里有映射文件的 sha256。
"""
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

import pyarrow.compute as pc
import pyarrow.parquet as pq

SEED = b"rewardfail-stage2-seed-2026-10-06"
D, OUT = Path(sys.argv[1]), Path(sys.argv[2])


def draw(tag, key, m):
    return int.from_bytes(hashlib.sha256(SEED + b"\x00" + tag + b"\x00" + key).digest()[:8], "big") % m


keys, by_k, halves = set(), Counter(), Counter()
OUT.parent.mkdir(parents=True, exist_ok=True)
with open(OUT, "w", encoding="utf-8", newline="\n") as fh:
    fh.write("problem_sha256\tshard\trow\tn_generations\tpick\thalf\n")
    for f in sorted((D / "openr1/data").glob("train-*.parquet")):
        t = pq.read_table(f, columns=["problem", "generations"])
        ks = pc.list_value_length(t.column("generations")).to_pylist()
        for row, (p, k) in enumerate(zip(t.column("problem").to_pylist(), ks)):
            assert p and k and k >= 1, (f.name, row)
            key = hashlib.sha256(p.encode("utf-8")).digest()
            assert key not in keys, (f.name, row)  # 题面必须两两不同，否则标识不唯一
            keys.add(key)
            pick, half = draw(b"pick", key, k), draw(b"half", key, 2)
            by_k[(k, pick)] += 1
            halves[half] += 1
            fh.write(f"{key.hex()}\t{f.name}\t{row}\t{k}\t{pick}\t{half}\n")
        del t

summary = {
    "说明": "主样本抽样映射的摘要；映射文件在仓外，按下面的 sha256 核对",
    "种子": SEED.decode(),
    "取法": "key=sha256(题面 UTF-8)；pick=sha256(种子+\\0pick\\0+key) 前 8 字节大端整数 % 回答条数；half 同法 % 2",
    "题数": len(keys),
    "前一半 / 后一半": [halves[0], halves[1]],
    "各回答条数下 pick 的分布": {str(k): [by_k[(k, i)] for i in range(k)] for k in sorted({k for k, _ in by_k})},
    "映射文件": str(OUT),
    "映射文件 sha256": hashlib.sha256(OUT.read_bytes()).hexdigest(),
}
text = json.dumps(summary, ensure_ascii=False, indent=2)
if len(sys.argv) > 3:
    Path(sys.argv[3]).write_text(text + "\n", encoding="utf-8")
print(text)
