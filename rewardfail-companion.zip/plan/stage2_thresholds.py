"""第二阶段方案的门槛算术（只做算术，不涉及任何数据或判分）。

单侧 95% Clopper–Pearson 界：下界是 P(X>=k | p)=0.05 的 p，上界是 P(X<=k | p)=0.05 的 p。
用二项尾概率二分反演，只用标准库；零事件与闭式公式 1-alpha^(1/n) 对照。
"""
import json
import math
import sys
from pathlib import Path


def cdf(k, n, p):
    """P(X <= k)，X ~ Bin(n, p)。"""
    if k < 0:
        return 0.0
    if p <= 0:
        return 1.0
    if p >= 1:
        return 0.0 if k < n else 1.0
    term = math.exp(n * math.log1p(-p))
    terms = [term]
    for j in range(1, k + 1):
        term *= ((n - j + 1) / j) * (p / (1 - p))
        terms.append(term)
    return min(1.0, math.fsum(terms))


def bisect(f, lo=0.0, hi=1.0, it=200):
    for _ in range(it):
        mid = (lo + hi) / 2
        if f(mid):
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def lower(k, n, alpha):
    """单侧 1-alpha 下界。"""
    if k == 0:
        return 0.0
    return bisect(lambda p: 1 - cdf(k - 1, n, p) < alpha)


def upper(k, n, alpha):
    """单侧 1-alpha 上界。"""
    return bisect(lambda p: cdf(k, n, p) > alpha)


def k_min_lower(n, thr, alpha):
    k = 1
    while lower(k, n, alpha) < thr:
        k += 1
    return k


def k_max_upper(n, thr, alpha):
    k = -1
    while upper(k + 1, n, alpha) < thr:
        k += 1
    return k  # -1 表示连零事件都不够


A = 0.05
out = {"alpha_one_sided": A, "assumption": "独立伯努利观测、单一端点、样本量固定；只做算术"}

for n in (40000, 50000):
    assert abs(upper(0, n, A) - (-math.expm1(math.log(A) / n))) < 1e-12
assert abs(upper(0, 40000, 0.025) - 9.221773403618501e-05) < 1e-12  # 与 Codex 的双侧零事件结果对照
assert k_min_lower(5000, 1e-3, 0.025) == 11  # 与 Codex 的双侧结果对照

primary = {}
for n in (93733, 60000, 40000):
    primary[str(n)] = {
        "zero_event_upper": upper(0, n, A),
        "max_events_plus_undetermined_for_upper_below_1e-4": k_max_upper(n, 1e-4, A),
        "min_events_for_lower_at_least_1e-3": k_min_lower(n, 1e-3, A),
        "lower_at_that_k": lower(k_min_lower(n, 1e-3, A), n, A),
    }
out["overall_endpoint"] = primary
out["min_n_zero_event_upper_below_1e-4"] = math.floor(math.log(A) / math.log1p(-1e-4)) + 1

conf = {}
for nt in (2000, 5000, 10000, 20000, 46866):
    conf[str(nt)] = {str(m): k_min_lower(nt, 1e-3, A / m) for m in (1, 3, 7)}
out["type_confirmation_min_events_lower_at_least_1e-3_by_flagged_types_m"] = conf

audit = {}
for n_audit in (1000, 3000):
    audit[str(n_audit)] = upper(0, n_audit, A)
out["sanity_sample_zero_event_upper"] = audit

text = json.dumps(out, ensure_ascii=False, indent=2)
if len(sys.argv) > 1:
    Path(sys.argv[1]).write_text(text + "\n", encoding="utf-8")
print(text)
