"""核 rewardfail/s2/mem.py 的读数（10-07）：resident_size 应与 psutil 的 rss 一致；写满一块高度可压缩的内存后，
footprint 应涨上去且不因压缩回落，RSS 会掉；lifetime max 不回落。另核读不了的进程（pid 1）报错而不是给 0。"""
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import psutil  # noqa: E402

from rewardfail.s2 import mem  # noqa: E402

M = 1 << 20


def snap(tag):
    fp, fpmax, res = mem.usage()
    print(json.dumps({"tag": tag, "psutil_rss_MiB": psutil.Process().memory_info().rss // M, "resident_MiB": res // M,
                      "footprint_MiB": fp // M, "lifetime_max_MiB": fpmax // M}, ensure_ascii=False), flush=True)


snap("开始")
buf = bytearray(b"\x01") * (600 * M)
snap("写满 600 MiB 同一字节之后")
for i in range(4):
    time.sleep(5)
    snap(f"+{5 * (i + 1)} 秒")
del buf
snap("释放之后")
try:
    mem.usage(1)
    print(json.dumps({"pid1": "读到了（不应如此）"}, ensure_ascii=False))
except mem.Gone:
    print(json.dumps({"pid1": "Gone（不应如此）"}, ensure_ascii=False))
except OSError as e:
    print(json.dumps({"pid1": f"OSError errno={e.errno}，符合预期"}, ensure_ascii=False))
p = psutil.Popen([sys.executable, "-c", "pass"])
p.wait()
try:
    mem.usage(p.pid)
    print(json.dumps({"exited_child": "已回收的子进程还读到了（不应如此）"}, ensure_ascii=False))
except mem.Gone:
    print(json.dumps({"exited_child": "Gone，符合预期"}, ensure_ascii=False))
