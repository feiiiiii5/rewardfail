"""生成环节的替身：不调用模型，直接把每行 extra_info["fixed_response"] 编码成回答 token。

只替换“建提示词 + 模型生成”这一段；之后的 _agent_loop_postprocess、_compute_score（真实打分进程）、
_postprocess（第一条汇总路径）和 AgentLoopManager 的跨进程合并，都是被测的真实代码。
"""

from typing import Any

from verl.experimental.agent_loop.agent_loop import AgentLoopBase, AgentLoopMetrics, AgentLoopOutput


class FixedResponseAgentLoop(AgentLoopBase):
    def __init__(self, trainer_config, server_manager, tokenizer, processor, dataset_cls, data_config, **kwargs):
        self.config = trainer_config.config
        self.tokenizer = tokenizer

    async def run(self, sampling_params: dict[str, Any], **kwargs) -> AgentLoopOutput:
        prompt_text = "".join(m["content"] for m in kwargs["raw_prompt"])
        response_text = kwargs["extra_info"]["fixed_response"]
        prompt_ids = self.tokenizer.encode(prompt_text, add_special_tokens=False)
        response_ids = self.tokenizer.encode(response_text, add_special_tokens=False) + [self.tokenizer.eos_token_id]
        return AgentLoopOutput(
            prompt_ids=prompt_ids,
            response_ids=response_ids,
            response_mask=[1] * len(response_ids),
            num_turns=2,
            metrics=AgentLoopMetrics(),
            extra_fields={"turn_scores": [], "tool_rewards": []},
        )
