"""故障注入：被标记的回答一进入 Math-Verify 子进程，子进程就直接退出（模拟子进程被杀，例如被系统 OOM 杀掉）。

只替换 #8015 包装里交给进程池的那个函数 `_verify_in_subprocess`。进程池、坏池后重建并重试一次、
重试仍失败就往上抛、管理器捕获并写 `error`、两条汇总路径，都是被测的真实代码。
标记在两次尝试里都会触发，所以这是“持续失败”；不带标记的回答走原函数，结果与未注入时相同。
"""

import json
import os
import re
import time

MARKER = "[[INJECT_WORKER_DEATH]]"
EXIT_CODE = 17
# 台账：每次注入触发、子进程退出前追加一行，作为“注入确实发生、且重试后又发生一次”的独立证据（不依赖日志收集）
LEDGER_ENV = "REWARDFAIL_INJECT_LEDGER"


def verify_or_die(ground_truth_boxed: str, model_output: str) -> float:
    if MARKER in model_output:
        ledger = os.environ.get(LEDGER_ENV)
        if ledger:
            m = re.search(r"#row=(\d+)", model_output)
            with open(ledger, "a") as f:
                f.write(json.dumps({"row": int(m.group(1)) if m else None, "pid": os.getpid(), "t": time.time()}) + "\n")
        os._exit(EXIT_CODE)
    # 子进程里重新导入的是未被替换的原模块，所以这里调用的是 #8015 原函数
    from verl.utils.reward_score import math_verify as wrapper

    return wrapper._verify_in_subprocess(ground_truth_boxed, model_output)
