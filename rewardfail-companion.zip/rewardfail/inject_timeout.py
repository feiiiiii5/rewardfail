"""C1a 的注入：让 Math-Verify 库内“被计时的那一步”真的变慢，库自己的计时器和捕获层保持原样。

在 #8015 包装交给进程池的子进程里执行（替换 `_verify_in_subprocess`，见 c1a 脚本）：
- [[SLOW_PARSE]]：回答（第二次 parse 调用）的 latex2sympy 先睡 SLEEP 秒，落在 parse 的 5 秒计时内；
- [[SLOW_VERIFY]]：sympy_expr_eq 先睡 SLEEP 秒，落在 verify 每对比较的 5 秒计时内；
- [[SLOW_OUTSIDE]]：在调用 parse 之前睡 SLEEP 秒，不在库的任何计时内（只有外层等待能截住）；
- [[RAISE_TIMEOUT]]：子进程直接抛 TimeoutException（外壳阳性对照：证明这个分支在异常真的传上来时能用）。
time.sleep 可以被 SIGALRM 打断，所以库的计时器一到就会在睡眠处抛 TimeoutException，与真实的慢步骤走同一条捕获路径。
"""

import time

SLEEP = 8.0


def verify_with_injection(ground_truth_boxed: str, model_output: str) -> float:
    import math_verify.grader as G
    import math_verify.parser as P
    from math_verify.errors import TimeoutException

    saved = (P.latex2sympy, G.sympy_expr_eq)
    try:
        if "[[RAISE_TIMEOUT]]" in model_output:
            raise TimeoutException("injected: shell-level positive control")
        if "[[SLOW_OUTSIDE]]" in model_output:
            time.sleep(SLEEP)
        if "[[SLOW_PARSE]]" in model_output:
            orig = P.latex2sympy
            calls = {"n": 0}

            def slow_latex2sympy(*a, **k):
                calls["n"] += 1
                if calls["n"] >= 2:  # 第一次是标准答案，第二次起是回答
                    time.sleep(SLEEP)
                return orig(*a, **k)

            P.latex2sympy = slow_latex2sympy
            P.parse_latex_cached.cache_clear()
            P.extract_latex.cache_clear()
        if "[[SLOW_VERIFY]]" in model_output:
            orig_eq = G.sympy_expr_eq

            def slow_eq(*a, **k):
                time.sleep(SLEEP)
                return orig_eq(*a, **k)

            G.sympy_expr_eq = slow_eq
        clean = model_output
        for tag in ["[[SLOW_PARSE]]", "[[SLOW_VERIFY]]", "[[SLOW_OUTSIDE]]"]:
            clean = clean.replace(tag, "")
        from verl.utils.reward_score import math_verify as wrapper  # 子进程里是未被替换的原模块

        return wrapper._verify_in_subprocess(ground_truth_boxed, clean)
    finally:
        P.latex2sympy, G.sympy_expr_eq = saved
        P.parse_latex_cached.cache_clear()
        P.extract_latex.cache_clear()
