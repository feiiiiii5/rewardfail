"""verl 的自定义奖励函数文件（config.reward.custom_reward_function.path 指向这里）。

#8015 的 Math-Verify 包装签名是 compute_score(model_output, ground_truth, ...)，不能直接当
rate_limited 管理器要求的 compute_score(data_source, solution_str, ground_truth, extra_info) 用；
这里只做参数转接，并在本进程装上注入钩子（见 inject.py）。
"""

from verl.utils.reward_score import math_verify as wrapper

from rewardfail import inject

wrapper._verify_in_subprocess = inject.verify_or_die


def compute_score(data_source, solution_str, ground_truth, extra_info=None, **kwargs):
    return wrapper.compute_score(solution_str, ground_truth)
