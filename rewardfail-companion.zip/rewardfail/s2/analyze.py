"""把一个运行目录里的父侧观测、子侧观测、整机保护与结果合成逐行记录，并做完整性检查（方案第 4、11.2 节；
Codex 10-07 审核第 13.2 节第 1 项）。

逐行：每次尝试的池代次、外层等待的结局、子进程里每一步（哪一侧、墙钟、结果、库日志类别、计时信号时刻、内存），
本行线程里的重置与杀进程，相关子进程的实际退出码，整机保护的终止，外部故障。
检查不过的行标“观测不完整”，分析时按未裁定处理，不默认为正常。检查分几类（check_row）：
- 序号：父侧文件的 seq、每行的 rseq，子侧文件的 fseq、每个任务的 tseq，都必须从 0 起连续、不重复；
  每行以 row_begin 开始、row_end 结束。缺行、多行都查得出来；整个文件缺行时，这个测量进程或子进程的行全部标出。
- 父侧：每次尝试恰好一条提交记录；提交成功的恰好一条等待结局；同一次尝试的池代次一致；尝试编号与结果行对得上。
- 关联：子侧记录只来自一个子进程，池代次与父侧这次尝试相同，测量进程相同，子进程在父侧登记过的这一代池里；
  子侧收到的模式、时限与注入与本行开始时记的相同。
- 子任务：恰好一条开始记录（第一条），至多一条结束记录（最后一条）；步骤编号从 1 起连续，每步一条开始、至多一条结束，
  种类前后相同；顺序只能是 标准答案解析 → 回答解析 → 比较……，前一步结束后一步才开始；只有没结束的任务的最后一步
  可以没有结束记录。被测包装总是先解析两侧：正常结束的任务必须有两次完整的解析记录；两侧都解析出东西才比较，
  比较的次数和结果要能按包装的循环（每个回答项依次比标准答案项，遇到相等就换下一个回答项）复现，任务结果等于
  “有一次比较相等”；有一侧没解析出东西就不该有比较、结果是 0。以异常结束的任务，异常要来自最后一步。
  没结束的任务要有子进程退出、整机保护终止或外部故障的记录。
- 计时信号：任务结束时记的信号次数要等于各步记到的次数之和（每次信号都落在某一步里）；另有逐步的时间规则（多于一次、
  有库超时日志却没收到信号、有库超时日志而墙钟比时限短、没收到信号而墙钟比时限长）。
- 结局：得分要与子任务结果相同；外层超时要有取消、重置、杀掉运行它的子进程与其退出记录；池损坏要有这一代池的
  子进程退出或终止记录；库超时异常要来自子任务的超时异常；没有子侧记录的尝试，只允许提交时池已损坏，或这一代池
  有终止记录的池损坏与外层超时。
旧记录（10-07 修订前，没有序号与 row_begin）用 strict=False 复核：跳过序号、参数与信号总数三项，其余照查。
另记不影响裁定的标记（flags）：收到计时信号、库没记超时；计时信号晚到（比时限晚 1 秒以上才轮到处理函数）。

本机预算终止的归因（10-08 修订，方案第 18.3 节第 1 项）：整机保护杀掉一个池子进程，只记到被杀时结果还没送回父侧的
尝试上——运行它的子进程或同一代池里的子进程被杀，且这次尝试没有在被杀前 KILL_MARGIN 秒以上完整返回。完整返回指：
子侧恰好一条任务结束记录、父侧恰好一条提交成功与一条等待结局、结局是得分或子任务抛回的异常（不是池损坏、外层超时）、
子侧记录只来自父侧登记过的这一代池里的那一个子进程；取子侧结束与父侧收到两者较晚的时刻。不满足的（仍在执行、池损坏、
外层超时、记录不全）照旧记预算终止。修订前按子进程 pid 和池代次贴到它判过的所有行上，一个子进程连判几千行后被杀，
此前早已正常返回的行也被记成未裁定（主测量参照段 9,866 行）。
"""
import json
import os
import shutil
from collections import defaultdict
from pathlib import Path

LIMIT_DEFAULT = {"parse": 5, "compare": 5}
TOL = 0.5  # 秒：库的计时用整秒 alarm，墙钟比时限略长或略短的容差
KIND_AT = ("gold_parse", "pred_parse")  # 第 1、2 步；之后都是 compare
RETURNED = ("score", "lib_timeout_exc", "other_exc")  # 父侧收到子任务送回的结果（得分或子任务抛回的异常）
KILL_MARGIN = 1.0  # 秒：完整返回要早于预算终止的记录时刻这么多才不受它影响（各进程同用 time.time()，保护日志记到毫秒）


def _jsonl(path):
    out = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.strip():
            out.append(json.loads(line))
    return out


def seq_problem(seqs, what):
    """序号必须从 0 起连续、不重复；返回问题文字或 None。"""
    if any(s is None for s in seqs):
        return f"{what}缺序号"
    if seqs != list(range(len(seqs))):
        dup = len(seqs) - len(set(seqs))
        top = max(seqs) + 1 if seqs else 0
        return f"{what}序号不连续（{len(seqs)} 条，重复 {dup}，缺 {max(0, top - len(set(seqs)))}）"
    return None


class FileSeq:
    """边读边核一个文件的序号（父侧 seq、子侧 fseq）。"""

    def __init__(self, key):
        self.key, self.n, self.bad = key, 0, None

    def add(self, e):
        if self.bad is None and e.get(self.key) != self.n:
            self.bad = f"第 {self.n} 行的{self.key} 是 {e.get(self.key)}"
        self.n += 1


def load_run(run_dir, strict=True):
    run = Path(run_dir)
    parent, fprob = [], {"workers": {}, "pids": {}}
    for f in sorted(run.glob("obs-*.jsonl")):
        w = f.stem[len("obs-"):]
        fs = FileSeq("seq")
        for e in _jsonl(f):
            e["worker"] = w
            fs.add(e)
            parent.append(e)
        if strict and fs.bad:
            fprob["workers"][w] = f"测量进程观测文件 {f.name} 缺行或多行（{fs.bad}）"
    child = []
    for f in sorted((run / "child_logs").glob("child-*.jsonl")):
        fs = FileSeq("fseq")
        evs = _jsonl(f)
        for e in evs:
            fs.add(e)
        if strict and fs.bad and evs:
            fprob["pids"][evs[0]["pid"]] = f"子进程文件 {f.name} 缺行或多行（{fs.bad}）"
        child += evs
    guard = []
    for f in sorted(run.glob("guard*.jsonl")):
        guard += _jsonl(f)
    results, dups = {}, set()
    for f in sorted(run.glob("results-*.jsonl")):
        for r in _jsonl(f):
            if r["id"] in results:
                dups.add(r["id"])
            results[r["id"]] = r
    warms = []
    for f in sorted(run.glob("warm-*.jsonl")):
        for r in _jsonl(f):
            warms.append(r)
            if str(r["id"]).startswith("warm-"):
                results[r["id"]] = dict(r, worker=f.stem[len("warm-"):], warm=True)
    ipath = run / "interrupts.json"
    interrupts = json.loads(ipath.read_text(encoding="utf-8")) if ipath.exists() else {}
    return {"parent": parent, "child": child, "guard": guard, "results": results, "warms": warms,
            "interrupts": interrupts, "file_problems": fprob, "dup_results": dups, "strict": strict}


def summarize(run):
    """返回 {请求编号: 逐行记录}；预热行也在里面（编号以 warm- 开头）。"""
    strict = run.get("strict", True)
    by_req = defaultdict(list)
    for e in run["parent"]:
        if e.get("req") is not None:
            by_req[e["req"]].append(e)
    child_by = defaultdict(lambda: defaultdict(list))
    for e in run["child"]:
        child_by[e["req"]][e["att"]].append(e)
    # 全局：池代次 → 子进程（父侧登记的、另加子侧报的）；子进程 → 退出码；谁杀的
    exits, reg_pids, gen_pids = {}, defaultdict(set), defaultdict(set)
    for e in run["parent"]:
        key = (e["worker"], e.get("pid"))
        if e["ev"] == "proc_exit":
            exits[key] = e["code"]
        elif e["ev"] == "proc_new":
            reg_pids[(e["worker"], e["gen"])].add(e["pid"])
            gen_pids[(e["worker"], e["gen"])].add(e["pid"])
    for e in run["child"]:  # 子侧日志也带 pid 与池代次：池损坏的连带核查要看到这一代池里所有跑过任务的子进程
        w = e.get("worker") or (run["results"].get(e["req"]) or {}).get("worker")
        if w is not None:
            gen_pids[(w, e["gen"])].add(e["pid"])
    budget_kills = defaultdict(list)
    for e in run["guard"]:
        if e["ev"] == "budget_kill":
            budget_kills[e["pid"]].append(e)
    fault_pids, fault_gens = set(), set()
    for e in run["parent"]:
        if e["ev"] == "fault_kill":
            fault_pids |= set(e["pids"])
            fault_gens.add((e["worker"], e["gen"]))
    fprob = run.get("file_problems") or {"workers": {}, "pids": {}}
    dups = run.get("dup_results") or set()

    rows = {}
    reqs = set(by_req) | set(run["results"])
    for req in sorted(reqs, key=str):
        # 中断后重跑的行，几次启动的尝试编号都从 1 起：只取产出最终结果的那个测量进程的记录（子侧事件也带测量进程名）
        fw = (run["results"].get(req) or {}).get("worker")
        evs = [e for e in by_req.get(req, []) if fw is None or e["worker"] == fw]
        worker = fw or (evs[0]["worker"] if evs else None)
        atts, resets, kills, faults, pre = {}, [], [], [], []
        begin = None
        for e in evs:
            ev = e["ev"]
            if ev == "row_begin":
                begin = {k: e.get(k) for k in ("inject", "limits", "mode")}
            elif ev in ("submit", "submit_exc"):
                a = atts.setdefault(e["att"], {"att": e["att"], "gen": e["gen"]})
                a["n_submit"] = a.get("n_submit", 0) + 1
                a.setdefault("gens", set()).add(e["gen"])
                a["submitted"] = ev == "submit"
                if ev == "submit_exc":
                    a["outcome"], a["exc"] = e["outcome"], e["exc"]
            elif ev == "wait_end":
                a = atts.setdefault(e["att"], {"att": e["att"], "gen": e["gen"]})
                a["n_wait"] = a.get("n_wait", 0) + 1
                a.setdefault("gens", set()).add(e["gen"])
                a["outcome"], a["waited"], a["timeout"] = e["outcome"], e["waited"], e["timeout"]
                if e["outcome"] == "score":
                    a["score"] = e["score"]
                else:
                    a["exc"] = e["exc"]
                a["t_wait_end"] = e["t"]
            elif ev == "cancel":
                a = atts.setdefault(e["att"], {"att": e["att"], "gen": e["gen"]})
                a["cancel_ok"] = e["ok"]
                a.setdefault("gens", set()).add(e["gen"])
            elif ev == "reset_enter":
                resets.append({"gen": e["gen"], "is_current": e["is_current"], "pids": e["pids"], "t": e["t"],
                               "kills": []})
            elif ev == "reset_exit":
                if resets:
                    resets[-1]["current_gen_after"] = e["current_gen"]
            elif ev in ("proc_kill", "proc_terminate") and not e.get("mgmt"):
                k = {"pid": e["pid"], "gen": e["gen"], "how": ev, "t": e["t"]}
                kills.append(k)
                if resets:
                    resets[-1]["kills"].append(e["pid"])
            elif ev == "fault_kill":
                faults.append({"why": e["why"], "pids": e["pids"], "gen": e["gen"]})
        if strict and fw is not None:
            pre.append(seq_problem([e.get("rseq") for e in evs], "父侧本行"))
            if not evs or evs[0]["ev"] != "row_begin":
                pre.append("父侧本行没有以开始记录起头")
            if not evs or evs[-1]["ev"] != "row_end" or evs[-1].get("n") != evs[-1].get("rseq"):
                pre.append("父侧本行没有完整的结束记录")
            if sum(e["ev"] == "row_begin" for e in evs) > 1 or sum(e["ev"] == "row_end" for e in evs) > 1:
                pre.append("父侧本行的开始或结束记录不止一条")
        for att, cev in sorted(child_by.get(req, {}).items()):
            cev = [e for e in cev if fw is None or e.get("worker") in ((fw,) if strict else (None, fw))]
            if not cev:
                continue
            a = atts.setdefault(att, {"att": att, "gen": cev[0]["gen"]})
            c = {"pid": cev[0]["pid"], "steps": [], "logs": [], "task_end": None, "task_start": None,
                 "pids": {e["pid"] for e in cev}, "gens": {e["gen"] for e in cev}, "workers": {e.get("worker") for e in cev},
                 "tseqs": [e.get("tseq") for e in cev], "first_ev": cev[0]["ev"], "last_ev": cev[-1]["ev"],
                 "n_task_start": 0, "n_task_end": 0}
            steps = {}
            for pos, e in enumerate(cev):
                if e["ev"] == "task_start":
                    c["n_task_start"] += 1
                    c["task_start"] = {k: e.get(k) for k in ("mode", "limits", "inject", "hooks", "gt_len", "out_len",
                                                             "gt_sha", "out_sha", "maxrss", "fp", "fp_max")}
                    c["t_start"] = e["t"]
                elif e["ev"] == "step_start":
                    s = steps.setdefault(e["step"], {"step": e["step"], "kind": e["kind"], "logs": [], "end": False,
                                                     "n_start": 0, "n_end": 0, "kinds": set()})
                    s["n_start"] += 1
                    s["kinds"].add(e["kind"])
                    s["t0"], s["i0"] = e["t"], pos
                elif e["ev"] == "step_end":
                    s = steps.setdefault(e["step"], {"step": e["step"], "kind": e["kind"], "logs": [], "end": False,
                                                     "n_start": 0, "n_end": 0, "kinds": set()})
                    s["n_end"] += 1
                    s["kinds"].add(e["kind"])
                    s["i1"] = pos
                    s.update(end=True, wall=e["wall"], cpu=e["cpu"], res=e.get("res"), exc=e.get("exc"), t1=e["t"],
                             alarms=e.get("alarms") or [], maxrss=e.get("maxrss"), fp=e.get("fp"), fp_max=e.get("fp_max"))
                elif e["ev"] == "log":
                    item = {"level": e["level"], "cat": e["cat"], "exc": e["exc"], "msg_len": e["msg_len"]}
                    if e["step"] in steps:
                        steps[e["step"]]["logs"].append(item)
                    else:
                        c["logs"].append(item)
                elif e["ev"] == "task_end":
                    c["n_task_end"] += 1
                    c["t_end"] = e["t"]
                    c["task_end"] = {"res": e.get("res"), "exc": e.get("exc"), "wall": e["wall"], "cpu": e["cpu"],
                                     "maxrss": e.get("maxrss"), "fp": e.get("fp"), "fp_max": e.get("fp_max"),
                                     "alarms_total": e.get("alarms_total")}
                    if "res" not in e:
                        c["task_end"].pop("res")
                elif e["ev"] == "inject_exit":
                    c["inject_exit"] = e["code"]
            c["steps"] = [steps[k] for k in sorted(steps)]
            a["child"] = c
        for a in atts.values():
            a["begin"] = begin
        rows[req] = {"id": req, "worker": worker, "result": run["results"].get(req),
                     "attempts": [atts[k] for k in sorted(atts)], "resets": resets, "kills": kills, "faults": faults,
                     "_pre": [x for x in pre if x], "_file": [], "_strict": strict}
        if fw in fprob["workers"]:
            rows[req]["_file"].append(fprob["workers"][fw])
        if req in dups:
            rows[req]["_file"].append("结果行重复")

    # 补上每次尝试相关子进程的退出码与终止来源
    for row in rows.values():
        w = row["worker"]
        for a in row["attempts"]:
            c = a.get("child")
            if c:
                pid = c["pid"]
                c["exit"] = exits.get((w, pid))
                c["fault_killed"] = pid in fault_pids
                c["registered"] = pid in reg_pids.get((w, a["gen"]), ())
                if pid in fprob["pids"]:
                    row["_file"].append(fprob["pids"][pid])
            elif any(p in fprob["pids"] for p in gen_pids.get((w, a["gen"]), ())):
                row["_file"].append(f"第 {a['att']} 次尝试那一代池的子进程文件缺行或多行")
            done = returned_at(a)
            hit = [p for p in ({c["pid"]} if c else set()) | gen_pids.get((w, a["gen"]), set())
                   if any(done is None or done > k["t"] - KILL_MARGIN for k in budget_kills.get(p, ()))]
            if c:
                c["budget_killed"] = c["pid"] in hit
            a["returned_at"] = done
            a["gen_exits"] = {str(p): exits.get((w, p)) for p in sorted(gen_pids.get((w, a["gen"]), ()))}
            a["gen_budget_kills"] = sorted(p for p in hit if p in gen_pids.get((w, a["gen"]), ()))
            a["gen_fault_kills"] = sorted(p for p in gen_pids.get((w, a["gen"]), ()) if p in fault_pids)
            a["gen_fault"] = (w, a["gen"]) in fault_gens
        for k in row["kills"]:
            k["exit"] = exits.get((w, k["pid"]))
        row["problems"] = check_row(row)
        row["flags"] = step_flags(row)
        row["class"] = classify(row)
    return rows


def returned_at(a):
    """这次尝试的结果完整送回父侧的时刻（子侧任务结束与父侧收到两者较晚的）；没有完整送回，或记录不全、关联不上，返回 None。"""
    c = a.get("child")
    if (not c or c.get("t_end") is None or c["n_task_end"] != 1 or c["last_ev"] != "task_end"
            or len(c["pids"]) != 1 or c["gens"] != {a["gen"]} or not c.get("registered")):
        return None
    if (not a.get("submitted") or a.get("n_submit") != 1 or a.get("n_wait") != 1 or a.get("outcome") not in RETURNED
            or a.get("t_wait_end") is None or len(a.get("gens") or ()) != 1):
        return None
    te = c["task_end"]
    if (te.get("res") != a.get("score")) if a["outcome"] == "score" else (te.get("exc") != a.get("exc")):
        return None  # 父侧收到的与子侧送出的对不上
    return max(c["t_end"], a["t_wait_end"])


def _limits(c):
    lim = dict(LIMIT_DEFAULT)
    ts = (c or {}).get("task_start") or {}
    lim.update(ts.get("limits") or {})
    return lim


NAMES = {"mode": "模式", "limits": "时限", "inject": "注入"}


def replay_compares(n_gold, n_pred, results):
    """按被测包装的循环复现比较序列：max(1.0 if any(verify(g, p) for g in gold) else 0.0 for p in pred)，
    即每个回答项依次比标准答案项，遇到相等就换下一个回答项。返回 (次数与顺序对得上, 应得分)。"""
    i = 0
    for _ in range(n_pred):
        for _ in range(n_gold):
            if i >= len(results):
                return False, None
            i += 1
            if results[i - 1] is True:
                break
    return i == len(results), (1.0 if any(r is True for r in results) else 0.0)


def child_problems(a, c, tag, strict, worker):
    """一次尝试的子侧记录：关联、结构、结果能否由步骤复现、计时信号是否都落在步骤里。"""
    p = []
    if len(c["pids"]) != 1:
        p.append(f"{tag}：子侧记录来自 {len(c['pids'])} 个子进程")
    if c["gens"] != {a["gen"]}:
        p.append(f"{tag}：子侧池代次 {sorted(c['gens'])} 与父侧第 {a['gen']} 代不符")
    if strict and c["workers"] != {worker}:
        p.append(f"{tag}：子侧记的测量进程 {sorted(map(str, c['workers']))} 与 {worker} 不符")
    if not c.get("registered"):
        p.append(f"{tag}：子进程 {c['pid']} 不在父侧登记的第 {a['gen']} 代池里")
    if strict and c["tseqs"] != list(range(len(c["tseqs"]))):
        p.append(f"{tag}：子任务记录序号不连续（{len(c['tseqs'])} 条）")
    if c["n_task_start"] != 1 or c["first_ev"] != "task_start":
        p.append(f"{tag}：子任务开始记录 {c['n_task_start']} 条，或不是第一条")
    if c["n_task_end"] > 1 or (c["n_task_end"] == 1 and c["last_ev"] != "task_end"):
        p.append(f"{tag}：子任务结束记录 {c['n_task_end']} 条，或不是最后一条")
    ts = c.get("task_start") or {}
    b = a.get("begin")
    if strict and b is not None:
        for k, name in NAMES.items():
            if ts.get(k) != b.get(k):
                p.append(f"{tag}：子侧收到的{name}与本行开始时记的不同")
    hooks = ts.get("hooks") or {}
    if hooks and (hooks.get("handlers") != 1 or hooks.get("installs") != 1 or not hooks.get("parse_ours")
                  or not hooks.get("verify_ours") or not hooks.get("alarm_ours")):
        p.append(f"{tag}：子进程钩子安装异常 {hooks}")
    te = c.get("task_end")
    if te is None and c["exit"] is None and not c["budget_killed"] and not c["fault_killed"]:
        p.append(f"{tag}：子任务没结束，也没有子进程退出或终止记录")

    steps = c["steps"]
    if [s["step"] for s in steps] != list(range(1, len(steps) + 1)):
        p.append(f"{tag}：步骤编号不连续 {[s['step'] for s in steps]}")
    for i, s in enumerate(steps):
        want = KIND_AT[i] if i < len(KIND_AT) else "compare"
        if s["n_start"] != 1 or s["n_end"] > 1 or len(s["kinds"]) != 1:
            p.append(f"{tag} 第 {s['step']} 步：开始记录 {s['n_start']} 条、结束记录 {s['n_end']} 条、种类 {sorted(s['kinds'])}")
        if s["kind"] != want:
            p.append(f"{tag} 第 {s['step']} 步是 {s['kind']}，按包装的顺序应是 {want}")
        if s.get("i1") is not None and s.get("i0") is not None and s["i1"] < s["i0"]:
            p.append(f"{tag} 第 {s['step']} 步的结束记录在开始记录之前")
        if i + 1 < len(steps):
            if not s["end"]:
                p.append(f"{tag} 第 {s['step']} 步没有结束记录，后面却还有步骤")
            elif steps[i + 1].get("i0") is not None and s.get("i1") is not None and steps[i + 1]["i0"] < s["i1"]:
                p.append(f"{tag} 第 {s['step']} 步还没结束，第 {s['step'] + 1} 步就开始了")
    if te is not None:
        if steps and not steps[-1]["end"]:
            p.append(f"{tag} 最后一步没有结束记录，任务却结束了")
        if te.get("exc"):
            last = steps[-1] if steps else None
            if last is None:
                if not (ts.get("inject") or {}).get("raise_task_timeout"):
                    p.append(f"{tag}：子任务以 {te['exc']} 结束，却没有任何步骤")
            elif last.get("exc") != te["exc"]:
                p.append(f"{tag}：子任务以 {te['exc']} 结束，最后一步的结局却是 {last.get('exc') or '正常返回'}")
            for s in steps[:-1]:
                if s.get("exc"):
                    p.append(f"{tag} 第 {s['step']} 步以 {s['exc']} 结束，任务却继续往下走")
        else:
            for s in steps:
                if s.get("exc"):
                    p.append(f"{tag} 第 {s['step']} 步以 {s['exc']} 结束，任务却正常返回")
            if len(steps) < 2 or not (steps[0]["end"] and steps[1]["end"]):
                p.append(f"{tag}：子任务正常结束，却没有两次完整的解析记录")
            elif not isinstance(steps[0].get("res"), list) or not isinstance(steps[1].get("res"), list):
                p.append(f"{tag}：解析步骤的结果记录不是列表")
            else:
                g, q = steps[0]["res"], steps[1]["res"]
                cmp = [s.get("res") for s in steps[2:]]
                if g and q:
                    ok, want = replay_compares(len(g), len(q), cmp)
                    if not ok or any(not isinstance(r, bool) for r in cmp):
                        p.append(f"{tag}：两侧各解析出 {len(g)}、{len(q)} 项，比较记录 {len(cmp)} 次，按包装的循环对不上")
                    elif te.get("res") != want:
                        p.append(f"{tag}：子任务结果 {te.get('res')} 与比较记录推出的 {want} 不符")
                else:
                    if cmp:
                        p.append(f"{tag}：有一侧没解析出东西，却记了 {len(cmp)} 次比较")
                    if te.get("res") != 0.0:
                        p.append(f"{tag}：有一侧没解析出东西，子任务结果却是 {te.get('res')}")
        if strict:
            n_al = sum(len(s.get("alarms") or []) for s in steps)
            if te.get("alarms_total") != n_al:
                p.append(f"{tag}：任务里收到 {te.get('alarms_total')} 次计时信号，各步只记到 {n_al} 次")

    lim = _limits(c)
    for s in steps:
        if not s.get("end"):
            continue
        kind = "parse" if s["kind"].endswith("parse") else "compare"
        cats = [lg["cat"] for lg in s["logs"]]
        timed = any(x.startswith("Timeout") for x in cats)
        al = s.get("alarms") or []
        if len(al) > 1:
            p.append(f"{tag} {s['kind']}：一步里记到 {len(al)} 次计时信号")
        if timed and not al:
            p.append(f"{tag} {s['kind']}：有库超时日志，却没有计时信号记录")
        if timed and s["wall"] < lim[kind] - TOL:
            p.append(f"{tag} {s['kind']}：记了库超时，但墙钟只有 {s['wall']} 秒")
        if not al and s["wall"] > lim[kind] + 1:
            p.append(f"{tag} {s['kind']}：墙钟 {s['wall']} 秒超过时限，却没有计时信号记录")
    return p


def check_row(row):
    """观测一致性检查；返回问题列表（空表示一致）。各类检查见文件开头。"""
    res = row["result"]
    if res is None:
        return ["没有结果行"]
    p = list(row.get("_file") or [])
    if res.get("mode") == "off":
        return p
    p += row.get("_pre") or []
    strict = row.get("_strict", True)
    atts = row["attempts"]
    nums = [a["att"] for a in atts]
    if nums != list(range(1, len(nums) + 1)):
        p.append(f"尝试编号不连续：{nums}")
    if res.get("attempts") is not None and len(atts) != res["attempts"]:
        p.append(f"尝试数不符：父侧记了 {len(atts)} 次，测量进程数到 {res['attempts']} 次")
    if len(atts) > 2:
        p.append(f"尝试 {len(atts)} 次，包装最多两次")
    for a in atts[:-1]:
        if a.get("outcome") != "broken_pool":
            p.append(f"第 {a['att']} 次尝试的结局是 {a.get('outcome')}，包装不会因此重试")
    for a in atts:
        tag = f"第 {a['att']} 次"
        if a.get("n_submit", 0) != 1:
            p.append(f"{tag}：提交记录 {a.get('n_submit', 0)} 条（应为 1 条）")
        if a.get("submitted") and a.get("n_wait", 0) != 1:
            p.append(f"{tag}：等待结局 {a.get('n_wait', 0)} 条（应为 1 条）")
        if a.get("submitted") is False and a.get("n_wait", 0):
            p.append(f"{tag}：提交时就失败了，却还有等待结局")
        if len(a.get("gens") or {a["gen"]}) > 1:
            p.append(f"{tag}：同一次尝试的池代次不一致 {sorted(a['gens'])}")
        if "outcome" not in a:
            p.append(f"{tag}尝试没有等待结局")
            continue
        c = a.get("child")
        o = a["outcome"]
        if c:
            p += child_problems(a, c, tag, strict, row["worker"])
        elif a.get("submitted") and o not in ("broken_pool", "outer_timeout"):
            p.append(f"{tag}：提交了、结局是 {o}，却没有子侧记录")
        if o == "score":
            if not c or c["task_end"] is None or c["task_end"].get("res") != a.get("score"):
                p.append(f"{tag}：父侧得分 {a.get('score')} 与子任务结果不符")
        elif o == "lib_timeout_exc":
            if c and (c.get("task_end") or {}).get("exc") != "TimeoutException":
                p.append(f"{tag}：父侧收到库超时异常，子任务却不是以超时异常结束")
        elif o == "other_exc" and a.get("submitted"):
            if c and (c.get("task_end") or {}).get("exc") != a.get("exc"):
                p.append(f"{tag}：父侧收到 {a.get('exc')}，子任务结束记录不是这个异常")
        elif o == "outer_timeout":
            rs = [r for r in row["resets"] if r["gen"] == a["gen"]]
            if a.get("cancel_ok") is None:
                p.append(f"{tag}外层超时：没有取消记录")
            if not rs:
                p.append(f"{tag}外层超时：没有重置记录")
            for r in rs:
                if r["is_current"] and (not r["kills"] or not set(r["kills"]) <= set(r["pids"])):
                    p.append(f"{tag}外层超时：重置要杀 {r['pids']}，实际记到 {r['kills']}")
                if r["is_current"] and c and c["pid"] not in r["kills"]:
                    p.append(f"{tag}外层超时：运行这次任务的子进程 {c['pid']} 不在被杀之列")
            if c and c["exit"] is None:
                p.append(f"{tag}外层超时：运行这次任务的子进程 {c['pid']} 没有退出记录")
        elif o == "broken_pool":
            died = [k for k, v in a["gen_exits"].items() if v not in (None, 0)]
            if not died and not a["gen_budget_kills"] and not a["gen_fault_kills"] and not a.get("gen_fault"):
                p.append(f"{tag}池损坏：第 {a['gen']} 代池没有子进程退出或终止记录")
    last = atts[-1] if atts else None
    if last is None:
        p.append("没有任何尝试记录")
    elif res.get("exc"):
        if last.get("outcome") not in ("broken_pool", "other_exc") or last.get("exc") != res["exc"]:
            p.append(f"最终异常 {res['exc']} 与最后一次尝试的结局 {last.get('outcome')} 不符")
    else:
        o = last.get("outcome")
        if o == "score" and last.get("score") != res["score"]:
            p.append(f"最终得分 {res['score']} 与最后一次尝试的得分 {last.get('score')} 不符")
        if o in ("outer_timeout", "lib_timeout_exc") and res["score"] != 0:
            p.append(f"超时结局但最终得分是 {res['score']}")
        if o in ("broken_pool", "other_exc"):
            p.append(f"最后一次尝试是 {o}，却没有最终异常")
    return p


FLAG_NO_LOG = "收到计时信号、库没记超时"


def step_flags(row):
    """不影响裁定的标记：收到计时信号、库没记超时（可能是处理函数抛出的异常被计算代码吞掉，属推断）；计时信号晚到。"""
    out = []
    for a in row["attempts"]:
        c = a.get("child") or {}
        lim = _limits(c)
        for s in c.get("steps") or []:
            if not s.get("end") or not s.get("alarms"):
                continue
            kind = "parse" if s["kind"].endswith("parse") else "compare"
            timed = any(lg["cat"].startswith("Timeout") for lg in s["logs"])
            if not timed:
                out.append(f"第 {a['att']} 次 {s['kind']}：{FLAG_NO_LOG}")
            late = s["alarms"][0] - lim[kind]
            if late > 1:
                out.append(f"第 {a['att']} 次 {s['kind']}：计时信号晚到 {round(late, 1)} 秒")
    return out


def side_events(a):
    """一次尝试里库层面的事件：[(哪一步, 日志类别)]；只看有日志的步骤。"""
    out = []
    for s in ((a.get("child") or {}).get("steps") or []):
        for lg in s["logs"]:
            out.append((s["kind"], lg["cat"]))
    return out


def classify(row):
    res = row["result"]
    if res is None:
        return "没有结果"
    if res.get("undetermined"):
        return "未裁定（" + res["undetermined"] + "）"
    if any(a.get("child", {}).get("budget_killed") or a.get("gen_budget_kills") for a in row["attempts"]):
        return "本机预算终止（未裁定）"
    if row["problems"]:
        return "观测不完整（未裁定）"
    if res.get("exc"):
        return f"最终异常（{res['exc']}）"
    outs = [a.get("outcome") for a in row["attempts"]]
    if res["score"] == 1:
        return "1 分" + ("（重试后）" if len(outs) > 1 else "") + ("，有库超时日志" if any(
            c.startswith("Timeout") for a in row["attempts"] for _, c in side_events(a)) else "")
    if "outer_timeout" in outs:
        return "0 分：外层超时"
    if "lib_timeout_exc" in outs:
        return "0 分：库超时异常（壳层）"
    ev = side_events(row["attempts"][-1]) if row["attempts"] else []
    tags = []
    for kind, cat in ev:
        side = {"gold_parse": "标准答案侧解析", "pred_parse": "回答侧解析", "compare": "比较"}[kind]
        tags.append(f"{side}{'超时' if cat.startswith('Timeout') else '出错'}")
    if tags:
        return "0 分：" + "、".join(sorted(set(tags)))
    return "正常 0"


def run_stats(run, rows):
    gens = defaultdict(set)
    for e in run["parent"]:
        if e["ev"] == "pool_new":
            gens[e["worker"]].add(e["gen"])
    codes = defaultdict(int)
    for e in run["parent"]:
        if e["ev"] == "proc_exit":
            codes[str(e["code"])] += 1
    walls = sorted(r["result"]["wall"] for r in rows.values() if r["result"] and "wall" in r["result"])
    rss = [a["child"]["task_end"].get("fp_max") or 0 for r in rows.values() for a in r["attempts"]
           if a.get("child") and a["child"].get("task_end")]
    return {"pools": {w: len(g) for w, g in gens.items()}, "exit_codes": dict(codes),
            "budget_kills": sum(1 for e in run["guard"] if e["ev"] == "budget_kill"),
            "hard_stops": sum(1 for e in run["guard"] if e["ev"] == "hard_stop"),
            "rows": len([k for k in rows if not str(k).startswith("warm-")]),
            "wall_p50": walls[len(walls) // 2] if walls else None, "wall_max": walls[-1] if walls else None,
            "child_fp_max": max(rss) if rss else None,
            "flags": sum(len(r.get("flags") or []) for r in rows.values())}


# ---------------- 大运行：分桶合成逐行记录 ----------------
GLOBAL_EVS = ("proc_new", "proc_exit", "pool_new", "proc_kill", "proc_terminate", "fault_kill")


def compact_row(row):
    """逐行记录的精简版（主测量分析用）：每步只留哪一步、墙钟、是否结束、库日志类别、计时信号次数。"""
    res = row["result"] or {}
    atts = []
    for a in row["attempts"]:
        c = a.get("child") or {}
        atts.append({"att": a["att"], "gen": a.get("gen"), "outcome": a.get("outcome"), "waited": a.get("waited"),
                     "exit": c.get("exit"), "budget_killed": c.get("budget_killed"),
                     "fp_max": (c.get("task_end") or {}).get("fp_max"),
                     "steps": [[s["kind"], s.get("wall"), bool(s.get("end")), sorted({lg["cat"] for lg in s["logs"]}),
                                len(s.get("alarms") or [])] for s in c.get("steps") or []]})
    return {"id": row["id"], "worker": row["worker"], "class": row["class"], "score": res.get("score"),
            "exc": res.get("exc"), "wall": res.get("wall"), "undetermined": res.get("undetermined"),
            "problems": row["problems"], "flags": row["flags"], "resets": len(row["resets"]), "attempts": atts}


def summarize_stream(run_dir, out_path, batch=2000, strict=True, tick=None):
    """大运行用：先把事件按行分桶写到临时目录，再逐桶合成逐行记录，写成精简的 jsonl；内存只占一桶。

    跨行的事件（新池、子进程登记与退出、杀进程、外部故障）另抄一份去掉行号，放进每一桶。
    预热行一桶（编号 warm-），没有结果的行一桶。文件级的序号与重复结果行在分桶时核，结论带进每一桶。
    tick 是资源保护的检查点（stepguard.StepGuard.tick），每读 5,000 行、每合成一桶调用一次。
    输出先写临时文件，全部写完再改名。返回整个运行的统计。"""
    run = Path(run_dir)
    tick = tick or (lambda: None)
    n_read = [0]

    def read_tick():
        n_read[0] += 1
        if n_read[0] % 5000 == 0:
            tick()

    order = []
    for f in sorted(run.glob("results-*.jsonl")):
        order += [json.loads(x)["id"] for x in f.read_text(encoding="utf-8").splitlines() if x.strip()]
    seen = defaultdict(int)
    for rid in order:
        seen[rid] += 1
    dups = {rid for rid, n in seen.items() if n > 1}
    bucket_of = {rid: i // batch for i, rid in enumerate(dict.fromkeys(order))}

    def bucket(req):
        if req is None:
            return None
        if str(req).startswith("warm-"):
            return "w"
        return bucket_of.get(req, "x")

    tmp = run / "_buckets"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir()
    fhs = {}

    def put(b, kind, e):
        fh = fhs.get((b, kind))
        if fh is None:
            fh = fhs[(b, kind)] = open(tmp / f"{kind}-{b}.jsonl", "a", encoding="utf-8")
        fh.write(json.dumps(e, ensure_ascii=False) + "\n")

    glob, fprob = [], {"workers": {}, "pids": {}}
    for f in sorted(run.glob("obs-*.jsonl")):
        w = f.stem[len("obs-"):]
        fs = FileSeq("seq")
        with open(f, encoding="utf-8") as fh:
            for line in fh:
                if not line.strip():
                    continue
                read_tick()
                e = json.loads(line)
                fs.add(e)
                e["worker"] = w
                b = bucket(e.get("req"))
                if e["ev"] in GLOBAL_EVS:
                    glob.append(dict(e, req=None))
                if b is not None:
                    put(b, "parent", e)
                elif e["ev"] not in GLOBAL_EVS:
                    glob.append(e)
        if strict and fs.bad:
            fprob["workers"][w] = f"测量进程观测文件 {f.name} 缺行或多行（{fs.bad}）"
    for f in sorted((run / "child_logs").glob("child-*.jsonl")):
        fs, pid = FileSeq("fseq"), None
        with open(f, encoding="utf-8") as fh:
            for line in fh:
                if line.strip():
                    read_tick()
                    e = json.loads(line)
                    fs.add(e)
                    pid = e["pid"]
                    put(bucket(e["req"]), "child", e)
        if strict and fs.bad and pid is not None:
            fprob["pids"][pid] = f"子进程文件 {f.name} 缺行或多行（{fs.bad}）"
    for f in sorted(run.glob("results-*.jsonl")):
        for r in _jsonl(f):
            put(bucket(r["id"]), "results", r)
    for f in sorted(run.glob("warm-*.jsonl")):
        for r in _jsonl(f):
            if str(r["id"]).startswith("warm-"):
                put("w", "results", dict(r, worker=f.stem[len("warm-"):], warm=True))
    for fh in fhs.values():
        fh.close()
    guard = []
    for f in sorted(run.glob("guard*.jsonl")):
        guard += _jsonl(f)
    ipath = run / "interrupts.json"
    interrupts = json.loads(ipath.read_text(encoding="utf-8")) if ipath.exists() else {}
    n_rows = n_warm = 0
    out_tmp = Path(str(out_path) + ".tmp")
    with open(out_tmp, "w", encoding="utf-8") as out:
        for b in sorted({b for b, _ in fhs}, key=str):
            tick()
            part = {k: _jsonl(tmp / f"{k}-{b}.jsonl") if (tmp / f"{k}-{b}.jsonl").exists() else []
                    for k in ("parent", "child", "results")}
            results = {}
            for r in part["results"]:
                results[r["id"]] = r
            rows = summarize({"parent": glob + part["parent"], "child": part["child"], "guard": guard,
                              "results": results, "warms": [], "interrupts": interrupts, "file_problems": fprob,
                              "dup_results": dups, "strict": strict})
            for rid in sorted(rows, key=str):
                row = compact_row(rows[rid])
                row["warm"] = b == "w"
                n_warm += row["warm"]
                n_rows += not row["warm"]
                out.write(json.dumps(row, ensure_ascii=False) + "\n")
    os.replace(out_tmp, out_path)
    shutil.rmtree(tmp)
    gens, codes = defaultdict(set), defaultdict(int)
    for e in glob:
        if e["ev"] == "pool_new":
            gens[e["worker"]].add(e["gen"])
        elif e["ev"] == "proc_exit":
            codes[str(e["code"])] += 1
    return {"rows": n_rows, "warm_rows": n_warm, "pools": {w: len(g) for w, g in gens.items()}, "exit_codes": dict(codes),
            "budget_kills": sum(1 for e in guard if e["ev"] == "budget_kill"),
            "hard_stops": sum(1 for e in guard if e["ev"] == "hard_stop"), "interrupted_rows": len(interrupts),
            "file_problems": fprob, "dup_results": sorted(dups, key=str)}
