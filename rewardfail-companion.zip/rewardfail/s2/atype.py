"""答案类型：按标准答案的字符串分类（方案第 4 节“答案类型运行前写定”）。

规则在看任何判分结果之前写定并提交；之后只按这里分类，不按结果改规则。按下面的顺序判断，先命中的算数：
1. 矩阵或向量：含 matrix/array 环境、\\langle、\\vec、\\overrightarrow。
2. 文字或选项（选项）：整串是 A–E 的选项字母（可带括号、\\text 或 \\textbf，可多选），或以“(A)”这类选项标记开头。
3. 把单位（\\text、\\mathrm 等）、度数、空白类命令换成空格后剩下的是一个数：整数（1,234 或 1 234 这样三位一组的
   逗号、空格当千位分隔）→ 整数；小数、a/b、\\frac{a}{b}、带分数，以及带百分号的数 → 分数或小数。中间还隔着空格的不算一个数。
4. 区间或集合：首尾是括号且最外层括号里有逗号；含集合括号、集合运算或属于号；含不等号；括号外有逗号或分号（多个答案）；
   用“或”连接。
5. 文字或选项（文字）：整串只是英文单词（至少两个字母、含元音）；或去掉 \\text 类内容和命令名后仍有连续 3 个以上英文字母；
   或含汉字；或去掉 \\text 类内容后什么都不剩。
6. 含符号的表达式：还有字母、反斜杠命令、^、_、=、+、*、/ 或数字间的减号。
7. 其他。
"""
import re

TYPES = ("整数", "分数或小数", "含符号的表达式", "区间或集合", "矩阵或向量", "文字或选项", "其他")

_MATRIX = re.compile(r"\\begin\{[pbBvV]?matrix\}|\\begin\{array\}|\\langle|\\vec\b|\\overrightarrow")
_MARK = r"\(?[A-E]\)?"
_WRAPPED = rf"\\(?:text|textbf|mathrm|mathbf)\{{\s*{_MARK}\s*\}}"
_CHOICE = re.compile(rf"(?:{_WRAPPED}|{_MARK})(?:\s*[,，、]?\s*(?:{_WRAPPED}|{_MARK}))*")
_CHOICE_PREFIX = re.compile(r"\\(?:text|textbf|mathrm|mathbf)\{\s*\([A-E]\)\s*\}|\([A-E]\)")
_TEXTLIKE = re.compile(r"\\(?:text|textbf|textit|mathrm|mbox|operatorname)\s*\{[^{}]*\}")
_SPACES = re.compile(r"\\[,;:! ]|~|\\quad|\\qquad|\\displaystyle|\\left|\\right")
_DEGREE = re.compile(r"\^\s*\{?\\circ\}?|°")
_INT = re.compile(r"[+-]?(?:\d+|\d{1,3}(?:,\d{3})+)")
_FRAC = re.compile(r"[+-]?(?:\d*\.\d+|\d+\.|\d+/\d+|\d*\\[dt]?frac\{\d+\}\{\d+\})")
_SET = re.compile(r"\\\{|\\\}|\\cup|\\cap|\\emptyset|\\varnothing|\\in\b|\\notin|\\subset|\\setminus")
_INEQ = re.compile(r"<|>|\\le\b|\\ge\b|\\leq\b|\\geq\b|\\leqslant|\\geqslant|\\lt\b|\\gt\b|≤|≥")
_OR = re.compile(r"\bor\b|或|\\vee|\\lor")
_CMD = re.compile(r"\\[A-Za-z]+")
_WORDS = re.compile(r"[A-Za-z]+(?:[\s'-][A-Za-z]+)*")
_EXPR = re.compile(r"[A-Za-z\\^_=+*/]|\d\s*-\s*\d|π|∞|√")


def _top_level_sep(s):
    """括号（圆、方、花）之外有没有逗号或分号。"""
    depth = 0
    for ch in s:
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth = max(0, depth - 1)
        elif ch in ",;，；" and depth == 0:
            return True
    return False


def _interval(s):
    """首尾是括号，且最外层括号里（深度 1）有逗号；第一个括号在中途闭合的不算，例如 (x-2)(x-5)。"""
    if len(s) < 3 or s[0] not in "([" or s[-1] not in ")]":
        return False
    depth, comma = 0, False
    for i, ch in enumerate(s):
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
            if depth == 0 and i != len(s) - 1:
                return False
        elif ch == "," and depth == 1:
            comma = True
    return comma


def normalize(ans):
    s = (ans or "").strip().replace("\u2212", "-")
    while len(s) >= 2 and s[0] == "$" and s[-1] == "$":
        s = s[1:-1].strip()
    s = re.sub(r"\\(?:text|mathrm|mbox)\{\s*\}", "", s)  # 空的 \text{}、\mathrm{}
    return s.rstrip(".。").strip()


def number_core(s):
    """单位、度数、空白类命令换成空格；三位一组的空格分隔并起来，其余还有空格的不当一个数（返回原样，下面的数字规则匹配不上）。"""
    core = _SPACES.sub(" ", _DEGREE.sub("", _TEXTLIKE.sub(" ", s)))
    core = re.sub(r"^([+-])\s+", r"\1", re.sub(r"\s+", " ", core).strip())
    if re.fullmatch(r"[+-]?\d{1,3}(?: \d{3})+", core):
        core = core.replace(" ", "")
    return core


def answer_type(ans):
    s = normalize(ans)
    if not s:
        return "其他"
    if _MATRIX.search(s):
        return "矩阵或向量"
    if _CHOICE.fullmatch(s) or _CHOICE_PREFIX.match(s):
        return "文字或选项"
    core = number_core(s)
    percent = bool(re.search(r"\\?%$", core))
    core = re.sub(r"\\?%$", "", core)
    if core:
        if _INT.fullmatch(core):
            return "分数或小数" if percent else "整数"
        if _FRAC.fullmatch(core):
            return "分数或小数"
    if _interval(s) or _SET.search(s) or _INEQ.search(s) or _top_level_sep(s) or _OR.search(s):
        return "区间或集合"
    if _WORDS.fullmatch(s) and len(s) >= 2 and re.search(r"[AEIOUaeiou]", s):
        return "文字或选项"
    rest = _CMD.sub("", _TEXTLIKE.sub("", s))
    if re.search(r"[A-Za-z]{3,}", rest) or re.search(r"[\u4e00-\u9fff]", s) or (not core and _TEXTLIKE.search(s)):
        return "文字或选项"
    if _EXPR.search(s):
        return "含符号的表达式"
    return "其他"
