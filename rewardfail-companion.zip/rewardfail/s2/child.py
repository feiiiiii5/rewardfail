"""进程池子进程一侧的观测（spawn 出来的子进程按名字导入本模块）。

父进程替换后的 submit 把 #8015 的 _verify_in_subprocess 换成这里的 observed_verify(ctx, 标准答案, 回答)：
带着编号进入子进程，给 math_verify 的 parse、verify 各套一层，再原样调用 _verify_in_subprocess，参数和返回值不变。
包装在调用时才从模块里取 parse、verify，所以套的这一层会被用上。
每一步开始就写一行（子进程被杀时也能看出停在哪一步），结束再写一行：哪一侧、墙钟与 CPU 时间、结果类型、
这一步里库打的日志（含 DEBUG；库的警告会带整段原文，只留哈希和长度），以及内存（footprint 与常驻峰值）。

计时信号：库的时限靠 signal.alarm，处理函数在解释器拿回控制时才运行。这里给库装上的 SIGALRM 处理函数外面
套一层，只把（第几步，时刻）追加进内存里的列表再原样调用，步骤结束时随结束行写出；任务结束行另记这次任务一共收到
几次，供分析核对每次信号都落在某一步里。看得到的三种情况：信号按时到、库记了超时；信号到了、库没记超时（一种可能是
处理函数抛出的异常被计算代码吞掉，这是推断，不是观测）；信号比时限晚到很多（例如长时间的 C 层计算，解释器拿不回控制）。
信号处理里不写文件，免得与正在写的那一行重入。

序号（10-07 按 Codex 审核第 13.2 节第 1 项加）：每行带 tseq（本次任务里的第几行，任务开始行是 0）和 fseq（这个子进程
文件里的第几行）。分析时两种序号都必须连续、不重复，缺行或多行都记观测不完整。

库的日志只交给本层的处理器（只留哈希、长度、类别）；根记录器上 verl 装的 stderr 处理器不再收到 math_verify 的记录，
测量进程的日志里也就没有回答原文。关闭观测（off）时不装这一层，库照原样输出。

ctx["limits"] 只在参照判分和时限敏感度跟进时出现（参数变更，结果里单独标明）；ctx["inject"] 只在自检时出现。
"""
import hashlib
import json
import logging
import os
import resource
import signal
import time

# 与真实路径一样，在解开任务时就导入被测包装（连带 verl、torch），导入开销落在任务开始之前
from verl.utils.reward_score import math_verify as W

from rewardfail.s2 import mem

CATS = ("Timeout during parsing", "Error parsing", "Timeout during comparison", "Error during comparison")
_S = {"installed": False, "ctx": None, "fh": None, "dir": None, "n": 0, "parses": 0, "alarms": [], "tseq": 0, "fseq": 0}


def _sha(s):
    return hashlib.sha256(str(s).encode("utf-8", "surrogatepass")).hexdigest()[:16]


def _maxrss():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss  # macOS 单位是字节


def _mem():
    """当前 footprint、生命周期内最大 footprint、常驻峰值（字节）；读不到的项记 None。"""
    try:
        fp, fp_max, _ = mem.usage()
    except Exception:
        fp = fp_max = None
    return {"fp": fp, "fp_max": fp_max, "maxrss": _maxrss()}


def _out(rec):
    ctx = _S["ctx"]
    if _S["fh"] is None or _S["dir"] != ctx["log_dir"]:
        _S["fh"] = open(os.path.join(ctx["log_dir"], f"child-{os.getpid()}.jsonl"), "a", encoding="utf-8")
        _S["dir"] = ctx["log_dir"]
    rec.update(req=ctx["req"], att=ctx["att"], gen=ctx["gen"], worker=ctx.get("worker"), pid=os.getpid(),
               t=round(time.time(), 6), tseq=_S["tseq"], fseq=_S["fseq"])
    _S["tseq"] += 1
    _S["fseq"] += 1
    _S["fh"].write(json.dumps(rec, ensure_ascii=False) + "\n")
    _S["fh"].flush()  # 交给操作系统；进程被杀也不丢已写的行


class _Catch(logging.Handler):
    def emit(self, record):
        if _S["ctx"] is None:
            return
        try:
            msg = record.getMessage()
        except Exception:
            msg = str(record.msg)
        exc = record.exc_info[0].__name__ if record.exc_info and record.exc_info[0] else None
        _out({"ev": "log", "step": _S["n"], "level": record.levelname, "logger": record.name,
              "cat": next((c for c in CATS if msg.startswith(c)), "其他"), "msg_sha": _sha(msg), "msg_len": len(msg),
              "exc": exc})


def _summ(r):
    if isinstance(r, list):
        return [type(x).__name__ for x in r]
    if isinstance(r, bool):
        return r
    return type(r).__name__


def _alarms(n, w0):
    """这一步里计时信号处理函数运行的时刻，换成距步骤开始的秒数。"""
    return [round(t - w0, 6) for s, t in _S["alarms"] if s == n]


def _step(kind, fn, a, k):
    _S["n"] += 1
    n = _S["n"]
    _out({"ev": "step_start", "step": n, "kind": kind})
    w0, c0 = time.time(), time.process_time()
    try:
        r = fn(*a, **k)
    except BaseException as e:
        _out(dict({"ev": "step_end", "step": n, "kind": kind, "wall": round(time.time() - w0, 6),
                   "cpu": round(time.process_time() - c0, 6), "exc": type(e).__name__, "alarms": _alarms(n, w0)},
                  **_mem()))
        raise
    _out(dict({"ev": "step_end", "step": n, "kind": kind, "wall": round(time.time() - w0, 6),
               "cpu": round(time.process_time() - c0, 6), "res": _summ(r), "alarms": _alarms(n, w0)}, **_mem()))
    return r


def _wrap_alarm_handler(handler):
    if not callable(handler) or getattr(handler, "_rf_alarm", False):
        return handler

    def wrapped(signum, frame):
        _S["alarms"].append((_S["n"], time.time()))  # 只追加，不写文件
        return handler(signum, frame)

    wrapped._rf_alarm = True
    return wrapped


def _install():
    if _S["installed"]:
        return
    import math_verify.grader as G
    import math_verify.parser as P

    lg = logging.getLogger("math_verify")

    class _Keep(logging.Filter):  # 根处理器（verl 导入时装的 stderr 输出）不再收到 math_verify 的记录：它们带回答原文
        def filter(self, record):
            return not record.name.startswith("math_verify")

    for h in logging.getLogger().handlers:
        h.addFilter(_Keep())
    orig_signal = signal.signal

    def _signal(signum, handler):  # 只给 SIGALRM 的处理函数套一层；其余原样
        if signum == signal.SIGALRM:
            handler = _wrap_alarm_handler(handler)
        return orig_signal(signum, handler)

    _signal._rf = True
    signal.signal = _signal
    lg.addHandler(_Catch(level=logging.DEBUG))
    lg.setLevel(logging.DEBUG)  # 库的其他异常只打 DEBUG，要收到它们得放开级别；不改判分逻辑
    orig_parse, orig_verify = P.parse, G.verify

    def parse(*a, **k):
        _S["parses"] += 1
        lim = (_S["ctx"].get("limits") or {}).get("parse")
        if lim is not None:
            k["parsing_timeout"] = lim
        return _step("gold_parse" if _S["parses"] == 1 else "pred_parse", orig_parse, a, k)

    def verify(*a, **k):
        lim = (_S["ctx"].get("limits") or {}).get("compare")
        if lim is not None:
            k["timeout_seconds"] = lim
        return _step("compare", orig_verify, a, k)

    parse._rf = verify._rf = True
    P.parse, G.verify = parse, verify
    _S["installed"] = True
    _S["n_install"] = _S.get("n_install", 0) + 1


def _swallow(sec):
    """模拟计算代码里的裸 except 吞掉了计时信号抛出的异常：睡满 sec 秒，期间收到的异常全部吞掉。"""
    end = time.time() + sec
    while (left := end - time.time()) > 0:
        try:
            time.sleep(left)
        except BaseException:
            pass


def _block(sec):
    """模拟解释器拿不回控制的长 C 计算：一次 pbkdf2_hmac（OpenSSL）调用跑约 sec 秒，期间计时信号的处理函数没法运行。
    先校准：每次把迭代数乘 4，直到一次调用不短于 0.2 秒（10-07 第二次自检里只校准 4 毫秒，被负载抖动带偏，只跑了 3 秒）。"""
    n = 20000
    while True:
        t0 = time.perf_counter()
        hashlib.pbkdf2_hmac("sha256", b"rewardfail", b"selftest", n)
        dt = time.perf_counter() - t0
        if dt >= 0.2:
            break
        n *= 4
    hashlib.pbkdf2_hmac("sha256", b"rewardfail", b"selftest", max(1, int(n * sec / dt)))


def _inject(spec):
    """只在自检时用：让某一步在库的计时之内变慢、吞掉计时信号、被长 C 计算挡住、抛非超时异常，
    或在计时之外变慢、子进程退出、占内存。返回恢复函数。"""
    if not spec:
        return lambda: None
    import math_verify.grader as G
    import math_verify.parser as P
    from math_verify.errors import TimeoutException

    saved = (P.extract_target_from_pred, G.sympy_expr_eq)

    def restore():
        P.extract_target_from_pred, G.sympy_expr_eq = saved
        P.parse_latex_cached.cache_clear()
        P.parse_expr_cached.cache_clear()

    side = {"gold_parse": 1, "pred_parse": 2}
    kind = next((k for k in ("slow", "raise", "swallow", "block") if spec.get(k) in side), None)
    if kind:
        want, orig = side[spec[kind]], P.extract_target_from_pred

        def extract(*a, **k):  # 在 parse 的计时之内
            if _S["parses"] == want:
                if kind == "slow":
                    time.sleep(spec["sec"])
                elif kind == "raise":
                    raise ValueError("injected: non-timeout library error")
                elif kind == "swallow":
                    _swallow(spec["sec"])
                else:
                    _block(spec["sec"])
            return orig(*a, **k)

        P.extract_target_from_pred = extract
    if spec.get("slow") == "compare":
        orig_eq = G.sympy_expr_eq

        def slow_eq(*a, **k):  # 在每对比较的计时之内
            time.sleep(spec["sec"])
            return orig_eq(*a, **k)

        G.sympy_expr_eq = slow_eq
    if "exit" in spec and _S["ctx"]["att"] in spec.get("atts", [1, 2]):
        _out({"ev": "inject_exit", "code": spec["exit"]})
        os._exit(spec["exit"])
    if spec.get("slow") == "outside" and _S["ctx"]["att"] in spec.get("atts", [1, 2]):
        time.sleep(spec["sec"])  # 在库的任何计时之外，只有外层等待截得住
    if spec.get("hog_mb"):
        _S["hog"] = bytearray(b"\x01") * (spec["hog_mb"] << 20)  # 每页都写过，常驻内存真的涨上去
        time.sleep(spec.get("hold", 20))
        _S.pop("hog", None)
    if spec.get("raise_task_timeout"):
        restore()
        raise TimeoutException("injected: shell-level positive control")
    return restore


def observed_verify(ctx, ground_truth_boxed, model_output):
    _S["ctx"], _S["n"], _S["parses"], _S["tseq"] = ctx, 0, 0, 0
    _install()
    import math_verify.grader as G
    import math_verify.parser as P

    _S["alarms"] = []
    hooks = {"handlers": sum(isinstance(h, _Catch) for h in logging.getLogger("math_verify").handlers),
             "installs": _S["n_install"], "parse_ours": getattr(P.parse, "_rf", False),
             "verify_ours": getattr(G.verify, "_rf", False), "alarm_ours": getattr(signal.signal, "_rf", False)}
    _out(dict({"ev": "task_start", "mode": ctx.get("mode"), "limits": ctx.get("limits"), "inject": ctx.get("inject"),
               "hooks": hooks,
               "gt_sha": _sha(ground_truth_boxed), "gt_len": len(ground_truth_boxed),
               "out_sha": _sha(model_output), "out_len": len(model_output)}, **_mem()))
    w0, c0 = time.time(), time.process_time()
    try:
        undo = _inject(ctx.get("inject"))
        try:
            r = W._verify_in_subprocess(ground_truth_boxed, model_output)
        finally:
            undo()
    except BaseException as e:
        _out(dict({"ev": "task_end", "exc": type(e).__name__, "wall": round(time.time() - w0, 6),
                   "cpu": round(time.process_time() - c0, 6), "alarms_total": len(_S["alarms"])}, **_mem()))
        _S["ctx"] = None
        raise
    _out(dict({"ev": "task_end", "res": r, "wall": round(time.time() - w0, 6), "cpu": round(time.process_time() - c0, 6),
               "alarms_total": len(_S["alarms"])}, **_mem()))
    _S["ctx"] = None
    return r
