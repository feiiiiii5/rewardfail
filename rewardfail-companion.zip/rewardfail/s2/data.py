"""第二阶段的数据读取：抽样映射、按行组读回答、试跑集。数据当不受信任的输入，只当字符串交给被测包装。"""
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq

from rewardfail.s2.atype import answer_type

ROOT = Path(__file__).resolve().parents[2]
DATA = Path.home() / ".local/share/rewardfail/data"
STAGE2 = Path.home() / ".local/share/rewardfail/stage2"
SHARDS = DATA / "openr1/data"
SEED = b"rewardfail-stage2-seed-2026-10-06"  # 与 plan/sample_map.py 相同


def draw(tag, key, m):
    return int.from_bytes(hashlib.sha256(SEED + b"\x00" + tag + b"\x00" + key).digest()[:8], "big") % m


def load_map(path=STAGE2 / "sample_map.tsv"):
    """读抽样映射，并按 plan/sample_map.json 里记的 sha256 核对，对不上就停。"""
    want = json.loads((ROOT / "plan/sample_map.json").read_text(encoding="utf-8"))["映射文件 sha256"]
    raw = Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != want:
        raise SystemExit(f"抽样映射 {path} 与 plan/sample_map.json 记的 sha256 不符")
    rows = []
    for line in raw.decode("utf-8").splitlines()[1:]:
        key, shard, row, k, pick, half = line.split("\t")
        rows.append({"key": key, "shard": shard, "row": int(row), "k": int(k), "pick": int(pick), "half": int(half)})
    return rows


class Reader:
    """按 (分片, 行号) 取标准答案与回答；一次只缓存一个行组。

    行组留在 Arrow 里，只把要用的那一行转成 Python 字符串；换行组时先丢掉旧行组，再把 Arrow 内存池里不用的内存还给系统。
    10-07 实测（同一测量进程的导入，按主测量的顺序读前 3 个分片的每一行）：每读完一个分片记一次到那时为止的 footprint
    峰值，原来整组转成 Python 列表是 699–837 MiB，这样读是 448–499 MiB；读完各分片时的当时读数另为 631–767 MiB 与
    374–392 MiB，不与峰值混成一个范围。两种读法在全部行上逐条相同。数字与比对见 results/s2_pilot/reader_check.json。"""

    def __init__(self, shards=SHARDS):
        self.shards, self.files, self.cache_key, self.cache = Path(shards), {}, None, None

    def _file(self, shard):
        if shard not in self.files:
            pf = pq.ParquetFile(self.shards / shard)
            starts, s = [], 0
            for i in range(pf.metadata.num_row_groups):
                starts.append(s)
                s += pf.metadata.row_group(i).num_rows
            self.files[shard] = (pf, starts)
        return self.files[shard]

    def get(self, shard, row):
        pf, starts = self._file(shard)
        rg = max(i for i, s in enumerate(starts) if s <= row)
        if self.cache_key != (shard, rg):
            self.cache_key, self.cache = None, None
            pa.default_memory_pool().release_unused()
            t = pf.read_row_group(rg, columns=["answer", "generations"])
            self.cache_key, self.cache = (shard, rg), (t.column("answer"), t.column("generations"))
        answers, gens = self.cache
        i = row - starts[rg]
        return answers[i].as_py(), gens[i].as_py()


def answers_by_row(shards=SHARDS, tick=None):
    """只读 answer 一列（很小），给答案类型和试跑分层用。tick：资源保护的检查点，每读完一个分片调用一次。"""
    out = {}
    for f in sorted(Path(shards).glob("train-*.parquet")):
        for i, a in enumerate(pq.read_table(f, columns=["answer"]).column("answer").to_pylist()):
            out[(f.name, i)] = a
        if tick:
            tick()
    return out


def pilot_set(map_rows, answers, per_shard=100, tick=None):
    """试跑集：主样本以外的回答，按分片和答案类型分层，每片约 per_shard 条；层内按种子哈希取最小的几条。"""
    cands = defaultdict(list)
    for j, r in enumerate(map_rows):
        if tick and j % 5000 == 0:
            tick()
        t = answer_type(answers[(r["shard"], r["row"])])
        for idx in range(r["k"]):
            if idx != r["pick"]:
                h = hashlib.sha256(SEED + b"\x00pilot\x00" + bytes.fromhex(r["key"]) + bytes([idx])).hexdigest()
                cands[(r["shard"], t)].append((h, r, idx))
    chosen = []
    for shard in sorted({s for s, _ in cands}):
        types = {t: sorted(v, key=lambda x: x[0]) for (s, t), v in cands.items() if s == shard}
        total = sum(len(v) for v in types.values())
        quota = {t: max(1, round(per_shard * len(v) / total)) for t, v in types.items()}
        for t, v in sorted(types.items()):
            for h, r, idx in v[:quota[t]]:
                chosen.append({"id": f"pilot-{r['key'][:16]}-{idx}", "shard": shard, "row": r["row"], "idx": idx,
                               "atype": t, "hash": h})
    chosen.sort(key=lambda x: x["hash"])
    return chosen


def type_counts(map_rows, answers):
    c = Counter()
    for r in map_rows:
        c[(answer_type(answers[(r["shard"], r["row"])]), r["half"])] += 1
    return c
