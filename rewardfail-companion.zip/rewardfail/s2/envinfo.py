"""运行环境记录：包版本只读元数据，不导入（导入 verl 会连带 torch，调度进程的 footprint 多出约 180 MiB）；
另记第二阶段代码各文件的 sha256 与实验仓提交，供复核时确认结果出自哪一版代码。"""
import hashlib
import importlib.metadata
import importlib.util
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PKGS = ("verl", "math-verify", "sympy", "torch", "pyarrow", "psutil")


def env():
    def git(*a):
        return subprocess.run(["git", *a], cwd=ROOT, capture_output=True, text=True).stdout.strip()

    files = sorted([*ROOT.glob("rewardfail/s2/*.py"), *ROOT.glob("experiments/s2_*.py")])
    return {"python": sys.version.split()[0], "platform": platform.platform(),
            "versions": {d: importlib.metadata.version(d) for d in PKGS},
            "verl_dir": str(Path(importlib.util.find_spec("verl").origin).parent),
            "repo_head": git("rev-parse", "HEAD"), "repo_dirty": git("status", "--porcelain").splitlines(),
            "code_sha256": {str(f.relative_to(ROOT)): hashlib.sha256(f.read_bytes()).hexdigest() for f in files}}
