"""整机保护（申请季 D135，2026-10-08 起；此前按方案第 6 节预算的版本见实验仓 9a88991，主测量用的就是它）：每秒查一次。

唯一的资源红线是系统内存压力变红（kern.memorystatus_vm_pressure_level 为 4，严重）。macOS 主动用缓存、压缩和交换
把内存用满：合计 footprint 高、“可用”内存低、交换区有用量都只记录，不暂停、不停止；绿（1）、黄（2）照常运行。
- 变红：暂停派新行（正在判的行照常跑）。最大的进程池子进程 footprint 不低于 kill_min（默认 1 GiB，正常一行约 0.3 GiB）
  时把它杀掉，记 budget_kill（why=内存压力变红），那一行记“本机预算终止（未裁定）”；仍红每 kill_gap 秒再看一次。
  kill_min 只在变红之后用来认出失控的那一行，不是预算：不红时不论多大都不杀。连续 hard_after 秒仍红：整项停止（并发降到 0，
  杀掉本测量的全部测量进程组，已完成的行都已逐行落盘），回落后由调度按减半的 P 从检查点续跑（supervise.py）。
- 不红之后要连续 resume_after 秒才恢复派发。
- 读不到内存压力：有测量进程时整项停止，并发已是 0 时暂停（不当作安全）。进程树、footprint、可用内存、交换区读不到只记录。
- child_limit（默认不设）：单个进程池子进程超过它就杀。只给自检与测试制造确定的终止路径；测量不设（D135：静态预算
  不是停工或降速的理由）。
- 内存一律按 macOS 的 footprint 计（rewardfail/s2/mem.py），被压缩、被换出的页也算；RSS 只照记。状态记录（默认每 10 秒，
  条件变化时立刻记）带分角色的 footprint（调度、各测量进程、各进程池子进程、其他后代）、可用内存、交换区与负载。
"""
import ctypes
import ctypes.util
import json
import os
import signal
import time

import psutil

from rewardfail.s2 import mem

GiB = 1 << 30
MiB = 1 << 20
_libc = ctypes.CDLL(ctypes.util.find_library("c"))
RED = 4


def sysctl_int(name):
    v, sz = ctypes.c_int(0), ctypes.c_size_t(ctypes.sizeof(ctypes.c_int))
    return v.value if _libc.sysctlbyname(name.encode(), ctypes.byref(v), ctypes.byref(sz), None, 0) == 0 else None


def pressure():
    """macOS 系统内存压力：1 正常，2 警告，4 严重；读不到返回 None。"""
    return sysctl_int("kern.memorystatus_vm_pressure_level")


def plan_parallel(budget, pipeline, child_base, child_limit, cap=4):
    """历史（方案第 6 节公式，试跑与 10-07 主测量用）：P = min(4, ⌊(预算 − 一个子进程最多还能涨的量) ÷ 每条流水线常驻内存⌋)。
    D135 起只作记录，不拦停。"""
    head = max(0, child_limit - child_base)
    return max(0, min(cap, int((budget - head) // pipeline)))


class Guard:
    def __init__(self, log_path, *, child_limit=None, kill_min=1 * GiB, kill_gap=5, resume_after=30, hard_after=15,
                 status_every=10):
        vm = psutil.virtual_memory()
        self.avail_start, self.swap_start = vm.available, psutil.swap_memory().used
        self.child_limit, self.kill_min, self.kill_gap = child_limit, kill_min, kill_gap
        self.resume_after, self.hard_after, self.status_every = resume_after, hard_after, status_every
        self.fh = open(log_path, "a", encoding="utf-8")
        self.paused, self.pause_since, self.clear_since, self.red_since, self.last_kill = False, None, None, None, None
        self.last_status, self.last_reasons = 0.0, None
        self.peak_total, self.min_avail, self.max_swap = 0, self.avail_start, self.swap_start
        self.max_pressure = pressure() or 0
        self.kills, self.red_kills, self.stops = 0, 0, 0
        self.log("guard_start", rule="D135：只在内存压力变红（4）时降并发或暂停", child_limit=child_limit, kill_min=kill_min,
                 avail_start=self.avail_start, swap_start=self.swap_start, pressure=self.max_pressure, metric="phys_footprint")

    def log(self, ev, **kw):
        kw.update(ev=ev, t=round(time.time(), 3))
        self.fh.write(json.dumps(kw, ensure_ascii=False) + "\n")
        self.fh.flush()

    def _kill(self, pid, fp, **why):
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            return False
        self.kills += 1
        self.log("budget_kill", pid=pid, fp=fp, **why)
        return True

    def sample(self, worker_pids):
        s = {"read_fail": [], "procs": [], "pressure": None, "avail": None, "swap": None, "load1": None}
        try:
            me = psutil.Process()
            tree = [me] + me.children(recursive=True)
        except Exception as e:  # 读不到自己的进程树：不能当作安全
            s["read_fail"].append(f"进程树:{type(e).__name__}")
            tree = []
        for p in tree:
            try:
                ppid = p.ppid()
                fp, _, rss = mem.usage(p.pid)
                s["procs"].append((p.pid, ppid, fp, rss))
            except (psutil.NoSuchProcess, psutil.ZombieProcess, mem.Gone):
                pass  # 刚好退出，不占内存
            except Exception as e:
                s["read_fail"].append(f"进程{p.pid}:{type(e).__name__}")
        s["total"] = sum(fp for _, _, fp, _ in s["procs"])
        s["total_rss"] = sum(rss for _, _, _, rss in s["procs"])
        s["pool_children"] = [(pid, fp) for pid, ppid, fp, _ in s["procs"] if ppid in worker_pids]
        me_pid = os.getpid()
        s["roles"] = {"sup": sum(fp for pid, _, fp, _ in s["procs"] if pid == me_pid),
                      "workers": [[pid, fp] for pid, _, fp, _ in s["procs"] if pid in worker_pids],
                      "pool": [[pid, ppid, fp] for pid, ppid, fp, _ in s["procs"] if ppid in worker_pids],
                      "other": [[pid, ppid, fp] for pid, ppid, fp, _ in s["procs"]
                                if pid != me_pid and pid not in worker_pids and ppid not in worker_pids]}
        s["pressure"] = pressure()
        if s["pressure"] is None:
            s["read_fail"].append("内存压力")
        try:
            s["avail"] = psutil.virtual_memory().available
        except Exception as e:
            s["read_fail"].append(f"可用内存:{type(e).__name__}")
        try:
            s["swap"] = psutil.swap_memory().used
        except Exception as e:
            s["read_fail"].append(f"交换区:{type(e).__name__}")
        try:
            s["load1"] = round(os.getloadavg()[0], 2)
        except OSError:
            pass
        return s

    def step(self, worker_pids):
        """返回 "run"、"pause" 或 "stop"。变红时自己动手杀失控的进程池子进程并记录。worker_pids 为空表示并发已是 0。"""
        s = self.sample(set(worker_pids))
        now = time.time()
        self.peak_total = max(self.peak_total, s["total"])
        if s["avail"] is not None:
            self.min_avail = min(self.min_avail, s["avail"])
        if s["swap"] is not None:
            self.max_swap = max(self.max_swap, s["swap"])
        p = s["pressure"]
        if p is not None:
            self.max_pressure = max(self.max_pressure, p)
        if self.child_limit:
            for pid, fp in s["pool_children"]:
                if fp > self.child_limit:
                    self._kill(pid, fp, limit=self.child_limit, why="超过 child_limit（只用于自检与测试）")
        reasons, hard = [], []
        if p is None:
            hard.append("监控读数失败：内存压力")
        elif p >= RED:
            reasons.append("内存压力严重（红）")
            self.red_since = self.red_since or now
            big = max(s["pool_children"], key=lambda x: x[1], default=None)
            if (big and self.kill_min is not None and big[1] >= self.kill_min
                    and (self.last_kill is None or now - self.last_kill >= self.kill_gap)):
                if self._kill(big[0], big[1], kill_min=self.kill_min, why="内存压力变红，杀 footprint 最大的进程池子进程"):
                    self.red_kills += 1
                    self.last_kill = now
            if worker_pids and now - self.red_since >= self.hard_after:
                hard.append(f"内存压力连续 {self.hard_after} 秒严重")
        else:
            self.red_since = None
        key = (tuple(reasons), tuple(hard))
        if now - self.last_status >= self.status_every or key != self.last_reasons:
            self.last_status, self.last_reasons = now, key
            self.log("status", total=s["total"], total_rss=s.get("total_rss"), n_procs=len(s["procs"]),
                     avail=s["avail"], swap=s["swap"], pressure=p, load1=s["load1"], workers=len(worker_pids),
                     paused=self.paused, reasons=reasons + hard, read_fail=s["read_fail"], roles=s.get("roles"))
        if hard or reasons:
            if not self.paused:
                self.log("pause", reasons=reasons + hard)
                self.paused, self.pause_since = True, now
            self.clear_since = None
            if hard and worker_pids:
                self.stops += 1
                self.log("hard_stop", reasons=hard, total=s["total"], avail=s["avail"], pressure=p)
                return "stop"
            return "pause"
        if self.paused:
            self.clear_since = self.clear_since or now
            if now - self.clear_since < self.resume_after:
                return "pause"
            self.log("resume", paused_for=round(now - (self.pause_since or now), 1))
            self.paused, self.pause_since, self.clear_since = False, None, None
        return "run"

    def wait_clear(self, poll=1.0):
        """并发为 0 时等保护条件连续解除（step 自己记日志）。"""
        while self.step([]) != "run":
            time.sleep(poll)

    def summary(self):
        return {"rule": "D135", "child_limit": self.child_limit, "kill_min": self.kill_min, "avail_start": self.avail_start,
                "swap_start": self.swap_start, "peak_total_fp": self.peak_total, "min_avail": self.min_avail,
                "max_swap": self.max_swap, "max_pressure": self.max_pressure, "budget_kills": self.kills,
                "red_kills": self.red_kills, "hard_stops": self.stops}
