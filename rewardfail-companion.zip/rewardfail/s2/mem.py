"""macOS 进程内存读数：phys_footprint（活动监视器“内存”一栏的口径），被压缩、被换出的页都算在内。

常驻内存（RSS）在内存被压缩后会掉下去。10-07 实测：一个进程写满 600 MiB 同一个字节，RSS 20 秒内从 621 MiB
掉到 350 MiB，footprint 一直是 612 MiB（探针脚本与输出见 results/s2_selftest/footprint_probe.*）。同日第一次完整自检
（58 项）D 段 3 项未过：每秒采样的进程合计 RSS 峰值 1.15 GiB（peak_total_rss），低于那次 1.32 GiB 的预算，整项停止
没有触发（常被引用的 0.88 GiB 只是第 10 秒的合计读数，不是峰值，也不是单行占用）。整机保护按 RSS 计，会在内存
最紧的时候低估占用，所以预算和单进程上限都改按 footprint 算，RSS 只照记。自检 G2 只核 footprint 读数与计入；
它那次 RSS 没有下降，“RSS 下降时 footprint 保持”只由上面的探针支持。

读法：libproc 的 proc_pid_rusage(pid, RUSAGE_INFO_V4)。结构体前 10 个字段各版本相同；resident_size 与 psutil 的 rss
对得上（10-07 连续读 20 次，19 次逐字节相同），lifetime_max_phys_footprint 不随释放回落，用来核布局没有读错位。
"""
import ctypes
import ctypes.util
import errno
import os

_U64 = ctypes.c_uint64
_NAMES = ("user_time", "system_time", "pkg_idle_wkups", "interrupt_wkups", "pageins", "wired_size", "resident_size",
          "phys_footprint", "proc_start_abstime", "proc_exit_abstime", "child_user_time", "child_system_time",
          "child_pkg_idle_wkups", "child_interrupt_wkups", "child_pageins", "child_elapsed_abstime",
          "diskio_bytesread", "diskio_byteswritten", "cpu_time_qos_default", "cpu_time_qos_maintenance",
          "cpu_time_qos_background", "cpu_time_qos_utility", "cpu_time_qos_legacy", "cpu_time_qos_user_initiated",
          "cpu_time_qos_user_interactive", "billed_system_time", "serviced_system_time", "logical_writes",
          "lifetime_max_phys_footprint", "instructions", "cycles", "billed_energy", "serviced_energy",
          "interval_max_phys_footprint", "runnable_time")
RUSAGE_INFO_V4 = 4


class _RU4(ctypes.Structure):
    _fields_ = [("uuid", ctypes.c_uint8 * 16)] + [(n, _U64) for n in _NAMES]


_lib = ctypes.CDLL(ctypes.util.find_library("proc") or "/usr/lib/libproc.dylib", use_errno=True)
_lib.proc_pid_rusage.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
_lib.proc_pid_rusage.restype = ctypes.c_int


class Gone(Exception):
    """进程已经不在了（ESRCH），不占内存。"""


def usage(pid=None):
    """返回 (footprint, 生命周期内最大 footprint, 常驻内存)，单位字节。进程不在了抛 Gone，其他失败抛 OSError。"""
    r = _RU4()
    if _lib.proc_pid_rusage(os.getpid() if pid is None else pid, RUSAGE_INFO_V4, ctypes.byref(r)) != 0:
        e = ctypes.get_errno()
        if e == errno.ESRCH:
            raise Gone(pid)
        raise OSError(e, os.strerror(e))
    return r.phys_footprint, r.lifetime_max_phys_footprint, r.resident_size
