"""测量进程（进程池的父进程）一侧的观测。不改包装的判分逻辑，异常对象原样往上抛。

- 给包装的 _get_pool 套一层：每个新池记一个代次，并替换这个池对象的 submit。替换后的 submit 把任务换成
  child.observed_verify(ctx, …)，ctx 带请求编号、第几次尝试、池代次；返回的 Future 外面套一个只转发
  result 与 cancel 的代理，记下每次等待的结局（得分、外层等待超时、库超时异常、池损坏、其他异常）和时刻。
- _reset_pool 照常执行，进出各记一笔（进入时这个池是不是当前池，即会不会真的杀）。
- multiprocessing 进程对象的 kill、terminate 记下是哪个线程（哪个请求，或进程池自己的管理线程）对哪个子进程动手。
- 子进程的实际退出码：正常判分只读进程对象里已被回收的 returncode，不自己去回收，免得和进程池的管理线程抢；
  测量进程收尾时（poll_exits(reap=True)）先等还没有退出码的子进程回收，合计最多 5 秒（实验仓 6c6cf9b）。
- 序号（10-07 按 Codex 审核第 13.2 节第 1 项加）：每行带 seq（本文件第几行）；属于某一行请求的再带 rseq（本行第几条）。
  每行请求以 row_begin 开始（rseq 0，记这一行的注入与参数），以 row_end 结束（记本行前面一共几条）。分析时序号必须连续、
  不重复，缺行或多行都记观测不完整。
"""
import concurrent.futures.process as cfp
import itertools
import json
import multiprocessing.process as mpp
import threading
import time
from concurrent.futures import TimeoutError as FuturesTimeoutError
from concurrent.futures.process import BrokenProcessPool

from math_verify.errors import TimeoutException

from rewardfail.s2 import child


def classify(e):
    if isinstance(e, FuturesTimeoutError):
        return "outer_timeout"
    if isinstance(e, TimeoutException):
        return "lib_timeout_exc"
    if isinstance(e, BrokenProcessPool):
        return "broken_pool"
    return "other_exc"


class FutureProxy:
    """只转发 compute_score 用到的 result、cancel；其余属性原样取自真正的 Future。"""

    def __init__(self, fut, obs, att, gen):
        self._f, self._obs, self._att, self._gen = fut, obs, att, gen

    def result(self, timeout=None):
        w0 = time.time()
        try:
            r = self._f.result(timeout=timeout)
        except BaseException as e:
            self._obs.rec("wait_end", att=self._att, gen=self._gen, outcome=classify(e), exc=type(e).__name__,
                          waited=round(time.time() - w0, 6), timeout=timeout)
            raise
        self._obs.rec("wait_end", att=self._att, gen=self._gen, outcome="score", score=r,
                      waited=round(time.time() - w0, 6), timeout=timeout)
        return r

    def cancel(self):
        ok = self._f.cancel()
        self._obs.rec("cancel", att=self._att, gen=self._gen, ok=ok)
        return ok

    def __getattr__(self, name):
        return getattr(self._f, name)


class Observer:
    def __init__(self, W, log_path, child_log_dir, base_ctx):
        self.W, self.child_log_dir, self.base_ctx = W, str(child_log_dir), dict(base_ctx)
        self.fh = open(log_path, "a", encoding="utf-8")
        self.lock, self.reg_lock, self.proc_lock = threading.Lock(), threading.Lock(), threading.Lock()
        self.tl = threading.local()
        self.gens = itertools.count(1)
        self.seq = 0
        self.pools = []  # 保留引用，id 不会被复用
        self.procs = {}  # pid -> {"gen", "proc", "code"}

    # ---- 记录 ----
    def rec(self, ev, **kw):
        req = getattr(self.tl, "req", None)
        kw.update(ev=ev, t=round(time.time(), 6), req=req, thread=threading.current_thread().name)
        if req is not None:
            kw["rseq"] = self.tl.rseq
            self.tl.rseq += 1
        with self.lock:
            kw["seq"] = self.seq
            self.seq += 1
            self.fh.write(json.dumps(kw, ensure_ascii=False) + "\n")
            self.fh.flush()

    def begin(self, req, inject=None, ctx_extra=None):
        """测量循环在调用 compute_score 之前设好本线程的请求编号；尝试次数从 0 数起。"""
        self.tl.req, self.tl.att, self.tl.inject, self.tl.extra, self.tl.rseq = req, 0, inject, ctx_extra or {}, 0
        self.rec("row_begin", inject=inject, limits=(ctx_extra or {}).get("limits"), mode=self.base_ctx.get("mode"))

    def end(self):
        self.poll_exits()
        self.rec("row_end", n=self.tl.rseq)
        self.tl.req = None

    # ---- 子进程与退出码 ----
    def snapshot(self, pool, gen):
        with self.proc_lock:
            for pid, p in list((pool._processes or {}).items()):
                if pid not in self.procs:
                    self.procs[pid] = {"gen": gen, "proc": p, "code": None}
                    self.rec("proc_new", pid=pid, gen=gen)

    def gen_of_pid(self, pid):
        info = self.procs.get(pid)
        return info["gen"] if info else None

    def poll_exits(self, reap=False, wait=0.0):
        """记下已退出子进程的退出码。reap=True 用于测量进程收尾：先等还没有退出码的子进程，合计最多 wait 秒。
        刚被杀的子进程要等系统回收才有退出码；10-07 晚的主测量脚本测试里，外层超时那行是测量进程的最后一行，
        收尾离杀子进程只有 0.1 毫秒，读不到退出码，那行因缺退出记录记成观测不完整。"""
        with self.proc_lock:
            t_end = time.time() + wait
            for pid, info in list(self.procs.items()):
                if info["code"] is not None:
                    continue
                p = info["proc"]
                if reap and wait > 0 and p._popen is not None:
                    p.join(timeout=max(0.0, t_end - time.time()))
                code = p.exitcode if reap else (p._popen.returncode if p._popen is not None else None)
                if code is not None:
                    info["code"] = code
                    self.rec("proc_exit", pid=pid, gen=info["gen"], code=code)

    # ---- 安装 ----
    def install(self):
        W, obs = self.W, self
        self.orig = (W._get_pool, W._reset_pool, mpp.BaseProcess.kill, mpp.BaseProcess.terminate)
        orig_get, orig_reset, orig_kill, orig_term = self.orig
        orig_vis = W._verify_in_subprocess

        def register(pool):
            with obs.reg_lock:
                if getattr(pool, "_rf_gen", None) is not None:
                    return
                gen = next(obs.gens)
                pool._rf_gen = gen
                obs.pools.append(pool)
                orig_submit = pool.submit

                def submit(fn, /, *args, **kwargs):
                    tl = obs.tl
                    tl.att = getattr(tl, "att", 0) + 1
                    ctx = dict(obs.base_ctx, **getattr(tl, "extra", {}), req=getattr(tl, "req", None), att=tl.att,
                               gen=gen, log_dir=obs.child_log_dir, inject=getattr(tl, "inject", None))
                    try:  # 池已被标为损坏时 submit 自己就抛 BrokenProcessPool，包装同样按池损坏处理
                        if fn is orig_vis:
                            fut = orig_submit(child.observed_verify, ctx, *args, **kwargs)
                        else:
                            fut = orig_submit(fn, *args, **kwargs)
                    except BaseException as e:
                        obs.rec("submit_exc", att=tl.att, gen=gen, outcome=classify(e), exc=type(e).__name__)
                        raise
                    obs.rec("submit", att=tl.att, gen=gen)
                    obs.snapshot(pool, gen)
                    return FutureProxy(fut, obs, tl.att, gen)

                pool.submit = submit
            obs.rec("pool_new", gen=gen)

        def _get_pool():
            pool = orig_get()
            if getattr(pool, "_rf_gen", None) is None:
                register(pool)
            return pool

        def _reset_pool(pool):
            gen = getattr(pool, "_rf_gen", None)
            obs.rec("reset_enter", gen=gen, is_current=W._pool is pool, pids=sorted(pool._processes or {}))
            try:
                return orig_reset(pool)
            finally:
                obs.rec("reset_exit", gen=gen, current_gen=getattr(W._pool, "_rf_gen", None))

        def kill(proc):
            obs.rec("proc_kill", pid=proc.pid, gen=obs.gen_of_pid(proc.pid),
                    mgmt=isinstance(threading.current_thread(), cfp._ExecutorManagerThread))
            return orig_kill(proc)

        def terminate(proc):
            obs.rec("proc_terminate", pid=proc.pid, gen=obs.gen_of_pid(proc.pid),
                    mgmt=isinstance(threading.current_thread(), cfp._ExecutorManagerThread))
            return orig_term(proc)

        W._get_pool, W._reset_pool = _get_pool, _reset_pool
        mpp.BaseProcess.kill, mpp.BaseProcess.terminate = kill, terminate
        self.rec("observer_installed", base_ctx=self.base_ctx)
