"""第二阶段主测量的判定与统计（方案第 4、5、7 节，运行前写定）。只读逐行精简记录（analyze.summarize_stream 的输出）。

裁定：
- 默认那一遍：类别以“1 分”开头记 1；“正常 0”或以“0 分”开头记 0；其余（最终异常、本机预算终止、观测不完整、
  中断两次、没有结果）记未裁定。
- 参照：以“1 分”开头记 1（不论有没有库超时日志）；“正常 0”记 0；以“0 分”开头的，类别里有“超时”记未裁定
  （方案第 4 节“参照自己也超时”），只有库内出错记 0；其余记未裁定。
- 主指标：k = 默认 0、参照 1 的题数；u = 默认未裁定，或默认 0 而参照未裁定（含参照缺失）的题数；分母始终是 n。
  继续看单侧 95% 下界（只算 k），停止看单侧 95% 上界（算 k+u）；描述用双侧 95%。
"""
import math
from collections import Counter, defaultdict

from rewardfail.s2.analyze import FLAG_NO_LOG

A = 0.05
CONTINUE_LOWER = 1e-3  # 方案第 7 节继续第 2 条
STOP_UPPER = 1e-4  # 方案第 7 节停止第 2 条
TYPE_MIN_K = 3  # 方案第 5 节：前一半里至少 3 题、点估计不低于千分之一的类型记为待确认
TYPE_COVER_N = 29_956  # 方案第 5 节：不到这个题数的类型，零事件也给不出低于万分之一的上界


# ---------------- Clopper–Pearson：二项尾概率用正则化不完全贝塔函数算，再二分反演 ----------------
# 原来按 plan/stage2_thresholds.py 从 (1−p)^n 起逐项连乘，np 超过约 745 时首项下溢成 0，后面乘不回来
# （Codex 10-07 审核第 13.2 节第 3 项：n=93,733、k=1,000 时上下界都算成 0.00791802）。
# 现在 P(X ≤ k) = I_{1−p}(n−k, k+1)、P(X ≥ k) = I_p(k, n−k+1)：系数在对数里算，连分式按 Lentz 法，不随 n 下溢。
# 预先写定的门槛（k ≥ 111、k+u ≤ 4）在小 k 时两种算法一致，tests/test_s2_stats.py 另用独立的对数逐项求和核对。
def _betacf(a, b, x):
    tiny = 1e-300
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > tiny else tiny)
    h = d
    for m in range(1, 100_000):
        m2 = 2 * m
        for aa in (m * (b - m) * x / ((qam + m2) * (a + m2)), -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))):
            d = 1.0 + aa * d
            d = 1.0 / (d if abs(d) > tiny else tiny)
            c = 1.0 + aa / c
            c = c if abs(c) > tiny else tiny
            h *= d * c
        if abs(d * c - 1.0) <= 4e-16:  # 两个最小精度单位以内
            return h
    raise ArithmeticError(f"不完全贝塔函数的连分式不收敛：a={a} b={b} x={x}")


def ibeta(a, b, x):
    """正则化不完全贝塔函数 I_x(a, b)，a、b > 0。x 在 (a+1)/(a+b+2) 以上时用 I_x(a,b) = 1 − I_{1−x}(b,a)。"""
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    front = math.exp(math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log1p(-x))
    if x < (a + 1.0) / (a + b + 2.0):
        return front * _betacf(a, b, x) / a
    return 1.0 - front * _betacf(b, a, 1.0 - x) / b


def cdf(k, n, p):
    """二项分布 P(X ≤ k)。"""
    if k < 0:
        return 0.0
    if k >= n or p <= 0:
        return 1.0
    if p >= 1:
        return 0.0
    return 1.0 - ibeta(k + 1, n - k, p)


def _bisect(f, it=200):
    lo, hi = 0.0, 1.0
    for _ in range(it):
        mid = (lo + hi) / 2
        if f(mid):
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def lower(k, n, alpha=A):
    """单侧下界：P(X ≥ k | p) = alpha 的 p。"""
    return 0.0 if k <= 0 else _bisect(lambda p: ibeta(k, n - k + 1, p) < alpha)


def upper(k, n, alpha=A):
    """单侧上界：P(X ≤ k | p) = alpha 的 p。"""
    return 1.0 if k >= n else _bisect(lambda p: ibeta(k + 1, n - k, p) < 1 - alpha)


def two_sided(k, n):
    return [lower(k, n, 0.025), upper(k, n, 0.025)]


def rate(k, n):
    return {"k": k, "n": n, "rate": k / n if n else None, "ci95": two_sided(k, n) if n else None}


# ---------------- 逐行裁定与事件 ----------------
def default_verdict(cls):
    if cls is None:
        return None
    if cls.startswith("1 分"):
        return 1
    if cls == "正常 0" or cls.startswith("0 分"):
        return 0
    return None


def ref_verdict(cls):
    if cls is None:
        return None
    if cls.startswith("1 分"):
        return 1
    if cls == "正常 0":
        return 0
    if cls.startswith("0 分"):
        return None if "超时" in cls else 0
    return None


def features(row):
    """(库超时的步骤种类, 库内出错的步骤种类, 是否有一步超过 1 秒, 各次尝试的结局)。"""
    timed, errs, slow, outs = set(), set(), False, []
    for a in row["attempts"]:
        outs.append(a.get("outcome"))
        for kind, wall, _end, cats, _nal in a["steps"]:
            if any(c.startswith("Timeout") for c in cats):
                timed.add(kind)
            if any(c.startswith("Error") for c in cats):
                errs.add(kind)
            if wall is not None and wall > 1:
                slow = True
    return timed, errs, slow, outs


def is_event(row):
    """方案第 4 节跟进第 1 条的“有事件”：类别不是“1 分”或“正常 0”，或有计时信号标记。"""
    return row is not None and (row["class"] not in ("1 分", "正常 0") or bool(row["flags"]))


def is_limit_row(row):
    """方案第 4 节跟进第 2 条：有库内超时，或任一步墙钟超过 1 秒。"""
    timed, _errs, slow, _outs = features(row)
    return bool(timed) or slow


EVENTS = [
    ("标准答案侧解析超时", lambda r, f: "gold_parse" in f[0]),
    ("回答侧解析超时", lambda r, f: "pred_parse" in f[0]),
    ("比较超时", lambda r, f: "compare" in f[0]),
    ("标准答案侧解析出错", lambda r, f: "gold_parse" in f[1]),
    ("回答侧解析出错", lambda r, f: "pred_parse" in f[1]),
    ("比较出错", lambda r, f: "compare" in f[1]),
    ("外层超时", lambda r, f: "outer_timeout" in f[3]),
    ("库超时异常（壳层）", lambda r, f: "lib_timeout_exc" in f[3]),
    ("池损坏", lambda r, f: "broken_pool" in f[3]),
    ("最终异常", lambda r, f: r["class"].startswith("最终异常")),
    ("本机预算终止", lambda r, f: r["class"] == "本机预算终止（未裁定）"),
    ("观测不完整", lambda r, f: r["class"] == "观测不完整（未裁定）"),
    ("中断两次", lambda r, f: r["class"].startswith("未裁定（中断两次")),
    (FLAG_NO_LOG, lambda r, f: any(FLAG_NO_LOG in x for x in r["flags"])),
    ("计时信号晚到", lambda r, f: any("晚到" in x for x in r["flags"])),
    ("任一步超过 1 秒", lambda r, f: f[2]),
    ("单行超过 10 秒", lambda r, f: (r["wall"] or 0) > 10),
]


class DefaultTally:
    """流式累计默认那一遍：每行只留类别；不平凡的行（有事件、慢步骤、库超时、单行超过 10 秒）留精简记录。"""

    def __init__(self):
        self.cls, self.keep, self.ev = {}, {}, Counter()

    def add(self, row):
        f = features(row)
        self.cls[row["id"]] = row["class"]
        for name, pred in EVENTS:
            if pred(row, f):
                self.ev[name] += 1
        if is_event(row) or f[2] or f[0] or (row["wall"] or 0) > 10:
            self.keep[row["id"]] = row


# ---------------- 主指标、答案类型、跟进 ----------------
def main_metric(ids, dcls, rcls):
    k_ids, u_ids, why_u, k_from = [], [], Counter(), Counter()
    for i in ids:
        d = dcls.get(i)
        dv = default_verdict(d)
        if dv is None:
            u_ids.append(i)
            why_u["默认：" + (d or "没有记录")] += 1
            continue
        if dv == 1:
            continue
        r = rcls.get(i)
        rv = ref_verdict(r)
        if rv == 1:
            k_ids.append(i)
            k_from[f"{d} → {r}"] += 1
        elif rv is None:
            u_ids.append(i)
            why_u["参照：" + (r or "没有记录")] += 1
    n, k, u = len(ids), len(k_ids), len(u_ids)
    lo, up = lower(k, n), upper(k + u, n)
    return {"n": n, "k": k, "u": u, "rate_k": k / n, "lower_one_sided_95_k": lo, "upper_one_sided_95_k_plus_u": up,
            "ci95_two_sided_k": two_sided(k, n), "continue_2_metric": lo >= CONTINUE_LOWER, "stop_2": up < STOP_UPPER,
            "k_by_classes": dict(k_from), "u_reasons": dict(why_u)}, k_ids, u_ids


def answer_types(ids, meta, k_set, u_set):
    t = defaultdict(lambda: {"n": [0, 0], "k": [0, 0], "u": [0, 0]})
    for i in ids:
        m = meta[i]
        h = m["half"]
        x = t[m["atype"]]
        x["n"][h] += 1
        x["k"][h] += i in k_set
        x["u"][h] += i in u_set
    flagged = sorted(a for a, x in t.items() if x["k"][0] >= TYPE_MIN_K and x["k"][0] / x["n"][0] >= CONTINUE_LOWER)
    m = len(flagged)
    out = {}
    for a, x in sorted(t.items()):
        n_all = sum(x["n"])
        row = {"n_first": x["n"][0], "k_first": x["k"][0], "n_second": x["n"][1], "k_second": x["k"][1],
               "u_all": sum(x["u"]), "flagged_in_first_half": a in flagged, "uncovered_if_stopping": n_all < TYPE_COVER_N}
        if a in flagged:
            lo = lower(x["k"][1], x["n"][1], A / m)
            row.update(confirm_alpha=A / m, confirm_lower=lo, confirmed=lo >= CONTINUE_LOWER)
        out[a] = row
    return {"m_flagged": m, "flagged": flagged, "confirmed": [a for a in flagged if out[a]["confirmed"]], "by_type": out}


def replays(ids, dcls, reps):
    """重放 3 次：每行默认类别与三次重放类别；全一样记“每次都发生”，否则“时有时无”。"""
    rows, final_exc, cands_outer = {}, [], []
    for i in ids:
        rs = [r.get(i) for r in reps]
        cl = [x["class"] if x else None for x in rs]
        same = all(c == dcls.get(i) for c in cl)
        rows[i] = {"default": dcls.get(i), "replays": cl, "every_time": same}
        if (dcls.get(i) or "").startswith("最终异常") and all((c or "").startswith("最终异常") for c in cl):
            final_exc.append(i)
    return {"rows": len(rows), "every_time": sum(v["every_time"] for v in rows.values()),
            "sometimes": sum(not v["every_time"] for v in rows.values()), "detail": rows,
            "continue_1_reproducible_final_exception": final_exc}


def limit_sensitive(ids, low, dcls, high):
    """2 秒、默认、10 秒三种设置下裁定不全相同的行（其中一种未裁定也算），即方案第 4 节的“时限敏感变化”。"""
    return [i for i in ids if len({default_verdict(x.get(i)) for x in (low, dcls, high)}) > 1]


def replay_set(ids, dkeep, ref_events, k_set, sensitive):
    """方案第 4 节跟进第 1 条的重放集合（Codex 10-07 审核第 13.2 节第 2 项修订）：默认有事件、参照有事件、主指标翻转、
    时限敏感变化、默认单行超过 10 秒（条件实验要核的慢行）的并集，按 ids 的顺序。返回 (编号列表, 各来源的行数)。"""
    sens, why, out = set(sensitive), Counter(), []
    for i in ids:
        d = dkeep.get(i)
        r = [name for name, hit in (("默认有事件", is_event(d)), ("参照有事件", i in ref_events), ("主指标翻转（k）", i in k_set),
                                    ("时限敏感变化", i in sens), ("默认单行超过 10 秒", d is not None and (d["wall"] or 0) > 10))
             if hit]
        if r:
            out.append(i)
            why.update(r)
    return out, dict(why)


def candidates(ids, dkeep, reps):
    """方案第 4 节条件实验的候选，在重放集合里找：默认与三次重放都外层超时、都池损坏，或默认、重放任一次单行超过
    10 秒（Codex 10-07 审核第 13.2 节第 2 项：不只看默认那一遍）。本机预算终止是主动干预（方案第 6 节，单列，不算自然
    死亡）：任何一次是预算终止的行不作池损坏候选，预算终止那几次的耗时也不算慢行。"""
    out = []
    for i in ids:
        d = dkeep.get(i)  # 默认那一遍平凡的行（1 分或正常 0、没有慢步骤、不超过 10 秒）不留精简记录
        rs = [r.get(i) for r in reps]
        runs = [x for x in (d, *rs) if x is not None]
        budget = any(x["class"] == "本机预算终止（未裁定）" for x in runs)
        fd = features(d)[3] if d else []
        frs = [features(r)[3] if r else [] for r in rs]
        outer = "outer_timeout" in fd and all("outer_timeout" in f for f in frs)
        death = not budget and "broken_pool" in fd and all("broken_pool" in f for f in frs)
        walls = [x["wall"] for x in runs if x["class"] != "本机预算终止（未裁定）" and x.get("wall") is not None]
        long_ = any(w > 10 for w in walls)
        if outer or death or long_:
            out.append({"id": i, "outer_timeout_every_time": outer, "pool_broken_every_time": death,
                        "wall_over_10s": long_, "max_wall": max(walls) if walls else None})
    return out


def limits_table(ids, low, dcls, high):
    """时限 2 秒、默认 5 秒、10 秒三种设置下的裁定（参数都是 {编号: 类别}）；不一样的记“本机上对时限敏感”。"""
    pat = Counter()
    for i in ids:
        s = [default_verdict(x.get(i)) for x in (low, dcls, high)]
        pat["/".join("未" if v is None else str(v) for v in s)] += 1
    return {"rows": len(ids), "pattern_2s_5s_10s": dict(pat),
            "sensitive": sum(c for p, c in pat.items() if len(set(p.split("/"))) > 1)}


def retest(ids, dcls, rt):
    """随机 1% 用原设置再跑一遍（参数都是 {编号: 类别}）：类别和裁定变了多少。"""
    changes = Counter()
    for i in ids:
        a, b = dcls.get(i), rt.get(i)
        if a != b:
            changes[f"{a} → {b}"] += 1
    score_flips = sum(1 for i in ids if default_verdict(dcls.get(i)) != default_verdict(rt.get(i)))
    return {"rows": len(ids), "class_changes": dict(changes), "verdict_changes": score_flips}


def decide(metric, types, rep, cands):
    c1 = bool(rep["continue_1_reproducible_final_exception"])
    c2 = metric["continue_2_metric"] or bool(types["confirmed"])
    c3 = "有候选，须做条件实验" if cands else "没有候选，不做"
    stop = (not c1 and not c2 and not cands and metric["stop_2"])
    return {"continue_1": c1, "continue_2": c2, "continue_3": c3,
            "stop": stop, "between": not (c1 or c2) and not stop,
            "note": "继续满足任一条即可；停止要三条都不成立且上界（k+u）低于万分之一。有候选时第 3 条要等条件实验，"
                    "此前不下停止结论。结论措辞按方案第 7 节。"}
