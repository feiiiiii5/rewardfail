"""准备与分析环节的资源保护（Codex 10-07 审核第 13.2 节第 4 项；工作块结束的处理按 10-07 修订复核第 15.2 节补）。

判分段在 supervise.run_phase 里由整机保护（guard.py）每秒查一次；构建任务、读答案类型、分桶合成逐行记录、
段间统计与最终汇总在调度进程自己里跑，原来不在监控之内。StepGuard 在这些环节开一个后台线程，用同一个 Guard
（同一条红线：申请季 D135，只看内存压力是否变红）每秒查一次本进程及其后代；本进程当作“测量进程”传给 Guard。
- 内存压力变红：主线程走到下一个检查点（tick）时停住等，不红之后连续 resume_after 秒再继续；连续 hard_after 秒仍红，
  升级为停止。绿、黄照常；合计 footprint、可用内存、交换区只记录。
- 停止（内存压力持续变红、读不到内存压力）：主线程在下一个检查点抛 StepStop，调用方记下停在哪个环节后退出。
  已完成判分段的原始记录与 pass_done.json 都已落盘，不受影响；续跑时这个环节重来。
- 主线程停止后 GRACE 秒内没走到检查点（例如卡在一次大读取里）：后台线程记一笔，直接 os._exit(EXIT_STUCK)。
  输出文件都先写临时文件再改名（write_atomic），被杀时不会留下半个文件。
- 工作块结束等同最后一个检查点：正常结束时先照检查点的规则处理（暂停就等，停止就抛 StepStop）；再让后台线程结束，
  等它退出后重读状态，线程收尾那一次才查到的停止也照样抛；后台线程 JOIN_S 秒内没退出，当作监控失败，按停止处理。
  所以最后一个检查点之后、工作块结束之前观察到的停止，不会记成正常、也不会进入下一阶段（修订前会，见第 15.2 节）。
  主线程已经带着别的异常离开工作块时不等、不改抛：原异常照常传出，结束记录写 outcome=error、异常摘要，
  并注明当时有待处理的停止。
- 记录写在 log_path（主测量是运行目录的 guard-steps.jsonl）：每个环节的开始与结束、状态（默认每 10 秒，条件变化时
  立刻记）、暂停、停止。结束记录的 outcome：ok、stopped（结束时才抛的另记 stop_at_exit）或 error（带 error 摘要）。
10-07 主测量用的是按方案第 6 节预算的版本（实验仓 9a88991）。
"""
import os
import threading
import time
from pathlib import Path

from rewardfail.s2.guard import Guard

EXIT_STOP, EXIT_STUCK = 7, 6
JOIN_S = 10  # 工作块结束时等后台线程退出的上限（秒）


class StepStop(Exception):
    pass


class StepGuard:
    def __init__(self, log_path, label, *, grace=5.0, poll=1.0, guard=None, **guard_kw):
        self.label, self.grace, self.poll = label, grace, poll
        self.g = guard or Guard(log_path, **guard_kw)
        self.state, self.stop_at, self.reasons, self.ticks, self.waited = "run", None, None, 0, 0.0
        self.ack, self.done = threading.Event(), threading.Event()
        self.th = threading.Thread(target=self._loop, name=f"stepguard-{label}", daemon=True)

    def __enter__(self):
        self.g.log("step_begin", label=self.label, rule="D135")
        self.th.start()
        return self

    def __exit__(self, et, ev, tb):
        """工作块结束（Codex 10-07 修订复核第 15.2 节）。顺序：
        1. 置 ack：主线程已到收尾，停止由这里处理，后台线程不再因宽限直接结束进程；
        2. 正常结束时等同最后一个检查点（监控仍在运行）：暂停就等，停止就准备抛 StepStop；
        3. 让后台线程结束并等它退出，之后才读状态，线程收尾那一次查到的停止也不漏；JOIN_S 秒内没退出当作监控失败；
        4. 先写结束记录再抛。主线程已有异常时不等、不改抛，返回 False 让原异常照常传出；在结束处等暂停时被打断
           （如 Ctrl-C），照样收尾、记下，再抛出原来那个异常。"""
        self.ack.set()
        exc = None  # 结束处要抛的：StepStop，或等暂停时被打断的原异常
        if et is None:
            try:
                self._hold("（工作块结束时）")
            except BaseException as e:
                exc = e
        self.done.set()
        self.th.join(timeout=JOIN_S)
        if self.th.is_alive():
            why = f"监控线程 {JOIN_S} 秒内没结束"
            self.g.log("step_monitor_error", label=self.label, error=why)
            if self.state != "stop":
                self.state, self.stop_at, self.reasons = "stop", time.time(), [[], [why]]
        if et is None and exc is None and self.state == "stop":
            exc = StepStop(f"{self.label}（工作块结束时）：整机保护要求停止（{self.reasons}）")
        kind, err = (et, ev) if et is not None else (type(exc) if exc is not None else None, exc)
        rec = {"label": self.label, "ticks": self.ticks, "waited_s": round(self.waited, 1)}
        if kind is None:
            rec["outcome"] = "ok"
        elif kind is StepStop:
            rec["outcome"] = "stopped"
            if et is None:
                rec["stop_at_exit"] = True
        else:
            rec["outcome"], rec["error"] = "error", f"{kind.__name__}：{err}"[:2000]
            if self.state == "stop":
                rec["pending_stop"] = self.reasons
        self.g.log("step_end", **rec, summary=self.g.summary())
        if exc is not None:
            raise exc
        return False

    def _loop(self):
        me = {os.getpid()}
        while not self.done.wait(self.poll):
            try:
                st = self.g.step(me)
            except Exception as e:  # 监控自己出错，不能当作安全
                self.g.log("step_monitor_error", label=self.label, error=type(e).__name__)
                st = "stop"
            if self.state != "stop":
                self.state = st
                if st == "stop":
                    self.stop_at = time.time()
                    self.reasons = self.g.last_reasons
                    self.g.log("step_stop", label=self.label, reasons=self.reasons)
            if self.state == "stop" and not self.ack.is_set() and time.time() - self.stop_at > self.grace:
                self.g.log("step_kill", label=self.label, reason=f"停止后主线程 {self.grace} 秒没走到检查点，直接退出")
                os._exit(EXIT_STUCK)

    def tick(self):
        """主线程的检查点：正常就返回；暂停时停住等；停止时抛 StepStop。"""
        self.ticks += 1
        self._hold()

    def _hold(self, where=""):
        t0 = None
        while True:
            s = self.state
            if s == "run":
                if t0 is not None:
                    self.waited += time.time() - t0
                return
            if s == "stop":
                self.ack.set()
                raise StepStop(f"{self.label}{where}：整机保护要求停止（{self.reasons}）")
            t0 = t0 or time.time()
            time.sleep(min(self.poll, 0.2))


class NoGuard:
    """流程替身测试用：同样的接口，不查也不停。"""

    def __init__(self, *a, **k):
        self.ticks = 0

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def tick(self):
        self.ticks += 1


def every(n, tick):
    """每调用 n 次才真正查一次的检查点，给逐行循环用。"""
    c = [0]

    def f():
        c[0] += 1
        if c[0] % n == 0:
            tick()
    return f


def write_atomic(path, text):
    """先写同目录的临时文件再改名：进程在写的时候被杀，不会留下半个文件。"""
    path = Path(path)
    tmp = path.with_name(path.name + f".tmp-{os.getpid()}")
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)
