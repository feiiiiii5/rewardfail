"""调度：把任务分给 P 个测量进程，在整机保护下运行（见 guard.py）。

- 每个测量进程单独成一个进程组（start_new_session），整项停止时连同它的进程池子进程一起杀掉；
  测量进程退出后（不论正常与否）也把组里剩下的本环境 Python 进程清掉，不留孤儿。
- 测量进程逐行落盘：开始一行先写 progress，判完写 results。整项停止或测量进程异常退出后，
  开始了却没写结果的行记一次中断（注明原因），恢复后重跑；中断两次的行写成未裁定，不再重跑。
- 整项停止后并发降到 0，等保护条件连续解除，再按减半的 P（至少 1）从检查点续跑；
  同一阶段整项停止 3 次，或连续两次启动都没有新完成的行，就放弃这一阶段并报告。
- 调用方给的 P 小于 1 时不启动。整机保护按申请季 D135 只看内存压力是否变红（guard.py）。
"""
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import psutil

from rewardfail.s2.guard import Guard

ROOT = Path(__file__).resolve().parents[2]
WORKER = ROOT / "experiments/s2_worker.py"
REAL_PY = os.path.realpath(sys.executable)  # psutil 给的是解析过链接的真实路径


def _ids(run_dir, pattern):
    out = set()
    for f in run_dir.glob(pattern):
        for line in f.read_text(encoding="utf-8").splitlines():
            if line.strip():
                out.add(json.loads(line)["id"])
    return out


def _partition(tasks, P):
    """有分片和行号的按 (分片, 行号) 排好切成 P 段连续块，各进程读不同的行组；合成任务保持原顺序。"""
    if tasks and all("shard" in t for t in tasks):
        tasks = sorted(tasks, key=lambda t: (t["shard"], t["row"], t.get("idx", 0)))
    n = len(tasks)
    parts = [tasks[i * n // P:(i + 1) * n // P] for i in range(P)]
    return [p for p in parts if p]


def _group_members(pgid):
    out = []
    for p in psutil.process_iter(["pid"]):
        try:
            if os.getpgid(p.pid) == pgid and p.exe() == REAL_PY:
                out.append(p)
        except (psutil.Error, ProcessLookupError, PermissionError, OSError):
            pass
    return out


def _kill_group(pgid, leader_alive):
    """杀掉一个测量进程组。组长还没被回收时直接 killpg（组号不会被复用）；否则只杀组里仍在的本环境 Python 进程。"""
    if leader_alive:
        try:
            os.killpg(pgid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        return -1
    left = _group_members(pgid)
    for p in left:
        try:
            p.kill()
        except psutil.Error:
            pass
    return len(left)


def run_phase(run_dir, tasks, P, *, worker_args=(), guard_kw=None, max_stops=3, label="phase", row_limit=None):
    run_dir = Path(run_dir)
    (run_dir / "child_logs").mkdir(parents=True, exist_ok=True)
    if P < 1:
        return {"aborted": "并发算出来小于 1，不启动", "P": P}
    k = len(list(run_dir.glob(f"guard-{label}*.jsonl")))
    if k:  # 同一目录再次调用（检查点续跑）：测量进程另起名字，记录不与上次混在一起
        label = f"{label}-r{k}"
    guard = Guard(run_dir / f"guard-{label}.jsonl", **(guard_kw or {}))
    ipath = run_dir / "interrupts.json"
    interrupts = json.loads(ipath.read_text(encoding="utf-8")) if ipath.exists() else {}
    ids = {t["id"] for t in tasks}
    launches, no_progress, t_start = 0, 0, time.time()
    pause_file = run_dir / "PAUSE"
    history = []
    while True:
        done = _ids(run_dir, "results-*.jsonl")
        todo = []
        for t in tasks:
            if t["id"] in done:
                continue
            if len(interrupts.get(t["id"], [])) >= 2:  # 中断两次：记未裁定，不再重跑
                with open(run_dir / "results-supervisor.jsonl", "a", encoding="utf-8") as fh:
                    fh.write(json.dumps({"id": t["id"], "undetermined": "中断两次", "interrupts": interrupts[t["id"]]},
                                        ensure_ascii=False) + "\n")
                continue
            todo.append(t)
        if not todo:
            break
        launches += 1
        procs, names = [], []
        for i, part in enumerate(_partition(todo, P)):
            name = f"{label}{launches}w{i}"
            tf = run_dir / f"tasks-{name}.jsonl"
            tf.write_text("".join(json.dumps(t, ensure_ascii=False) + "\n" for t in part), encoding="utf-8")
            log = open(run_dir / f"worker-{name}.log", "a", encoding="utf-8")
            args = [sys.executable, "-I", str(WORKER), "--run-dir", str(run_dir), "--tasks", str(tf), "--worker", name,
                    "--parent-pid", str(os.getpid()), *worker_args]
            if row_limit:
                args += ["--row-limit", str(row_limit)]
            procs.append(subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
                                          cwd=str(run_dir)))
            log.close()
            names.append(name)
        guard.log("launch", label=label, launch=launches, P=len(procs), todo=len(todo), workers=names,
                  pids=[p.pid for p in procs])
        stopped = None
        while True:
            alive = [p for p in procs if p.returncode is None and p.poll() is None]
            if not alive:
                break
            act = guard.step([p.pid for p in alive])
            if act == "stop":
                for p in procs:
                    _kill_group(p.pid, leader_alive=p.returncode is None)
                for p in procs:
                    p.wait()
                stopped = "整项停止（本机资源干预）"
                break
            if act == "pause":
                pause_file.touch()
            elif pause_file.exists():
                pause_file.unlink()
            time.sleep(1)
        if pause_file.exists():
            pause_file.unlink()
        orphans = sum(max(0, _kill_group(p.pid, leader_alive=False)) for p in procs)  # 正常退出后组里不该还有人
        codes = [p.returncode for p in procs]
        done_now = _ids(run_dir, "results-*.jsonl")
        started = _ids(run_dir, "progress-*.jsonl")
        why = stopped or ("测量进程异常退出" if any(c != 0 for c in codes) else "测量进程正常退出但行未完成")
        newly = sorted((started & ids & set(t["id"] for t in todo)) - done_now)
        for rid in newly:
            interrupts.setdefault(rid, []).append({"launch": f"{label}{launches}", "why": why})
        ipath.write_text(json.dumps(interrupts, ensure_ascii=False, indent=1), encoding="utf-8")
        progressed = len(done_now & ids) > len(done & ids)
        guard.log("launch_end", launch=launches, codes=codes, stopped=bool(stopped), done=len(done_now & ids),
                  interrupted=newly, orphans_killed=orphans)
        history.append({"launch": launches, "P": len(procs), "codes": codes, "stopped": bool(stopped),
                        "interrupted": len(newly), "orphans_killed": orphans})
        no_progress = 0 if progressed else no_progress + 1
        if no_progress >= 2:
            return {"aborted": "连续两次启动都没有新完成的行", "history": history, "guard": guard.summary()}
        if stopped:
            if guard.stops >= max_stops:
                return {"aborted": f"整项停止 {guard.stops} 次", "history": history, "guard": guard.summary()}
            guard.wait_clear()
            P = max(1, P // 2)
    return {"aborted": None, "history": history, "seconds": round(time.time() - t_start, 1), "guard": guard.summary()}
