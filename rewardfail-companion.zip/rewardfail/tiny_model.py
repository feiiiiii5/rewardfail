"""在本机现造一个只有配置、没有权重的“模型目录”，供 verl 读分词器和 hf_config。

不下载任何文件。分词器是字节级 BPE、没有合并规则：任意文本都能编码，解码逐字节还原。
"""

import json
import os

EOS = "<|endoftext|>"


def build(out_dir: str) -> str:
    from tokenizers import Tokenizer, decoders, models, pre_tokenizers
    from transformers import PreTrainedTokenizerFast, Qwen2Config

    os.makedirs(out_dir, exist_ok=True)
    alphabet = pre_tokenizers.ByteLevel.alphabet()
    vocab = {ch: i for i, ch in enumerate(sorted(alphabet))}
    tok = Tokenizer(models.BPE(vocab=vocab, merges=[]))
    tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tok.decoder = decoders.ByteLevel()
    tok.add_special_tokens([EOS])
    fast = PreTrainedTokenizerFast(tokenizer_object=tok, eos_token=EOS, pad_token=EOS)
    fast.chat_template = (
        "{% for m in messages %}{{ m['role'] }}: {{ m['content'] }}\n{% endfor %}"
        "{% if add_generation_prompt %}assistant: {% endif %}"
    )
    fast.save_pretrained(out_dir)

    cfg = Qwen2Config(
        vocab_size=len(fast),
        hidden_size=16,
        intermediate_size=32,
        num_hidden_layers=1,
        num_attention_heads=2,
        num_key_value_heads=1,
        max_position_embeddings=4096,
        architectures=["Qwen2ForCausalLM"],
        eos_token_id=fast.eos_token_id,
        pad_token_id=fast.pad_token_id,
    )
    cfg.save_pretrained(out_dir)
    with open(os.path.join(out_dir, "README.txt"), "w") as f:
        f.write("本机生成的替身：只有分词器和配置，没有权重。由 rewardfail/tiny_model.py 生成。\n")
    return out_dir


if __name__ == "__main__":
    import sys

    path = build(sys.argv[1] if len(sys.argv) > 1 else "artifacts/tiny_model")
    print(json.dumps({"tiny_model": os.path.abspath(path), "files": sorted(os.listdir(path))}, ensure_ascii=False))
