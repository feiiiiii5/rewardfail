#!/usr/bin/env bash
# 复现环境：固定解释器版本 + 带哈希的锁文件 + 固定提交的被测代码。不下载任何模型或数据集。
# 需要：git、uv（本机用的是 uv 0.12.10）。锁文件按 macOS arm64 / CPython 3.12 生成。
set -euo pipefail
cd "$(dirname "$0")"

fetch() {
  local dir=$1 sha=$2
  if [ ! -d "$dir/.git" ]; then
    git init -q "$dir"
    git -C "$dir" remote add origin https://github.com/verl-project/verl.git
  fi
  git -C "$dir" fetch -q --depth 1 origin "$sha"
  git -C "$dir" checkout -q "$sha"
  test "$(git -C "$dir" rev-parse HEAD)" = "$sha"
  test -z "$(git -C "$dir" status --porcelain)"
}

fetch third_party/verl-pr8015 0c4c3d40d46d5f47d1918c905641eea969b7fa09   # 被测：#8015 head
fetch third_party/verl-pr7437 1403781f1ae88b50c7544adc2d4bc2ddb1c178af   # 对照：#7437 head

# 环境放在不随 iCloud 同步的位置（本机桌面开着 iCloud 同步，1.2 GB 的环境放在桌面会被上传），再用 .venv 链接过去
VENV=${REWARDFAIL_VENV:-$HOME/.local/share/rewardfail/venv}
uv venv --python 3.12.8 "$VENV"
uv pip sync --python "$VENV/bin/python" requirements.lock
uv pip install --python "$VENV/bin/python" --no-deps -e third_party/verl-pr8015
[ -e .venv ] || ln -s "$VENV" .venv
.venv/bin/python -m rewardfail.tiny_model artifacts/tiny_model
echo "环境就绪：.venv/bin/python $(.venv/bin/python --version 2>&1)"
