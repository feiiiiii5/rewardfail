#!/bin/bash
# get_data.sh 的离线测试：用本机生成的假文件和 file:// 地址，不连网。
# 用法：bash tests/test_get_data.sh zh_CN.UTF-8 get_data.sh（第一个参数是语言环境；macOS 自带 bash 3.2 在 UTF-8 环境下才会暴露 10-06 的变量解析错误）
# 退出码：全部通过为 0，有失败项为 1。本脚本自己的输出语句也要写 ${name}，并在 UTF-8 环境下运行它本身
L="$1"; SRC_SCRIPT="$2"
S=$(mktemp -d "${TMPDIR:-/tmp}/gd.XXXX") && [ -d "$S" ] || exit 1
trap 'rm -rf "$S"' EXIT   # 只删本脚本刚建的临时目录
mkdir -p "$S/repo" "$S/src"; cp "$SRC_SCRIPT" "$S/repo/get_data.sh"
printf 'hello world\n' > "$S/src/a.txt"; head -c 300000 /dev/urandom > "$S/src/b.bin"
# git blob 值按定义独立算（"blob 字节数\0" 加原文，取 sha1），不经过 git，不受本机 git 设置影响
blob() { { printf 'blob %s\0' "$(wc -c < "$1" | tr -d ' ')"; cat "$1"; } | shasum -a 1 | cut -d' ' -f1; }
A_SHA=$(shasum -a 256 "$S/src/a.txt" | cut -d' ' -f1); B_GIT=$(blob "$S/src/b.bin")
printf '# rel\tsrc\tbytes\tkind\tdigest\nopenr1/a.txt\tfile://%s/src/a.txt\t%s\tsha256\t%s\nb.bin\tfile://%s/src/b.bin\t%s\tgitblob\t%s\n' \
  "$S" "$(wc -c < "$S/src/a.txt" | tr -d ' ')" "$A_SHA" "$S" "$(wc -c < "$S/src/b.bin" | tr -d ' ')" "$B_GIT" > "$S/repo/data_manifest.tsv"
run() { env -i HOME="$HOME" PATH=/usr/bin:/bin LANG="$L" LC_ALL="$L" REWARDFAIL_DATA="$S/dest" "$@"; }
cd "$S"; pass=0; fail=0
t() { if eval "$2"; then echo "  通过  $1"; pass=$((pass+1)); else echo "  失败  $1"; fail=$((fail+1)); fi; }
t "语法" "/bin/bash -n repo/get_data.sh"
run /bin/bash repo/get_data.sh --bogus >/dev/null 2>&1; rc=$?
t "未知参数退出码 2 且不建目录、不建链接" "[ $rc = 2 ] && [ ! -e dest ] && [ ! -e repo/data ] && [ ! -L repo/data ]"
run /bin/bash repo/get_data.sh --help >/dev/null 2>&1; t "--help 退出码 0" "[ $? = 0 ]"
run /bin/bash repo/get_data.sh --check extra >/dev/null 2>&1; t "参数过多退出码 2" "[ $? = 2 ]"
run /bin/bash repo/get_data.sh --check > o5.txt 2>&1; rc=$?
t "--check 无数据：退出码 1、报缺失、不建目录和链接" "[ $rc = 1 ] && grep -q '缺失或不符  openr1/a.txt' o5.txt && [ ! -e dest ] && [ ! -L repo/data ]"
env -i HOME="$HOME" PATH=/usr/bin:/bin LANG="$L" LC_ALL="$L" REWARDFAIL_DATA="$S/dest" HTTPS_PROXY=http://user:secretpw@127.0.0.1:1 /bin/bash repo/get_data.sh > o6.txt 2>&1; rc=$?
t "下载：退出码 0、两个文件核对通过、显示“下载”行" "[ $rc = 0 ] && grep -q '通过 2 个，未通过 0 个' o6.txt && grep -q '下载    openr1/a.txt（12 bytes）' o6.txt"
t "带密码的代理不出现在输出里" "! grep -q secretpw o6.txt && grep -q '代理环境变量：已设置（不显示地址）' o6.txt"
t "下载后写了一行下载记录" "[ \$(wc -l < dest/下载记录.tsv | tr -d ' ') = 1 ]"
run /bin/bash repo/get_data.sh --check > o7.txt 2>&1; rc=$?
t "--check 全有：退出码 0、不写下载记录" "[ $rc = 0 ] && [ \$(wc -l < dest/下载记录.tsv | tr -d ' ') = 1 ]"
run /bin/bash repo/get_data.sh > o8.txt 2>&1; rc=$?
t "重跑：已核对的跳过，不重下" "[ $rc = 0 ] && grep -q '已核对  openr1/a.txt' o8.txt && ! grep -q '下载    ' o8.txt"
head -c 100000 "$S/src/b.bin" > dest/b.bin
run /bin/bash repo/get_data.sh > o9.txt 2>&1; rc=$?
t "只下了一部分的文件：续传后核对通过" "[ $rc = 0 ] && grep -q '下载    b.bin' o9.txt && grep -q '通过 2 个，未通过 0 个' o9.txt"
printf 'corrupted!!\n' > dest/openr1/a.txt
run /bin/bash repo/get_data.sh > o10.txt 2>&1; rc=$?
t "内容不符的文件：删掉重下后通过" "[ $rc = 0 ] && grep -q '通过 2 个，未通过 0 个' o10.txt"
rm -f repo/data; ln -s "$S/nowhere" repo/data
run /bin/bash repo/get_data.sh > o11.txt 2>&1; rc=$?
t "仓内 data 是悬空链接：不出错、给提示、不改链接" "[ $rc = 0 ] && grep -q '注意：仓内 data 链接指向' o11.txt && [ \"\$(readlink repo/data)\" = '$S/nowhere' ]"
printf 'c.txt\tfile://%s/src/none.txt\t5\tsha256\t%s\n' "$S" "$A_SHA" >> repo/data_manifest.tsv
sed -i '' 's/sleep 3/sleep 0/' repo/get_data.sh
run /bin/bash repo/get_data.sh > o12.txt 2>&1; rc=$?
t "来源不可达：重试 5 次后报校验失败、退出码 1，其余文件不受影响" "[ $rc = 1 ] && grep -q '校验失败  c.txt' o12.txt && [ \$(grep -c '没下完整' o12.txt) = 4 ] && grep -q '通过 2 个，未通过 1 个' o12.txt"
# 带 CRLF 换行的文本文件：git 设了 core.autocrlf=input 时（本机全局就是这样），不加 --no-filters 的 git hash-object 会先转换换行再算（10-06 实跑人工标注集 CSV 时暴露）
mkdir -p repo2; cp repo/get_data.sh repo2/get_data.sh; sed -i '' 's/sleep 3/sleep 0/' repo2/get_data.sh   # 已在 $S 里，复制开头那份被测脚本
printf 'id,label\r\n1,correct\r\n2,wrong\r\n' > src/crlf.csv
printf '# rel\tsrc\tbytes\tkind\tdigest\ngold/crlf.csv\tfile://%s/src/crlf.csv\t%s\tgitblob\t%s\n' "$S" "$(wc -c < src/crlf.csv | tr -d ' ')" "$(blob src/crlf.csv)" > repo2/data_manifest.tsv
run2() { env -i HOME="$HOME" PATH=/usr/bin:/bin LANG="$L" LC_ALL="$L" REWARDFAIL_DATA="$S/dest2" GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=core.autocrlf GIT_CONFIG_VALUE_0=input "$@"; }
run2 /bin/bash repo2/get_data.sh > o13.txt 2>&1; rc=$?
t "带 CRLF 的文件（autocrlf=input）：下一次就核对通过，不删了重下" "[ $rc = 0 ] && grep -q '下载    gold/crlf.csv' o13.txt && grep -q '通过 1 个，未通过 0 个' o13.txt && ! grep -qE '核对不符|没下完整' o13.txt"
run2 /bin/bash repo2/get_data.sh --check > o14.txt 2>&1; rc=$?
t "同一文件 --check 通过" "[ $rc = 0 ] && grep -q '已核对  gold/crlf.csv' o14.txt"
printf 'wrong.txt\tfile://%s/src/a.txt\t12\tsha256\t%064d\n' "$S" 0 >> repo2/data_manifest.tsv
run2 /bin/bash repo2/get_data.sh > o15.txt 2>&1; rc=$?
t "大小对、校验值不符：提示“下完但核对不符”4 次后报校验失败、退出码 1" "[ $rc = 1 ] && [ \$(grep -c '下完但核对不符' o15.txt) = 4 ] && ! grep -q '没下完整' o15.txt && grep -q '校验失败  wrong.txt' o15.txt && grep -q '已核对  gold/crlf.csv' o15.txt"
echo "LANG=${L}：通过 ${pass} 项，失败 ${fail} 项"
[ "${fail}" -eq 0 ]   # 有失败项时退出码非零
