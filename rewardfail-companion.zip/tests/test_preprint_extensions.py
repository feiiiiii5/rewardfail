"""Boundary tests for new preprint experiments; old measurement code is read-only."""
import csv
import io
import json
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))
import s2_e3 as e3
import s2_e1 as e1
import s2_e2 as e2
import s2_contract as contract
import check_artifacts as artifacts


class Extensions(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.d = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def fixture(self, **changes):
        r = {"group_id": "g", "prompt_id": "p", "cid": "0", "model": "m", "gt_answer": "2", "raw_answer": " 2\n",
             "human_label": "1", "primary_cat": "numeric", "double_annotate": "False", "annotator2_label": ""}
        r.update(changes)
        return r

    def csv(self, rows):
        out = io.StringIO(newline="")
        writer = csv.DictWriter(out, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
        path = self.d / "a.csv"
        path.write_bytes(b"\xef\xbb\xbf" + out.getvalue().encode())
        return path

    def test_csv_preserves_strings_and_bom(self):
        r = e3.read_csv(self.csv([self.fixture()]), locked=False)[0]
        self.assertEqual(r["raw_answer"], " 2\n")
        self.assertEqual(r["human_label"], "1")

    def test_csv_duplicate_rejected(self):
        with self.assertRaises(ValueError):
            e3.read_csv(self.csv([self.fixture(), self.fixture()]), locked=False)

    def test_csv_bad_label_rejected(self):
        with self.assertRaises(ValueError):
            e3.read_csv(self.csv([self.fixture(human_label="maybe")]), locked=False)

    def test_csv_bad_second_label_rejected(self):
        with self.assertRaises(ValueError):
            e3.read_csv(self.csv([self.fixture(double_annotate="True")]), locked=False)

    def test_csv_hash_lock_rejected(self):
        with self.assertRaises(ValueError):
            e3.read_csv(self.csv([self.fixture()]))

    def test_boxed_alias_and_raw_preservation(self):
        rs = [dict(self.fixture(), id="a"), dict(self.fixture(raw_answer="\\boxed{2}"), id="b")]
        raw, aliases = e3.tasks_for(rs, "raw")
        boxed, aliases_b = e3.tasks_for(rs, "boxed")
        self.assertEqual(raw[0]["out"], " 2\n")
        self.assertEqual(boxed[0]["out"], "\\boxed{ 2\n}")
        self.assertEqual(aliases, [])
        self.assertEqual(aliases_b, ["b"])

    def write(self, name, rows):
        (self.d / name).write_text("".join(json.dumps(r) + "\n" for r in rows))

    def test_dead_supervisor_recovery_idempotent(self):
        self.write("progress-p1w0.jsonl", [{"id": "a"}, {"id": "b"}])
        self.write("results-p1w0.jsonl", [{"id": "a"}])
        self.assertEqual(len(e3.recover_interrupts(self.d, lambda n: False)), 1)
        self.assertEqual(e3.recover_interrupts(self.d, lambda n: False), [])
        self.assertEqual(len(json.loads((self.d / "interrupts.json").read_text())["b"]), 1)

    def test_later_success_does_not_erase_prior_interruption(self):
        self.write("progress-p1w0.jsonl", [{"id": "b"}])
        self.write("progress-p-r11w0.jsonl", [{"id": "b"}])
        self.write("results-p-r11w0.jsonl", [{"id": "b"}])
        e3.recover_interrupts(self.d, lambda n: False)
        self.assertEqual(len(json.loads((self.d / "interrupts.json").read_text())["b"]), 1)

    def test_second_dead_attempt_counts_twice(self):
        self.write("progress-p1w0.jsonl", [{"id": "b"}])
        self.write("progress-p-r11w0.jsonl", [{"id": "b"}])
        e3.recover_interrupts(self.d, lambda n: False)
        self.assertEqual(len(json.loads((self.d / "interrupts.json").read_text())["b"]), 2)

    def test_already_counted_interruption_is_not_counted_twice(self):
        self.write("progress-p1w0.jsonl", [{"id": "b"}])
        (self.d / "interrupts.json").write_text(json.dumps({"b": [{"launch": "p1", "why": "exit"}]}))
        self.assertEqual(e3.recover_interrupts(self.d, lambda n: False), [])

    def test_active_worker_forbids_resume(self):
        self.write("progress-p1w0.jsonl", [{"id": "b"}])
        with self.assertRaises(RuntimeError):
            e3.recover_interrupts(self.d, lambda n: True)
        self.assertFalse((self.d / "interrupts.json").exists())

    def test_failure_cost_not_all_false_negatives(self):
        rows = [dict(self.fixture(), id="a"), dict(self.fixture(cid="1"), id="b"), dict(self.fixture(cid="2"), id="c")]
        def result(cls, score, problems=(), steps=()):
            return {"class": cls, "score": score, "problems": list(problems), "flags": [],
                    "attempts": [{"outcome": "return", "steps": list(steps)}]}
        got = e3.tally(rows, {"a": result("正常 0", 0), "b": result("0 分：比较超时", 0, steps=[("compare", 5, True, ["Timeout comparison"], 1)]),
                             "c": result("观测不完整（未裁定）", 0, ["missing step"])})
        self.assertEqual(got["counts"]["failure_zero_human_one"], 1)
        self.assertEqual(got["counts"]["normal_false_negative"], 1)
        self.assertEqual(got["counts"]["incomplete_or_intervened"], 1)

    def test_e1_core_matrix_and_matching(self):
        inp = {"normal": [{"id": f"n{i}", "gt": "2", "out": "2"} for i in range(64)],
               "warm": [{"id": f"w{i}", "gt": "1", "out": "1"} for i in range(4)],
               "heavy": {i: {"id": i, "gt": "0", "out": "9"} for i in e1.diag.D1_IDS}}
        cases = e1.specs(self.d, inp)
        self.assertEqual(len(cases), 40)
        for c in cases:
            self.assertEqual((c["manager"], len(c["rows"]), c["outer"]), ("naive", 64, 30))
            diffs = [i for i, (a, b) in enumerate(zip(c["rows"], inp["normal"])) if a != b]
            expected = [] if c["variant"] == "normal" else [32 if c["variant"] == "bfc8-later" else 0]
            self.assertEqual(diffs, expected)
            self.assertEqual(c["following"][0]["out"], inp["normal"][0]["out"])

    def test_e1_selftest_distinguishes_synthetic_outer_limit(self):
        inp = {"normal": [{"id": "n", "gt": "2", "out": "2"}], "warm": []}
        cases = e1.specs(self.d, inp, True)
        self.assertEqual(len(cases), 10)
        self.assertTrue(all(c["outer"] == 0.25 for c in cases if c["variant"] == "outer"))
        self.assertTrue(all(c["outer"] == 30 for c in cases if c["variant"] != "outer"))

    def test_e1_eight_row_matching_and_three_distinct_heavy_inputs(self):
        inp = {"normal": [{"id": f"n{i}", "gt": "2", "out": "2"} for i in range(64)],
               "warm": [], "heavy": {i: {"id": i, "gt": "0", "out": "9"} for i in e1.diag.D1_IDS}}
        cases = e1.specs(self.d, inp, eight=True)
        self.assertEqual(len(cases), 16)
        self.assertEqual({c["manager"] for c in cases}, {"naive", "limited"})
        for c in cases:
            self.assertEqual((len(c["rows"]), len(c["following"]), c["outer"]), (8, 8, 30))
            heavy_ids = [r["id"] for r in c["rows"] if r["id"] in e1.diag.D1_IDS]
            self.assertEqual(heavy_ids, [] if c["variant"] == "normal" else list(e1.diag.D1_IDS[:3]))
            self.assertTrue(all(r["id"].startswith("following-") for r in c["following"]))

    def test_e1_recovery_requires_continuous_clear_readings(self):
        for middle in (4, None):
            t = [0]
            def read():
                return middle if t[0] == 10 else 2
            e1.wait_clear(read=read, now=lambda: t[0], sleep=lambda dt: t.__setitem__(0, t[0]+dt))
            self.assertEqual(t[0], 41)

    def test_e1_repetitions_and_child_observation_off_are_separate(self):
        inp = {"normal": [{"id": f"n{i}", "gt": "2", "out": "2"} for i in range(64)],
               "warm": [], "heavy": {i: {"id": i, "gt": "0", "out": "9"} for i in e1.diag.D1_IDS}}
        cases = e1.specs(self.d, inp, repeat_three=True)
        self.assertEqual(len(cases), 6)
        for wrapper in ("pr", "main"):
            selected = [c for c in cases if c["wrapper"] == wrapper]
            self.assertEqual([(c["repeat"], c["observe"]) for c in selected], [(2, True), (3, True), (1, False)])
            self.assertTrue(all((c["manager"], c["lib"], c["outer"], len(c["following"])) == ("naive", 60, 30, 8) for c in selected))

    def test_e1_controls_change_only_declared_calling_layer_and_deadline(self):
        inp = {"normal": [{"id": f"n{i}", "gt": "2", "out": "2"} for i in range(64)],
               "warm": [], "heavy": {i: {"id": i, "gt": "0", "out": "9"} for i in e1.diag.D1_IDS}}
        cases = e1.specs(self.d, inp, controls=True)
        self.assertEqual(len(cases), 14)
        for wrapper in ("pr", "main"):
            selected = [c for c in cases if c["wrapper"] == wrapper]
            self.assertEqual(len(selected), 7)
            self.assertEqual(sum(c["manager"] == "direct" for c in selected), 4)
        for c in cases:
            self.assertEqual((len(c["rows"]), len(c["following"]), c["repeat"]), (8, 8, 1))
            if c["manager"] == "direct":
                self.assertEqual(c["outer"], 30)
                self.assertIn(c["lib"], (None, 60))
            else:
                self.assertEqual((c["manager"], c["lib"], c["outer"]), ("naive", 60, 300))
            expected = [] if c["variant"] == "normal" else list(e1.diag.D1_IDS[:1 if c["variant"] == "imo-first" else 3])
            self.assertEqual([r["id"] for r in c["rows"] if r["id"] in e1.diag.D1_IDS], expected)
            self.assertEqual([r["out"] for r in c["following"]], [r["out"] for r in inp["normal"][:8]])

    def test_e1_compact_index_retains_counts_and_raw_hash(self):
        result = {"spec": {"dir": str(self.d), "rows": [{"id": "n", "gt": "2", "out": "2"}],
                           "following": [], "warm": []},
                  "batches": [{"name": "test", "scores": [1.0], "extras": [{"acc": 1.0}]}]}
        p = self.d / "result.json";p.write_text(json.dumps(result))
        index = e1.compact_scene(result)
        self.assertEqual(index["batches"][0]["score_counts"], {"1.0": 1})
        self.assertEqual(index["batches"][0]["extra_key_counts"], {"acc": 1})
        self.assertEqual(index["raw_result"]["sha256"], e1.s2_main.file_sha(p))
        self.assertNotIn("rows", index["spec"])

    def test_e1_monitor_red_unreadable_and_yellow(self):
        for pressure in (4, None, 2):
            d = self.d / str(pressure)
            class Process:
                pid = 987654
                returncode = None
                def poll(self): return self.returncode
                def wait(self): self.returncode = -9 if pressure in (4, None) else 0; return self.returncode
            p = Process()
            class Guard:
                def __init__(self, *a): self.fh = open(d / "fake-guard", "w")
                def log(self, *a, **kw): pass
                def sample(self, *a): return {"pressure": pressure}
            with patch.object(e1.guard, "Guard", Guard), patch.object(e1.guard, "pressure", return_value=1), \
                 patch("subprocess.Popen", return_value=p), patch.object(e1.os, "killpg") as kill, \
                 patch.object(e1.s2_main.supervise, "_kill_group", return_value=0), \
                 patch.object(e1.time, "sleep", side_effect=lambda dt: p.wait()):
                got = e1.monitor({"dir": str(d)})
            self.assertEqual(kill.called, pressure in (4, None))
            self.assertEqual(got["intervention"] is not None, pressure in (4, None))


class CorpusExtension(unittest.TestCase):
    def mapping(self, key, row, k, pick):
        import hashlib
        return {"key": hashlib.sha256(key.encode()).hexdigest(), "shard": "a.parquet", "row": row, "k": k, "pick": pick}

    def result(self, rid, cls="正常 0", event=False, problems=()):
        return {"id": rid, "class": cls, "problems": list(problems),
                "attempts": [{"outcome": "ok", "steps": [("compare", 5.0, True, ["Timeout during comparison"] if event else [], 1)]}]}

    def test_complement_excludes_selected_answer_including_singletons(self):
        mapping = [self.mapping("one", 0, 1, 0), self.mapping("three", 1, 3, 1)]
        tasks, meta, mains = e2.build(mapping)
        self.assertEqual([t["idx"] for t in tasks], [0, 2])
        self.assertEqual(len(meta), 4); self.assertEqual(len(mains), 2)
        self.assertFalse(set(mains) & {t["id"] for t in tasks})

    def test_inventory_rejects_duplicate_question_and_position(self):
        a = self.mapping("a", 0, 2, 0)
        for b in (dict(a, row=1), self.mapping("b", 0, 2, 1)):
            with self.assertRaises(ValueError): e2.build([a, b])

    def test_inventory_rejects_bad_pick_size_and_short_hash(self):
        a = self.mapping("a", 0, 2, 0)
        for b in (dict(a, k=7), dict(a, pick=2), dict(a, key="01")):
            with self.assertRaises(ValueError): e2.build([b])

    def test_truncated_identifier_collision_is_rejected(self):
        a = self.mapping("a", 0, 2, 0); b = self.mapping("b", 1, 2, 0)
        b["key"] = a["key"][:16] + b["key"][16:]
        with self.assertRaises(ValueError): e2.build([a, b])

    def test_reference_covers_zero_unknown_and_stable_controls(self):
        tasks, meta = e2.synthetic(); ids = [t["id"] for t in tasks]
        cls = {ids[0]: "1 分", ids[1]: "正常 0", ids[2]: "未裁定（中断两次）"}
        refs, controls = e2.reference_ids(ids, cls, meta, 1)
        self.assertEqual(set(refs), set(ids)); self.assertEqual(controls, [ids[0]])
        other, controls2 = e2.reference_ids(ids[::-1], cls, meta, 1)
        self.assertEqual(set(other), set(refs)); self.assertEqual(controls2, controls)

    def test_finite_metric_distinguishes_reference_timeout_and_ordinary_zero(self):
        ids = list("abcde")
        d = dict(zip(ids, ["正常 0", "正常 0", "观测不完整（未裁定）", "正常 0", "1 分"]))
        r = dict(zip(ids, ["1 分", "0 分：比较超时", "1 分", "正常 0", "正常 0"]))
        got = e2.metric(ids, d, r)
        self.assertEqual(got["k_ids"], ["a"]); self.assertEqual(got["u_ids"], ["b", "c"])
        self.assertEqual(got["k_plus_u_over_n"], .6)
        self.assertFalse(any("ci" in k or "threshold" in k for k in got))

    def group_fixture(self):
        meta = {i: {"key": "g1", "k": 3} for i in "abc"}
        meta.update({i: {"key": "g2", "k": 2} for i in "de"}); meta["f"] = {"key": "g3", "k": 1}
        rows = [self.result(i, event=i in "abdf", cls="观测不完整（未裁定）" if i == "e" else "正常 0") for i in "abcdef"]
        return meta, rows

    def test_directed_pair_denominators_unknown_range_and_singleton_exclusion(self):
        meta, rows = self.group_fixture(); got = e2.group_description(rows, meta)
        self.assertEqual(got["observed_event_answers"], 4)
        self.assertEqual(got["eligible_multi_answer_questions"], 2)
        self.assertEqual(got["multiple_event_question_fraction"], .5)
        self.assertEqual(got["directed_other_answer_pairs"], 5)
        self.assertEqual(got["observed_both_event_pairs"], 2)
        self.assertEqual(got["unknown_other_endpoint_pairs"], 1)
        self.assertEqual(got["other_answer_event_descriptive_range"], [.4, .6])

    def test_missing_duplicate_and_unmapped_results_refused(self):
        meta, rows = self.group_fixture()
        for bad in (rows[:-1], rows + rows[:1], rows + [self.result("unknown")]):
            with self.assertRaises(ValueError): e2.group_description(bad, meta)

    def test_zero_observed_events_does_not_hide_unknown(self):
        rows = [self.result("x", "观测不完整（未裁定）"), self.result("y")]
        meta = {i: {"key": "g", "k": 2} for i in "xy"}
        got = e2.group_description(rows, meta)
        self.assertEqual(got["unknown_no_event_answers"], 1)
        self.assertEqual(got["observed_event_answers"], 0)
        self.assertIsNone(got["other_answer_event_descriptive_range"])


class AggregationProposal(unittest.TestCase):
    def test_all_flag_positions_and_padding_declared(self):
        cases = contract.cases()
        self.assertEqual(len(cases), 21)
        self.assertEqual(len({c["name"] for c in cases}), 21)
        for kind in ("error", "timeout"):
            selected = [c for c in cases if c["name"].startswith(kind + "-position")]
            self.assertEqual(len(selected), 8)
            positions = [next(i for i, r in enumerate(c["outputs"]) if kind in r["reward_extra_info"]) for c in selected]
            self.assertEqual(positions, list(range(8)))
        padded = next(c for c in cases if c["name"] == "padding-trim")
        self.assertEqual((len(padded["outputs"]), padded["workers"]), (7, 2))

    def test_patch_refuses_unexpected_key_expression(self):
        def original(): pass
        src = "def original():\n    reward_extra_keys = list(reward_extra_infos[-1].keys())\n"
        with patch.object(contract.inspect, "getsource", return_value=src):
            with self.assertRaises(ValueError): contract.local_patch(original)

    def test_patch_refuses_missing_second_assignment(self):
        def original(): pass
        src = "def original():\n    reward_extra_keys = list(reward_extra_infos[0].keys())\n"
        with patch.object(contract.inspect, "getsource", return_value=src):
            with self.assertRaises(ValueError): contract.local_patch(original)


class ArtifactProvenance(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.repo = self.root / "repo"
        self.repo.mkdir()
        self.raw = self.root / "raw"
        (self.raw / "run").mkdir(parents=True)
        (self.repo / "report.json").write_text('{"n":3,"ok":true}')
        (self.raw / "run/event.json").write_text('{"value":1}')
        self.index = {"schema": 1, "roots": {"repo": "reports", "runs": "raw"},
                      "files": [self.member("repo", self.repo, "report.json"),
                                self.member("runs", self.raw, "run/event.json")],
                      "run_sets": [{"root": "runs", "path": "run"}],
                      "report_checks": [{"root": "repo", "path": "report.json",
                                         "pointer": "/n", "expected": 3}]}
        self.roots = {"repo": self.repo, "runs": self.raw}

    def tearDown(self):
        self.tmp.cleanup()

    def member(self, label, root, name):
        p = root / name
        return {"root": label, "path": name, "bytes": p.stat().st_size,
                "sha256": artifacts.digest(p)}

    def test_inventory_survives_relocation(self):
        moved = self.root / "relocated"
        self.repo.rename(moved)
        self.raw.rename(self.root / "other-runs")
        got = artifacts.verify(self.index, {"repo": moved, "runs": self.root / "other-runs"})
        self.assertEqual(got["status"], "pass")
        self.assertEqual((got["files_checked"], got["reports_matched"]), (2, 1))

    def test_same_length_corruption_is_rejected(self):
        (self.raw / "run/event.json").write_text('{"value":2}')
        self.assertEqual(artifacts.verify(self.index, self.roots)["status"], "fail")

    def test_missing_root_is_partial_not_pass(self):
        got = artifacts.verify(self.index, {"repo": self.repo})
        self.assertEqual((got["status"], got["files_not_checked"]), ("partial", 1))
        self.assertEqual(got["missing_roots"], ["runs"])

    def test_missing_file_under_supplied_root_fails(self):
        (self.raw / "run/event.json").unlink()
        self.assertEqual(artifacts.verify(self.index, self.roots)["status"], "fail")

    def test_absolute_and_traversal_paths_are_rejected(self):
        for name in ["/etc/passwd", "../report.json", "run/../event.json", "C:/file", "run\\file"]:
            with self.subTest(name=name):
                bad = json.loads(json.dumps(self.index))
                bad["files"][1]["path"] = name
                self.assertEqual(artifacts.verify(bad, {"repo": self.repo})["status"], "fail")

    def test_external_symlink_is_rejected(self):
        target = self.root / "outside.json"
        target.write_bytes((self.raw / "run/event.json").read_bytes())
        (self.raw / "run/event.json").unlink()
        (self.raw / "run/event.json").symlink_to(target)
        self.assertEqual(artifacts.verify(self.index, self.roots)["status"], "fail")

    def test_duplicate_member_and_unindexed_run_file_fail(self):
        bad = json.loads(json.dumps(self.index))
        bad["files"].append(bad["files"][0])
        self.assertEqual(artifacts.verify(bad, self.roots)["status"], "fail")
        (self.raw / "run/extra.json").write_text('{}')
        self.assertEqual(artifacts.verify(self.index, self.roots)["status"], "fail")

    def test_rehashed_report_still_cannot_change_frozen_number(self):
        (self.repo / "report.json").write_text('{"n":4,"ok":true}')
        self.index["files"][0] = self.member("repo", self.repo, "report.json")
        self.assertEqual(artifacts.verify(self.index, self.roots)["status"], "fail")
        self.index["report_checks"][0].update(pointer="/ok", expected=1)
        self.assertEqual(artifacts.verify(self.index, self.roots)["status"], "fail")

    def test_pointer_escape_and_empty_inventory(self):
        self.assertEqual(artifacts.pointer({"a/b": {"~c": [5]}}, "/a~1b/~0c/0"), 5)
        bad = dict(self.index, files=[])
        self.assertEqual(artifacts.verify(bad, self.roots)["status"], "fail")

    def test_checker_preserves_original_bytes(self):
        before = {p: p.read_bytes() for p in [self.repo / "report.json", self.raw / "run/event.json"]}
        self.assertEqual(artifacts.verify(self.index, self.roots)["status"], "pass")
        self.assertEqual(before, {p: p.read_bytes() for p in before})


if __name__ == "__main__":
    unittest.main()
