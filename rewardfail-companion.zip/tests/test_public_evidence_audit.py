"""Unit tests for the read-only public-evidence parser (standard library only)."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location("public_audit", Path(__file__).resolve().parents[1] / "experiments/audit_public_evidence.py")
AUDIT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(AUDIT)


class PublicAuditTests(unittest.TestCase):
    def row(self, name="row", warm=False, score=0.0, categories=None):
        return {"id": name, "warm": warm, "score": score, "class": "normal",
                "wall": 1.0, "attempts": [{"outcome": "score",
                "steps": [["compare", 1.0, True, categories or [], 0]]}]}

    def run_rows(self, rows):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "rows.jsonl"
            path.write_text("".join(json.dumps(row) + "\n" for row in rows))
            return AUDIT.count_rows(path)

    def test_warmup_excluded(self):
        result = self.run_rows([self.row("warm", True), self.row()])
        self.assertEqual((result["n"], result["warmups_excluded"]), (1, 1))

    def test_event_with_score_one_is_retained(self):
        result = self.run_rows([self.row(score=1.0, categories=["Error:comparison"])])
        self.assertEqual((result["library_event_rows"], result["library_event_score_one"]), (1, 1))

    def test_multiple_events_count_one_row(self):
        result = self.run_rows([self.row(categories=["Error:test", "Timeout:test"])])
        self.assertEqual(result["library_event_rows"], 1)

    def test_duplicate_id_rejected(self):
        with self.assertRaisesRegex(ValueError, "duplicate"):
            self.run_rows([self.row(), self.row()])

    def test_outer_timeout_recorded(self):
        row = self.row(); row["attempts"][0]["outcome"] = "outer_timeout"
        self.assertEqual(self.run_rows([row])["outer_timeout_rows"], 1)

    def test_manifest_path_escape_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, "escapes"):
                AUDIT.member(Path(directory), "../outside")

    def test_malformed_json_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "rows.jsonl";path.write_text("not json\n")
            with self.assertRaises(ValueError): AUDIT.count_rows(path)


if __name__ == "__main__":
    unittest.main()
