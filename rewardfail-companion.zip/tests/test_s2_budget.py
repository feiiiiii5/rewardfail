"""本机预算终止归因的回归核对（方案第 18.3 节第 1 项；analyze.returned_at）。不调用判分器，逐行记录用最小的父侧、
子侧与保护日志拼出来，交给 analyze.summarize 合成。

同一个池子进程（第 1 代，pid 100）先后判几行，t=30 被整机保护杀掉；第 2 代（pid 101）接着重试：
- done：t=10 完整返回 1 分 → 修订后 1 分；修订前（实验仓 9a88991）记预算终止（复现主测量参照段的误记）；
- edge：t=29.5 返回，离终止不足 KILL_MARGIN → 仍记预算终止；
- active：t=20 开始，被杀时还在执行，父侧池损坏，第 2 次在新池得 1 分 → 预算终止；
- lost：子侧 t=12 已结束，父侧却收到池损坏（结果没送回）→ 预算终止；
- nowait：子侧 t=14 已结束，父侧缺等待结局（记录不全）→ 预算终止；
- mismatch：子侧结果 0、父侧得分 1（关联不上）→ 预算终止；
- later：第 2 代池里 t=40 完整返回，与被杀的 pid 100 无关 → 1 分；
- reuse：另一个测量进程 w1 的第 1 代池子进程恰好也叫 pid 100（编号复用），t=5 完整返回 → 1 分。
真实记录：Codex 审过的主测量脚本测试与自检运行目录（REAL）里每个含观测文件的目录，复制到临时目录，用两版各合成一遍，
类别要逐行相同（这些运行里被杀的子进程此前没有离终止 1 秒以上的完整返回，修订不该改变任何一行）；目录不在就跳过。
运行：.venv/bin/python -I tests/test_s2_budget.py（在实验仓根目录）
"""
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from rewardfail.s2 import analyze  # noqa: E402

OLD_COMMIT = "9a88991"  # 主测量执行的版本
RUNS = Path.home() / ".local/share/rewardfail/stage2/runs"
REAL = ("maintest-20261007-194344", "selftest-20261007-193925")
KILL_T = 30.0
BEGIN = {"inject": None, "limits": None, "mode": "observe"}
STEPS = [("gold_parse", ["2"]), ("pred_parse", ["2"]), ("compare", True)]


class Row:
    def __init__(self, req, worker="w0"):
        self.req, self.worker, self.parent, self.child, self.rseq = req, worker, [], [], 0

    def p(self, ev, t, **kw):
        self.parent.append(dict(kw, ev=ev, t=t, req=self.req, worker=self.worker, rseq=self.rseq))
        self.rseq += 1

    def attempt(self, att, gen, pid, t0, t1, outcome="score", score=1.0, child_res=1.0, child_end=True, wait=True):
        self.p("submit", t0, att=att, gen=gen)
        tseq = [0]

        def c(ev, t, **kw):
            self.child.append(dict(kw, ev=ev, t=t, req=self.req, att=att, gen=gen, worker=self.worker, pid=pid,
                                   tseq=tseq[0]))
            tseq[0] += 1
        c("task_start", t0, **BEGIN)
        steps = STEPS if child_end else STEPS[:1]
        for n, (kind, res) in enumerate(steps, 1):
            c("step_start", t0, step=n, kind=kind)
            if child_end:
                c("step_end", t0, step=n, kind=kind, wall=0.01, cpu=0.01, res=res, alarms=[])
        if child_end:
            c("task_end", t1 - 0.01, res=child_res, wall=0.03, cpu=0.03, alarms_total=0)
        if wait:
            kw = {"score": score} if outcome == "score" else {"exc": "BrokenProcessPool"}
            self.p("wait_end", t1, att=att, gen=gen, outcome=outcome, waited=t1 - t0, timeout=300, **kw)

    def done(self, score, attempts):
        n = self.rseq
        self.p("row_end", self.parent[-1]["t"], n=n)
        return {"id": self.req, "worker": self.worker, "score": score, "attempts": attempts, "mode": "observe"}


def build():
    rows, results = [], {}

    def row(req, worker="w0"):
        r = Row(req, worker)
        r.p("row_begin", 0.0, **BEGIN)
        rows.append(r)
        return r
    r = row("done"); r.attempt(1, 1, 100, 9.0, 10.0); results["done"] = r.done(1.0, 1)
    r = row("lost"); r.attempt(1, 1, 100, 11.0, 31.0, outcome="broken_pool"); r.attempt(2, 2, 101, 32.0, 33.0)
    results["lost"] = r.done(1.0, 2)
    r = row("nowait"); r.attempt(1, 1, 100, 13.0, 14.0, wait=False); results["nowait"] = r.done(1.0, 1)
    r = row("mismatch"); r.attempt(1, 1, 100, 15.0, 16.0, child_res=0.0); results["mismatch"] = r.done(1.0, 1)
    r = row("active"); r.attempt(1, 1, 100, 20.0, 31.0, outcome="broken_pool", child_end=False)
    r.attempt(2, 2, 101, 34.0, 35.0); results["active"] = r.done(1.0, 2)
    r = row("edge"); r.attempt(1, 1, 100, 29.0, 29.5); results["edge"] = r.done(1.0, 1)
    r = row("later"); r.attempt(1, 2, 101, 39.0, 40.0); results["later"] = r.done(1.0, 1)
    r = row("reuse", "w1"); r.attempt(1, 1, 100, 4.0, 5.0); results["reuse"] = r.done(1.0, 1)
    glob = [{"ev": "proc_new", "worker": "w0", "gen": 1, "pid": 100, "t": 0.0},
            {"ev": "proc_new", "worker": "w0", "gen": 2, "pid": 101, "t": 31.0},
            {"ev": "proc_exit", "worker": "w0", "pid": 100, "code": -9, "t": 30.1},
            {"ev": "proc_new", "worker": "w1", "gen": 1, "pid": 100, "t": 0.0},
            {"ev": "proc_exit", "worker": "w1", "pid": 100, "code": 0, "t": 6.0}]
    run = {"parent": glob + [e for r in rows for e in r.parent], "child": [e for r in rows for e in r.child],
           "guard": [{"ev": "budget_kill", "pid": 100, "fp": 4 << 30, "limit": 3 << 30, "t": KILL_T}],
           "results": results, "warms": [], "interrupts": {}, "file_problems": {"workers": {}, "pids": {}},
           "dup_results": set(), "strict": True}
    return run


EXPECT = {"done": "1 分", "edge": "本机预算终止（未裁定）", "active": "本机预算终止（未裁定）",
          "lost": "本机预算终止（未裁定）", "nowait": "本机预算终止（未裁定）", "mismatch": "本机预算终止（未裁定）",
          "later": "1 分", "reuse": "1 分"}
OLD_EXPECT_BUDGET = {"done", "edge", "active", "lost", "nowait", "mismatch", "reuse"}


def old_analyze():
    src = subprocess.run(["git", "-C", str(ROOT), "show", f"{OLD_COMMIT}:rewardfail/s2/analyze.py"], capture_output=True,
                         text=True, check=True).stdout
    d = Path(tempfile.mkdtemp())
    (d / "analyze_old.py").write_text(src, encoding="utf-8")
    spec = importlib.util.spec_from_file_location("analyze_old", d / "analyze_old.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    bad = []
    new = analyze.summarize(build())
    for req, want in EXPECT.items():
        got = new[req]["class"]
        ok = got == want
        print("通过" if ok else "未通过", "修订后", req, got, new[req]["problems"][:2])
        if not ok:
            bad.append(("修订后", req, want, got))
    if new["done"]["problems"] or new["later"]["problems"] or new["reuse"]["problems"]:
        bad.append(("完整返回的行应当没有一致性问题", new["done"]["problems"], new["later"]["problems"]))
    if not new["nowait"]["problems"]:
        bad.append(("nowait 缺等待结局，应有一致性问题", new["nowait"]["problems"]))
    old = old_analyze().summarize(build())
    for req in EXPECT:
        got = old[req]["class"] == "本机预算终止（未裁定）"
        ok = got == (req in OLD_EXPECT_BUDGET)
        print("通过" if ok else "未通过", f"修订前（{OLD_COMMIT}）", req, old[req]["class"])
        if not ok:
            bad.append(("修订前", req, old[req]["class"]))
    n = len(EXPECT) * 2 + 2
    mod = old_analyze()
    dirs = sorted({p.parent for name in REAL for p in (RUNS / name).rglob("obs-*.jsonl")})
    with tempfile.TemporaryDirectory() as tmp:
        for d in dirs:
            dst = Path(tmp) / "x"
            shutil.copytree(d, dst, ignore=shutil.ignore_patterns("rows.jsonl"))
            mod.summarize_stream(dst, dst / "old.jsonl")
            analyze.summarize_stream(dst, dst / "new.jsonl")
            o, w = ([json.loads(x)["class"] for x in open(dst / f, encoding="utf-8")] for f in ("old.jsonl", "new.jsonl"))
            if o != w:
                bad.append(("真实记录", str(d.relative_to(RUNS)), sum(a != b for a, b in zip(o, w))))
            shutil.rmtree(dst)
    print(f"真实记录：{len(dirs)} 个目录两版合成{'逐行相同' if not any(b[0] == '真实记录' for b in bad) else '有不同'}")
    n += len(dirs)
    print(f"{n} 项，失败 {len(bad)} 项")
    for b in bad:
        print("  失败：", b)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
