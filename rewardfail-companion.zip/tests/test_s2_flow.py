"""主测量跟进流程的替身测试（Codex 10-07 审核第 13.2 节第 2 项）：不调用判分器，各段的逐行记录由替身直接写出。

替身行（精简逐行记录，格式同 analyze.compact_row）：
- r-a：默认、参照、2 秒都是“正常 0”，10 秒是 1 分（时限 0/0/1），默认没有事件，靠随机 1% 进时限检查；
- r-b：三步各 4 秒、得 1 分，单行 12 秒，没有事件；2 秒时限下 0 分，10 秒下 1 分；
- 情景二另加：r-hog 每次都被本机预算终止且单行 15 秒；r-death 每次都池损坏、最终异常；r-outer 每次都外层超时；
  r-k 默认回答侧解析超时、参照 1 分（主指标翻转）。
对照两种流程：修订前（实验仓 42e4d63 的 s2_main.py 第 222–240 行原样照抄，报告函数取同一提交的 report.py）与修订后
（s2_main.followups）。核：修订后 r-a、r-b 都重放 3 次，r-b 是条件实验候选，时限两段在重放之前；预算终止的 r-hog
不因池损坏或耗时成为候选；修订前 r-a、r-b 都没重放、r-b 不是候选（复现审核里的反例）。
段间统计结束时保护要求停止（Codex 10-07 修订复核第 15.2 节）：seg 换成真的 StepGuard，“默认一遍·统计”这一块做完
之后（最后一个检查点之后）注入读不到内存压力、等后台线程观察到停止，再交给原来的 __exit__ 结束工作块。核：修订后
followups 抛 StepStop，参照段没被调用、没有别的段目录，默认段已写的文件逐个 sha256 不变；对照用修订前的
StepGuard（实验仓 99b086d），同一情景下记 ok、八段照常全跑（审核里的漏停）。这两项把系统内存压力读数固定为“正常”。
结果写 results/s2_d135/flow_check.json（申请季 D135 改保护后重跑；修订前与 10-07 第二次修订的结果留在 results/s2_rev1/、
results/s2_rev2/）。旧 StepGuard 记开始时的预算，D135 起没有预算，对照时给它一个 budget=None 的 Guard 子类。
"""
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments"))

import s2_main  # noqa: E402

from rewardfail.s2 import guard as guard_mod  # noqa: E402
from rewardfail.s2.stepguard import NoGuard, StepGuard, StepStop  # noqa: E402

OUT = ROOT / "results/s2_d135/flow_check.json"
OLD_COMMIT = "42e4d63"
OLD_GUARD_COMMIT = "99b086d"  # 第 15.2 节审核的版本
STOP_AT = "默认一遍·统计"
PASSES = ["default", "reference", "limit2s", "limit10s", "replay1", "replay2", "replay3", "retest"]
CHECKS = []
STEPS_OK = [["gold_parse", 0.05, True, [], 0], ["pred_parse", 0.05, True, [], 0], ["compare", 0.1, True, [], 0]]


def check(case, expect, actual, ok):
    CHECKS.append({"case": case, "expect": expect, "actual": actual, "pass": bool(ok)})
    print("通过" if ok else "未通过", case, "|", json.dumps(actual, ensure_ascii=False)[:240], flush=True)


def old_module(rel, name, commit=OLD_COMMIT):
    src = subprocess.run(["git", "-C", str(ROOT), "show", f"{commit}:{rel}"], capture_output=True, text=True,
                         check=True).stdout
    d = Path(tempfile.mkdtemp())
    (d / f"{name}.py").write_text(src, encoding="utf-8")
    spec = importlib.util.spec_from_file_location(name, d / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def row(i, cls="1 分", wall=0.3, steps=None, outcomes=("score",), budget=False):
    score = 1.0 if cls.startswith("1 分") else (0.0 if cls == "正常 0" or cls.startswith("0 分") else None)
    return {"id": i, "worker": "w", "class": cls, "score": score, "exc": None, "wall": wall, "undetermined": None,
            "problems": [], "flags": [], "resets": 0, "warm": False,
            "attempts": [{"att": k + 1, "gen": 1, "outcome": o, "waited": wall, "exit": None, "budget_killed": budget,
                          "fp_max": None, "steps": steps if steps is not None else STEPS_OK} for k, o in enumerate(outcomes)]}


SLOW3 = [["gold_parse", 4.0, True, [], 0], ["pred_parse", 4.0, True, [], 0], ["compare", 4.0, True, [], 0]]
TO_GOLD = [["gold_parse", 2.0, True, ["Timeout during parsing"], 1], ["pred_parse", 0.05, True, [], 0]]
TO_PRED = [["gold_parse", 0.05, True, [], 0], ["pred_parse", 5.0, True, ["Timeout during parsing"], 1]]


def script(extended):
    """{段: {编号: 行}}；没写到的行按平凡的 1 分。"""
    s = {p: {} for p in ("default", "reference", "limit2s", "limit10s", "replay1", "replay2", "replay3", "retest")}
    s["default"]["r-a"] = row("r-a", "正常 0")
    s["reference"]["r-a"] = row("r-a", "正常 0")
    s["limit2s"]["r-a"] = row("r-a", "正常 0")
    s["limit10s"]["r-a"] = row("r-a", "1 分")
    for p in ("default", "reference", "limit10s", "replay1", "replay2", "replay3"):
        s[p]["r-b"] = row("r-b", "1 分", 12.1, SLOW3)
    s["limit2s"]["r-b"] = row("r-b", "0 分：标准答案侧解析超时", 2.1, TO_GOLD)
    for p in ("replay1", "replay2", "replay3"):
        s[p]["r-a"] = row("r-a", "正常 0")
    if extended:
        for p in ("default", "reference", "replay1", "replay2", "replay3"):
            s[p]["r-hog"] = row("r-hog", "本机预算终止（未裁定）", 15.0, [], ("broken_pool", "broken_pool"), budget=True)
            s[p]["r-death"] = row("r-death", "最终异常（BrokenProcessPool）", 3.0, [], ("broken_pool", "broken_pool"))
            s[p]["r-outer"] = row("r-outer", "0 分：外层超时", 30.2, [], ("outer_timeout",))
        for p in ("default", "replay1", "replay2", "replay3"):
            s[p]["r-k"] = row("r-k", "0 分：回答侧解析超时", 5.1, TO_PRED)
        s["reference"]["r-k"] = row("r-k", "1 分", 9.0, TO_PRED[:1] + [["pred_parse", 9.0, True, [], 0]] + STEPS_OK[2:])
        s["limit2s"]["r-k"] = row("r-k", "0 分：回答侧解析超时", 2.1, TO_PRED)
        s["limit10s"]["r-k"] = row("r-k", "1 分", 9.0)
    return s


def stand_in(base, sc):
    calls = []

    def run(name, tasks, mode, extra):
        d = base / name
        d.mkdir(parents=True, exist_ok=True)
        rows = [sc[name].get(t["id"]) or row(t["id"]) for t in tasks]
        (d / "rows.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows), encoding="utf-8")
        calls.append((name, [t["id"] for t in tasks], mode, list(extra)))
        return {"pass": name, "tasks": len(tasks)}
    return run, calls


def old_flow(base, ids, by_id, draws, run, rep_mod):
    """修订前 s2_main.py（42e4d63）main() 里跟进部分的原样逻辑，只把 run_pass 换成替身。"""
    scan = s2_main.scan
    passes = {"default": run("default", [by_id[i] for i in ids], "observe", [])}
    tally = rep_mod.DefaultTally()
    for r in scan(base / "default"):
        tally.add(r)
    dcls = tally.cls
    refone_order = sorted(ids, key=lambda i: draws[i][2])
    ones = [i for i in refone_order if rep_mod.default_verdict(dcls.get(i)) == 1][:s2_main.REF_ONES]
    ones_set = set(ones)
    ref_ids = [i for i in ids if rep_mod.default_verdict(dcls.get(i)) != 1 or i in ones_set]
    passes["reference"] = run("reference", [by_id[i] for i in ref_ids], "reference", [])
    rcls, rev = {}, {}
    for r in scan(base / "reference"):
        rcls[r["id"]] = r["class"]
        if rep_mod.is_event(r):
            rev[r["id"]] = r
    metric, k_ids, u_ids = rep_mod.main_metric(ids, dcls, rcls)
    k_set = set(k_ids)
    ev_ids = [i for i in ids if rep_mod.is_event(tally.keep.get(i)) or i in rev or i in k_set]
    for j in (1, 2, 3):
        passes[f"replay{j}"] = run(f"replay{j}", [by_id[i] for i in ev_ids], "observe", [])
    rand_lim = {i for i in ids if draws[i][1]}
    lim_ids = [i for i in ids if (i in tally.keep and rep_mod.is_limit_row(tally.keep[i])) or i in rand_lim]
    passes["limit2s"] = run("limit2s", [by_id[i] for i in lim_ids], "observe", ["--limits", "2"])
    passes["limit10s"] = run("limit10s", [by_id[i] for i in lim_ids], "observe", ["--limits", "10"])
    reps = [{r["id"]: r for r in scan(base / f"replay{j}")} for j in (1, 2, 3)]
    cands = rep_mod.candidates(ev_ids, tally.keep, reps)
    lim = rep_mod.limits_table(lim_ids, s2_main.classes(base / "limit2s"), dcls, s2_main.classes(base / "limit10s"))
    return {"rep_ids": ev_ids, "candidates": cands, "limits": lim, "metric": metric}


def setup(extended):
    ids = [f"r-clean-{k:02d}" for k in range(1, 21)] + ["r-a", "r-b"]
    if extended:
        ids += ["r-hog", "r-death", "r-outer", "r-k"]
    by_id = {i: {"id": i} for i in ids}
    draws = {i: (i == "r-clean-01", i == "r-a", n) for n, i in enumerate(ids)}
    return ids, by_id, draws


def run_case(extended, rep_old):
    label = "情景二（加预算终止、池损坏、外层超时、主指标翻转）" if extended else "情景一（审核里的两行）"
    ids, by_id, draws = setup(extended)
    sc = script(extended)
    with tempfile.TemporaryDirectory() as t1, tempfile.TemporaryDirectory() as t2:
        run_new, calls_new = stand_in(Path(t1), sc)
        new = s2_main.followups(Path(t1), ids, by_id, draws, run_new, NoGuard)
        run_old, calls_old = stand_in(Path(t2), sc)
        old = old_flow(Path(t2), ids, by_id, draws, run_old, rep_old)
    order_new = [c[0] for c in calls_new]
    reps_new = [c[1] for c in calls_new if c[0].startswith("replay")]
    reps_old = [c[1] for c in calls_old if c[0].startswith("replay")]
    cand_new = {c["id"]: c for c in new["candidates"]}
    cand_old = {c["id"]: c for c in old["candidates"]}
    check(f"{label}：修订后段的顺序", "默认 → 参照 → 2 秒 → 10 秒 → 重放 ×3 → 重测", order_new,
          order_new == ["default", "reference", "limit2s", "limit10s", "replay1", "replay2", "replay3", "retest"])
    check(f"{label}：修订后 r-a、r-b 各重放 3 次", "三段重放的行相同，都含 r-a（时限 0/0/1）与 r-b（三步各 4 秒、12 秒）",
          {"replay_rows": reps_new[0] if reps_new else None, "why": new["replay_why"],
           "limits_pattern": new["limits"]["pattern_2s_5s_10s"]},
          len(reps_new) == 3 and reps_new[0] == reps_new[1] == reps_new[2] and {"r-a", "r-b"} <= set(reps_new[0]))
    check(f"{label}：修订后 r-b 是条件实验候选（单行超过 10 秒），r-a 不是", "r-b 的 wall_over_10s 为真；r-a 不在候选里",
          {"candidates": new["candidates"]},
          cand_new.get("r-b", {}).get("wall_over_10s") is True and "r-a" not in cand_new)
    check(f"{label}：修订前的流程漏掉两行（复现审核里的反例）", "修订前 r-a、r-b 都没重放，r-b 不是候选",
          {"old_replay_rows": reps_old[0] if reps_old else [], "old_candidates": sorted(cand_old)},
          not ({"r-a", "r-b"} & set(reps_old[0] if reps_old else [])) and "r-b" not in cand_old)
    if extended:
        check(f"{label}：预算终止不作候选，自然池损坏与外层超时照常", "r-hog 不在候选；r-death 池损坏每次都发生；"
              "r-outer 外层超时每次都发生；r-k 在重放里",
              {"candidates": new["candidates"], "replay_rows": reps_new[0]},
              "r-hog" not in cand_new and cand_new.get("r-death", {}).get("pool_broken_every_time") is True
              and cand_new.get("r-outer", {}).get("outer_timeout_every_time") is True and "r-k" in reps_new[0]
              and new["metric"]["k"] == 1)
        check(f"{label}：与修订前的差别照报", "修订前 r-hog 因默认 15 秒被列为候选（预算终止那几次的耗时现在不算）",
              {"old_candidates": sorted(cand_old), "new_candidates": sorted(cand_new)},
              "r-hog" in cand_old and "r-hog" not in cand_new)


def old_stepguard():
    mod = old_module("rewardfail/s2/stepguard.py", "stepguard_old", OLD_GUARD_COMMIT)

    class Compat(guard_mod.Guard):
        budget = None  # 旧 StepGuard 开始时记预算；D135 起没有预算
    mod.Guard = Compat
    return mod


def late_stop_cls(base_cls):
    """STOP_AT 那一块做完之后注入读不到内存压力，等后台线程观察到停止，再交给 base_cls 原来的 __exit__。"""
    class LateStop(base_cls):
        observed = None

        def __exit__(self, et, ev, tb):
            if self.label == STOP_AT and et is None:
                orig = self.g.sample
                self.g.sample = lambda wp: dict(orig(wp), pressure=None,
                                                read_fail=["回归测试：统计块最后一个检查点之后读不到内存压力"])
                t_end = time.time() + 5
                while self.state != "stop" and time.time() < t_end:
                    time.sleep(0.01)
                self.observed = self.state == "stop"
            return super().__exit__(et, ev, tb)
    return LateStop


def files_sha(d):
    return {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(Path(d).iterdir()) if f.is_file()}


def stop_case(base_cls):
    """情景二的行，seg 用 base_cls 的 StepGuard，在 STOP_AT 结束时要求停止。"""
    ids, by_id, draws = setup(True)
    sc = script(True)
    cls = late_stop_cls(base_cls)
    with tempfile.TemporaryDirectory() as t:
        base = Path(t)
        run, calls = stand_in(base, sc)
        written, made = {}, []

        def run_snap(name, tasks, mode, extra):
            out = run(name, tasks, mode, extra)
            written[name] = files_sha(base / name)
            return out

        def seg(label):
            made.append(cls(base / "guard-steps.jsonl", label, poll=0.05, grace=5))
            return made[-1]
        raised, continued = None, False
        try:
            s2_main.followups(base, ids, by_id, draws, run_snap, seg)
            continued = True
        except Exception as e:
            raised = e
        after = {name: files_sha(base / name) for name in written}
        dirs = sorted(p.name for p in base.iterdir() if p.is_dir())
        steps = [json.loads(x) for x in (base / "guard-steps.jsonl").read_text(encoding="utf-8").splitlines() if x.strip()]
    end = [x for x in steps if x["ev"] == "step_end" and x["label"] == STOP_AT]
    return {"raised": None if raised is None else f"{type(raised).__name__}：{raised}"[:200], "exc": raised,
            "continued": continued, "calls": [c[0] for c in calls], "dirs": dirs,
            "observed": [sg.observed for sg in made if sg.label == STOP_AT],
            "completed_unchanged": after == written, "written": sorted(written),
            "stop_block_end": [{k: x.get(k) for k in ("outcome", "stop_at_exit")} for x in end]}


def run_stop_cases():
    real = guard_mod.pressure
    guard_mod.pressure = lambda: 1
    try:
        new = stop_case(StepGuard)
        old = stop_case(old_stepguard().StepGuard)
    finally:
        guard_mod.pressure = real
    show = lambda r: {k: v for k, v in r.items() if k != "exc"}  # noqa: E731
    check(f"段间统计结束时要求停止（“{STOP_AT}”最后一个检查点之后）：下一段不执行，已完成段的记录不变",
          "followups 抛 StepStop；替身判分只调用过 default；只有 default 目录；default 已写的文件 sha256 不变；"
          "这一块的结束记录 outcome=stopped、stop_at_exit",
          show(new),
          new["observed"] == [True] and isinstance(new["exc"], StepStop) and not new["continued"]
          and new["calls"] == ["default"] and new["dirs"] == ["default"] and new["completed_unchanged"]
          and new["stop_block_end"] == [{"outcome": "stopped", "stop_at_exit": True}])
    check(f"对照：修订前的 StepGuard（{OLD_GUARD_COMMIT}）同一情景下漏停", "观察到停止却记 ok，八段照常全跑（审核里的反例）",
          show(old),
          old["observed"] == [True] and old["exc"] is None and old["continued"] and old["calls"] == PASSES
          and old["stop_block_end"] == [{"outcome": "ok", "stop_at_exit": None}])


def main():
    rep_old = old_module("rewardfail/s2/report.py", "report_old")
    run_case(False, rep_old)
    run_case(True, rep_old)
    run_stop_cases()
    n_fail = sum(not c["pass"] for c in CHECKS)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({"what": "跟进流程替身测试（不调用判分器）", "old": f"实验仓 {OLD_COMMIT}",
                               "old_stepguard": f"实验仓 {OLD_GUARD_COMMIT}", "checks": CHECKS,
                               "n_checks": len(CHECKS), "n_fail": n_fail}, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(CHECKS)} 项，失败 {n_fail} 项；写 {OUT}")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
