"""主测量脚本在真实入口上的续跑核对（Codex 10-07 审核第 13.2 节第 5 项“相同版本可续跑、执行版本/参数变化拒绝”）。

给一个已跑完的主测量脚本测试运行目录（--run-dir；不给就先跑一遍测试：试跑集 300 行加 5 条注入行），然后：
1. 同样的参数、同一个运行目录再跑：应当退出码 0，各段都复用 pass_done（reused），报告标 resumed；
2. 改 --child-limit-mib：应当拒绝（预先抽取与参数里的 child_limit_mib 不同），不动原记录；
3. 把运行目录复制一份，改副本 run.json 锁里记的 sympy 版本（模拟依赖换了）：应当拒绝，列出 versions / sympy；
4. 再复制一份，删掉其中一段的 pass_spec.json（模拟修订前留下的段）：应当拒绝。
10-07 晚按 Codex 修订复核第 15 节加：
5. 第 2、3 步的拒绝原因记在 guard-steps.jsonl 里“核对版本锁”这一环节的结束记录（outcome=error，error 列出不同项）；
6. 再复制一份，删掉其中的 retest 段与 report.json（模拟跑到一半）；用真实入口 main() 续跑，只把 StepGuard 换成一个子类：
   “构建任务与生成版本锁”这一块做完之后注入读不到内存压力、等后台线程观察到停止，再交给原来的 __exit__。应当退出码 7，
   没有核对版本锁（run.json 不变）、没有派发 retest、没有写报告，副本里原有的文件逐个 sha256 不变（资源保护日志照常追加）；
7. 同一副本不注入、照常续跑：退出码 0，只重跑 retest，其余七段复用，各表与第一次相同。
测试不传 --out 时主测量脚本默认写 results/s2_rev1/main_test/report.json；这里一律传 --out，写到 results/s2_d135/main_test/
（10-08 整机保护按申请季 D135 改后重跑；之前的结果留在 results/s2_rev1/、results/s2_rev2/），不覆盖之前的报告。
结果写 results/s2_d135/main_test/resume_e2e.json。--child-limit-mib 只给测试制造确定的终止路径（测量不设）。
会读试跑集数据、哈希十个数据分片。
"""
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable
MAIN = ROOT / "experiments/s2_main.py"
ARGS = ["--source", "pilot", "--n", "300", "--synthetic", "--child-limit-mib", "768", "--P", "2"]
R2 = ROOT / "results/s2_d135/main_test"
OUT = R2 / "resume_e2e.json"
CHECKS = []
STOP_AT = "构建任务与生成版本锁"
TABLES = ("main_metric", "default_classes", "reference_classes", "replay_set", "concurrency_candidates", "limits", "retest",
          "decision", "synthetic_check")
# 真实入口 main()，只把 StepGuard 换成在 STOP_AT 结束前注入停止的子类（第 6 步）
STOP_ENTRY = f"""import sys, time
sys.path.insert(0, {str(ROOT)!r})
sys.path.insert(0, {str(ROOT / "experiments")!r})
import s2_main


class LateStop(s2_main.StepGuard):
    def __exit__(self, et, ev, tb):
        if self.label == {STOP_AT!r} and et is None:
            orig = self.g.sample
            self.g.sample = lambda wp: dict(orig(wp), pressure=None, read_fail=["回归测试：工作块最后一个检查点之后读不到内存压力"])
            t_end = time.time() + 10
            while self.state != "stop" and time.time() < t_end:
                time.sleep(0.01)
            print("注入后后台线程观察到停止：", self.state == "stop", flush=True)
        return super().__exit__(et, ev, tb)


s2_main.StepGuard = LateStop
sys.argv = ["s2_main.py", *sys.argv[1:]]
s2_main.main()
"""


def check(case, expect, actual, ok):
    CHECKS.append({"case": case, "expect": expect, "actual": actual, "pass": bool(ok)})
    print("通过" if ok else "未通过", case, "|", json.dumps(actual, ensure_ascii=False)[:300], flush=True)


def run(args, timeout=3600, entry=None):
    t0 = time.time()
    cmd = [PY, "-I", "-c", entry] if entry else [PY, "-I", str(MAIN)]
    p = subprocess.run([*cmd, *args], capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout + p.stderr, round(time.time() - t0, 1)


def steps(d):
    return [json.loads(x) for x in (Path(d) / "guard-steps.jsonl").read_text(encoding="utf-8").splitlines() if x.strip()]


def last_end(d):
    ends = [e for e in steps(d) if e["ev"] == "step_end"]
    return {k: ends[-1].get(k) for k in ("label", "outcome", "stop_at_exit", "error")} if ends else {}


def tree_sha(d, skip=("guard-steps.jsonl",)):
    return {str(f.relative_to(d)): hashlib.sha256(f.read_bytes()).hexdigest()
            for f in sorted(Path(d).rglob("*")) if f.is_file() and f.name not in skip}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir")
    a = ap.parse_args()
    if a.run_dir:
        base = Path(a.run_dir)
    else:
        code, out, secs = run([*ARGS, "--out", str(R2 / "report.json")])
        m = re.search(r"运行目录 (\S+)；", out)
        check("先跑一遍主测量脚本测试", "退出码 0（合成行核对通过）", {"code": code, "seconds": secs, "tail": out[-400:]}, code == 0 and m)
        if not m:
            sys.exit(1)
        base = Path(m.group(1))
    first = json.loads((base / "report.json").read_text(encoding="utf-8"))

    code, out, secs = run([*ARGS, "--run-dir", str(base), "--out", str(R2 / "report_resume.json")])
    rep = json.loads((R2 / "report_resume.json").read_text(encoding="utf-8")) if code == 0 else {}
    reused = {k: v.get("reused") for k, v in (rep.get("passes") or {}).items()}
    same = {k: rep.get(k) == first.get(k) for k in TABLES}
    check("同版本同参数续跑：各段复用、结论相同", "退出码 0；八段都 reused；resumed 为真；判定与各表与第一次相同",
          {"code": code, "seconds": secs, "reused": reused, "resumed": rep.get("resumed"), "same": same},
          code == 0 and len(reused) == 8 and all(reused.values()) and rep.get("resumed") is True and all(same.values()))

    before = sorted(p.name for p in base.iterdir())
    code, out, secs = run([*ARGS[:-4], "--child-limit-mib", "1024", "--P", "2", "--run-dir", str(base)])
    check("参数变了（单子进程上限 768 → 1024 MiB）：拒绝", "退出码非 0；提示执行版本与第一次运行不同、列出 child_limit_mib；运行目录里没有新增文件（资源保护日志照常追加）",
          {"code": code, "msg": out.strip().splitlines()[-3:]},
          code != 0 and "执行版本与第一次运行不同" in out and "child_limit_mib" in out
          and sorted(p.name for p in base.iterdir()) == before)
    end_limit = last_end(base)

    c1 = base.parent / (base.name + "-locktest-deps")
    shutil.copytree(base, c1)
    rj = json.loads((c1 / "run.json").read_text(encoding="utf-8"))
    rj["lock"]["versions"]["sympy"] = rj["lock"]["versions"]["sympy"] + "-模拟旧版"
    (c1 / "run.json").write_text(json.dumps(rj, ensure_ascii=False, indent=1), encoding="utf-8")
    code, out, secs = run([*ARGS, "--run-dir", str(c1)])
    check("依赖版本变了（副本里改锁记的 sympy 版本）：拒绝", "退出码非 0；列出 versions / sympy",
          {"code": code, "msg": out.strip().splitlines()[-3:]}, code != 0 and "versions / sympy" in out)
    end_deps = last_end(c1)

    c2 = base.parent / (base.name + "-locktest-spec")
    shutil.copytree(base, c2)
    (c2 / "limit2s" / "pass_spec.json").unlink()
    code, out, secs = run([*ARGS, "--run-dir", str(c2)])
    check("某段缺 pass_spec.json（修订前留下的段）：拒绝", "退出码非 0；提示 limit2s 段确认不了参数",
          {"code": code, "msg": out.strip().splitlines()[-3:]}, code != 0 and "limit2s" in out and "pass_spec" in out)

    short = lambda e: dict(e, error=(e.get("error") or "")[:200])  # noqa: E731
    check("拒绝原因记在“核对版本锁”的结束记录里", "两次拒绝的运行，guard-steps.jsonl 最后一条结束记录都是“核对版本锁”、"
          "outcome=error，error 里分别有 child_limit_mib 与 versions / sympy；前一块“构建任务与生成版本锁”记 ok",
          {"参数变了": short(end_limit), "依赖版本变了": short(end_deps)},
          end_limit.get("label") == end_deps.get("label") == "核对版本锁"
          and end_limit.get("outcome") == end_deps.get("outcome") == "error"
          and "child_limit_mib" in (end_limit.get("error") or "") and "versions / sympy" in (end_deps.get("error") or ""))

    c3 = base.parent / (base.name + "-stoptest")
    shutil.copytree(base, c3)
    shutil.rmtree(c3 / "retest")
    (c3 / "report.json").unlink()
    snap = tree_sha(c3)
    n_steps = len(steps(c3))
    code, out, secs = run([*ARGS, "--run-dir", str(c3)], entry=STOP_ENTRY)
    new_steps = steps(c3)[n_steps:]
    labels = [e["label"] for e in new_steps if e["ev"] == "step_begin"]
    end_stop = [e for e in new_steps if e["ev"] == "step_end" and e["label"] == STOP_AT]
    after = tree_sha(c3)
    check(f"真实入口：“{STOP_AT}”最后一个检查点之后要求停止、工作块结束",
          "退出码 7；后台线程观察到停止；这一块结束记录 outcome=stopped、stop_at_exit；之后没有开始任何环节（没有核对版本锁）；"
          "没有 retest 目录、没有 report.json；副本里原有文件逐个 sha256 不变（run.json 不变，说明没走到核对版本锁）",
          {"code": code, "seconds": secs, "msg": out.strip().splitlines()[-2:], "new_step_labels": labels,
           "stop_block_end": [{k: e.get(k) for k in ("outcome", "stop_at_exit")} for e in end_stop],
           "retest_exists": (c3 / "retest").exists(), "report_exists": (c3 / "report.json").exists(),
           "files_unchanged": after == snap, "n_files": len(snap)},
          code == 7 and "注入后后台线程观察到停止： True" in out and labels == [STOP_AT]
          and [{k: e.get(k) for k in ("outcome", "stop_at_exit")} for e in end_stop] == [{"outcome": "stopped", "stop_at_exit": True}]
          and not (c3 / "retest").exists() and not (c3 / "report.json").exists() and after == snap)

    code, out, secs = run([*ARGS, "--run-dir", str(c3), "--out", str(R2 / "report_stop_resume.json")])
    rep3 = json.loads((R2 / "report_stop_resume.json").read_text(encoding="utf-8")) if code == 0 else {}
    reused3 = {k: v.get("reused") for k, v in (rep3.get("passes") or {}).items()}
    same3 = {k: rep3.get(k) == first.get(k) for k in TABLES}
    check("停下后照常续跑：只重跑 retest，其余七段复用，各表与第一次相同",
          "退出码 0；resumed 为真；retest 重跑，其余七段 reused；判定与各表与第一次相同",
          {"code": code, "seconds": secs, "reused": reused3, "resumed": rep3.get("resumed"), "same": same3},
          code == 0 and rep3.get("resumed") is True and not reused3.get("retest")
          and all(reused3.get(k) for k in reused3 if k != "retest") and len(reused3) == 8 and all(same3.values()))

    n_fail = sum(not c["pass"] for c in CHECKS)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({"what": "主测量脚本在真实入口上的续跑核对", "run_dir": str(base), "copies": [str(c1), str(c2), str(c3)],
                               "checks": CHECKS, "n_checks": len(CHECKS), "n_fail": n_fail}, ensure_ascii=False, indent=1),
                   encoding="utf-8")
    print(f"{len(CHECKS)} 项，失败 {n_fail} 项；写 {OUT}")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
