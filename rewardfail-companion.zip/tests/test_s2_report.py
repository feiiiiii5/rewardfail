"""第二阶段判定规则的单元测试：类别到裁定的映射、主指标记账、门槛算术（与方案第 5 节、plan/stage2_thresholds.py 对照）。

运行：.venv/bin/python -I tests/test_s2_report.py（在实验仓根目录）
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rewardfail.s2 import report as R  # noqa: E402

DEFAULT = [("1 分", 1), ("1 分（重试后）", 1), ("1 分，有库超时日志", 1), ("正常 0", 0), ("0 分：回答侧解析超时", 0),
           ("0 分：外层超时", 0), ("0 分：标准答案侧解析出错", 0), ("最终异常（BrokenProcessPool）", None),
           ("本机预算终止（未裁定）", None), ("观测不完整（未裁定）", None), ("未裁定（中断两次）", None), ("没有结果", None),
           (None, None)]
REF = [("1 分", 1), ("1 分，有库超时日志", 1), ("正常 0", 0), ("0 分：回答侧解析出错", 0), ("0 分：比较超时", None),
       ("0 分：外层超时", None), ("0 分：库超时异常（壳层）", None), ("0 分：回答侧解析出错、比较超时", None),
       ("最终异常（BrokenProcessPool）", None), ("本机预算终止（未裁定）", None), (None, None)]


def main():
    bad = [(c, v, R.default_verdict(c)) for c, v in DEFAULT if R.default_verdict(c) != v]
    bad += [(c, v, R.ref_verdict(c)) for c, v in REF if R.ref_verdict(c) != v]
    ids = ["a", "b", "c", "d", "e", "f", "g"]
    dcls = {"a": "1 分", "b": "正常 0", "c": "0 分：回答侧解析超时", "d": "最终异常（BrokenProcessPool）",
            "e": "0 分：比较超时", "f": "正常 0"}  # g 默认没有记录
    rcls = {"b": "正常 0", "c": "1 分", "d": "1 分", "e": "0 分：比较超时"}  # f 参照缺失
    m, k, u = R.main_metric(ids, dcls, rcls)
    if (m["n"], k, sorted(u)) != (7, ["c"], ["d", "e", "f", "g"]):
        bad.append(("main_metric", m, k, u))
    thr = (R.lower(111, 93733) >= 1e-3 > R.lower(110, 93733), R.upper(4, 93733) < 1e-4 <= R.upper(5, 93733))
    if thr != (True, True):
        bad.append(("thresholds", thr))
    if abs(R.upper(0, 40000, 0.025) - 9.221773403618501e-05) > 1e-12:  # 与 plan/stage2_thresholds.py 同一对照值
        bad.append(("zero-event upper", R.upper(0, 40000, 0.025)))
    print(f"{len(DEFAULT) + len(REF) + 3} 项，失败 {len(bad)} 项")
    for b in bad:
        print("  失败：", b)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
