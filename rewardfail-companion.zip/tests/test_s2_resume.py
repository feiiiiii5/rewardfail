"""续跑版本核对的单元测试（Codex 10-07 审核第 13.2 节第 5 项）：相同版本可续跑；执行代码、被测源码、依赖、数据、
预先抽取、段参数有任何变化都拒绝；只改注释或文档字符串的代码，登记兼容记录且语法树相同才放行。

在临时目录里造一个假的仓根（几份代码文件）和一份锁，直接调 s2_main.check_lock / check_spec，不跑判分器、不读数据。
真实入口上的续跑与拒绝另见 results/s2_rev2/main_test/resume_e2e.json（主测量脚本测试之后跑）。
结果写 results/s2_rev2/resume_check.json（10-07 晚第 15 节修订后重跑；修订前的结果留在 results/s2_rev1/）。
"""
import copy
import hashlib
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments"))

import s2_main  # noqa: E402

OUT = ROOT / "results/s2_rev2/resume_check.json"
CHECKS = []
SRC = '''"""模块说明。"""


def f(x):
    """函数说明。"""
    # 一条注释
    return x + 1
'''


def check(case, expect, actual, ok):
    CHECKS.append({"case": case, "expect": expect, "actual": actual, "pass": bool(ok)})
    print("通过" if ok else "未通过", case, "|", json.dumps(actual, ensure_ascii=False)[:200], flush=True)


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def refused(fn):
    try:
        fn()
    except SystemExit as e:
        return str(e)
    return None


def fresh():
    """(假仓根, 运行目录, 锁)。"""
    root, base = Path(tempfile.mkdtemp()), Path(tempfile.mkdtemp())
    (root / "rewardfail/s2").mkdir(parents=True)
    (root / "rewardfail/s2/a.py").write_text(SRC, encoding="utf-8")
    (root / "rewardfail/s2/b.py").write_text("X = 1\n", encoding="utf-8")
    lock = {"pre": {"source": "pilot", "n": 305, "ids_sha256": "aa", "child_limit_mib": 768},
            "code_sha256": {"rewardfail/s2/a.py": sha(root / "rewardfail/s2/a.py"), "rewardfail/s2/b.py": sha(root / "rewardfail/s2/b.py")},
            "tested_source": {"verl_dir": "/x/verl", "verl_head": "0c4c3d4", "verl_dirty": [], "wrapper_sha256": "w1"},
            "python": "3.12.0", "versions": {"sympy": "1.13.1", "math-verify": "0.9.0"},
            "data": {"sample_map_sha256": "m1", "shards_sha256": {"train-00000-of-00010.parquet": "s0"}}}
    s2_main.check_lock(base, lock, root=root)
    return root, base, lock


def edit_file(root, lock, rel, new_src):
    (root / rel).write_text(new_src, encoding="utf-8")
    new = copy.deepcopy(lock)
    new["code_sha256"][rel] = sha(root / rel)
    return new


def compat(base, lock, new, rel, note="只改注释，已核语法树"):
    (base / "compat.json").write_text(json.dumps({"files": {rel: {"old": lock["code_sha256"][rel], "new": new["code_sha256"][rel],
                                                                   "note": note}}}, ensure_ascii=False), encoding="utf-8")


def main():
    root, base, lock = fresh()
    snap = sorted(str(p.relative_to(base)) for p in (base / "code").rglob("*.py"))
    check("第一次运行写锁和代码快照", "run.json 里有 lock；code/ 下有两份代码", snap,
          (base / "run.json").exists() and snap == ["code/rewardfail/s2/a.py", "code/rewardfail/s2/b.py"])
    r = s2_main.check_lock(base, lock, root=root)
    check("相同版本可续跑", "返回 (True, [])，run.json 记一次续跑", r,
          r == (True, []) and len(json.loads((base / "run.json").read_text())["resumes"]) == 1)
    for path, val in ((("pre", "n"), 306), (("pre", "child_limit_mib"), 3072), (("tested_source", "verl_head"), "deadbee"),
                      (("tested_source", "verl_dirty"), [" M verl/x.py"]), (("tested_source", "wrapper_sha256"), "w2"),
                      (("python",), "3.12.1"), (("versions", "sympy"), "1.14.0"), (("data", "sample_map_sha256"), "m2"),
                      (("data", "shards_sha256", "train-00000-of-00010.parquet"), "s1")):
        new = copy.deepcopy(lock)
        d = new
        for k in path[:-1]:
            d = d[k]
        d[path[-1]] = val
        msg = refused(lambda: s2_main.check_lock(base, new, root=root))
        check(f"{' / '.join(path)} 变了就拒绝", "SystemExit，列出这一项", msg, msg and " / ".join(path) in msg)
    rel = "rewardfail/s2/a.py"
    new = edit_file(root, lock, rel, SRC.replace("return x + 1", "return x + 2"))
    msg = refused(lambda: s2_main.check_lock(base, new, root=root))
    check("执行代码变了、没有兼容记录：拒绝", "SystemExit", msg, msg and rel in msg)
    compat(base, lock, new, rel, "谎称只改注释")
    msg = refused(lambda: s2_main.check_lock(base, new, root=root))
    check("执行代码变了、登记成只改注释：仍拒绝（语法树不同）", "SystemExit，说是执行变化", msg, msg and "语法树" in msg)
    (base / "compat.json").unlink()
    new = edit_file(root, lock, rel, SRC.replace("# 一条注释", "# 改过的注释").replace("函数说明。", "改过的函数说明。"))
    msg = refused(lambda: s2_main.check_lock(base, new, root=root))
    check("只改注释和文档字符串、没有兼容记录：拒绝", "SystemExit，要求登记", msg, msg and "compat.json" in msg)
    compat(base, lock, new, rel)
    r = refused(lambda: s2_main.check_lock(base, new, root=root))
    res = s2_main.check_lock(base, new, root=root) if r is None else None
    check("只改注释和文档字符串、登记了兼容记录：放行", "返回 (True, [该文件])，记进 run.json 的 resumes",
          {"refused": r, "result": res}, r is None and res and res[0] and [x["file"] for x in res[1]] == [rel])
    compat(base, lock, new, rel, "")
    msg = refused(lambda: s2_main.check_lock(base, new, root=root))
    check("兼容记录没有审查说明：拒绝", "SystemExit", msg, bool(msg))
    (base / "compat.json").unlink()
    edit_file(root, lock, rel, SRC)
    new = copy.deepcopy(lock)
    new["code_sha256"]["rewardfail/s2/c.py"] = "c1"
    msg = refused(lambda: s2_main.check_lock(base, new, root=root))
    check("多了一个代码文件：拒绝", "SystemExit", msg, msg and "c.py" in msg)
    legacy = Path(tempfile.mkdtemp())
    (legacy / "run.json").write_text(json.dumps({"pre": lock["pre"]}), encoding="utf-8")
    msg = refused(lambda: s2_main.check_lock(legacy, lock, root=root))
    check("修订前的运行目录（没有锁）：拒绝", "SystemExit", msg, msg and "没有版本锁" in msg)

    tasks = [{"id": f"t{k}"} for k in range(5)]
    d = Path(tempfile.mkdtemp()) / "limit2s"
    spec = s2_main.pass_spec("limit2s", tasks, "observe", ["--limits", "2"], 768 << 20)
    s2_main.check_spec(d, spec)
    check("段参数：第一次写 pass_spec.json", "文件存在且与 spec 相同", None,
          json.loads((d / "pass_spec.json").read_text()) == spec)
    msg = refused(lambda: s2_main.check_spec(d, spec))
    check("段参数相同：可续跑、可复用 pass_done", "不拒绝", msg, msg is None)
    for name, other in (("时限参数", s2_main.pass_spec("limit2s", tasks, "observe", ["--limits", "10"], 768 << 20)),
                        ("行集合", s2_main.pass_spec("limit2s", tasks[:4], "observe", ["--limits", "2"], 768 << 20)),
                        ("模式", s2_main.pass_spec("limit2s", tasks, "reference", ["--limits", "2"], 768 << 20)),
                        ("单子进程上限", s2_main.pass_spec("limit2s", tasks, "observe", ["--limits", "2"], 3072 << 20))):
        msg = refused(lambda: s2_main.check_spec(d, other))
        check(f"段参数的{name}变了：拒绝", "SystemExit，列出不同的项", msg, bool(msg))
    d2 = Path(tempfile.mkdtemp()) / "default"
    d2.mkdir()
    (d2 / "pass_done.json").write_text("{}", encoding="utf-8")
    msg = refused(lambda: s2_main.check_spec(d2, spec))
    check("段目录已有记录却没有 pass_spec.json：拒绝", "SystemExit", msg, msg and "pass_spec" in msg)
    n_fail = sum(not c["pass"] for c in CHECKS)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({"what": "续跑版本核对的单元测试", "checks": CHECKS, "n_checks": len(CHECKS), "n_fail": n_fail},
                              ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(CHECKS)} 项，失败 {n_fail} 项；写 {OUT}")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
