"""第二阶段统计计算的独立核对（Codex 10-07 审核第 13.2 节第 3 项）。

report.py 的 Clopper–Pearson 界改用正则化不完全贝塔函数（连分式）。这里用另一种算法核它：二项概率在对数里逐项求和
（只加相对最大项 e^-80 以上的项），同样二分反演；关键点再用 mpmath 50 位精度直接求和，核界上的尾概率等于 α。
覆盖零事件、门槛附近、中等与高比例、全事件，以及题型大小不同的 n；界必须包含点估计、随 k 单调。
旧算法（从 (1−p)^n 起逐项连乘）原样留在这里作对照：小 k 时与新算法一致（预先写定的门槛不变），k=1,000 时下溢。
结果写 results/s2_rev1/stats_check.json。不需要网络或新装的包（mpmath 随 sympy 已装）。
"""
import json
import math
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import mpmath  # noqa: E402

from rewardfail.s2 import report as R  # noqa: E402

OUT = ROOT / "results/s2_rev1/stats_check.json"
NS = [5, 100, 1_003, 2_000, 29_956, 46_860, 46_873, 93_733]
KS = [0, 1, 2, 3, 4, 5, 10, 110, 111, 500, 1_000, 5_000]


def oracle_cdf(k, n, p):
    """P(X ≤ k)：对数逐项求和。"""
    if k < 0:
        return 0.0
    if k >= n or p <= 0:
        return 1.0
    if p >= 1:
        return 0.0
    lp, lq, c = math.log(p), math.log1p(-p), math.lgamma(n + 1)

    def lpmf(j):
        return c - math.lgamma(j + 1) - math.lgamma(n - j + 1) + j * lp + (n - j) * lq

    top = min(k, max(0, min(n, int((n + 1) * p))))  # 0..k 里最大的一项
    m = lpmf(top)
    w = int(14 * math.sqrt(n * p * (1 - p)) + 60)
    lo, hi = max(0, top - w), min(k, top + w)
    return min(1.0, math.fsum(math.exp(lpmf(j) - m) for j in range(lo, hi + 1)) * math.exp(m))


def bisect(f, it=64):
    lo, hi = 0.0, 1.0
    for _ in range(it):
        mid = (lo + hi) / 2
        if f(mid):
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def o_lower(k, n, a):
    return 0.0 if k <= 0 else bisect(lambda p: 1 - oracle_cdf(k - 1, n, p) < a)


def o_upper(k, n, a):
    return 1.0 if k >= n else bisect(lambda p: oracle_cdf(k, n, p) > a)


def old_cdf(k, n, p):
    """改之前 report.py 的算法（原样）。"""
    if k < 0:
        return 0.0
    if p <= 0:
        return 1.0
    if p >= 1:
        return 0.0 if k < n else 1.0
    term = math.exp(n * math.log1p(-p))
    terms = [term]
    for j in range(1, k + 1):
        term *= ((n - j + 1) / j) * (p / (1 - p))
        terms.append(term)
    return min(1.0, math.fsum(terms))


def old_lower(k, n, a=0.05):
    return 0.0 if k <= 0 else R._bisect(lambda p: 1 - old_cdf(k - 1, n, p) < a)


def old_upper(k, n, a=0.05):
    return 1.0 if k >= n else R._bisect(lambda p: old_cdf(k, n, p) > a)


def mp_tail_ge(k, n, p):
    """mpmath 50 位：P(X ≥ k) = 1 − Σ_{j<k} C(n,j) p^j (1−p)^(n−j)，在有效窗口内求和。"""
    mpmath.mp.dps = 50
    p = mpmath.mpf(p)
    q = 1 - p
    mode = int((n + 1) * float(p))
    w = int(20 * math.sqrt(n * float(p) * float(1 - p)) + 80)
    lo, hi = max(0, min(k - 1, mode) - w), min(k - 1, mode + w)
    s = mpmath.fsum(mpmath.binomial(n, j) * p ** j * q ** (n - j) for j in range(lo, hi + 1))
    return 1 - s


def main():
    t0 = time.time()
    checks, grid = [], []

    def check(name, ok, detail):
        checks.append({"case": name, "pass": bool(ok), "detail": detail})
        print("通过" if ok else "未通过", name, json.dumps(detail, ensure_ascii=False)[:200], flush=True)

    worst = {"rel": 0.0, "at": None}
    for n in NS:
        ks = sorted({k for k in KS + [n // 3, n // 2, n - 1, n] if 0 <= k <= n})
        prev = None
        for k in ks:
            row: dict = {"n": n, "k": k}
            for a, tag in ((0.05, "one_sided_95"), (0.025, "two_sided_95_end")):
                lo, up = R.lower(k, n, a), R.upper(k, n, a)
                olo, oup = o_lower(k, n, a), o_upper(k, n, a)
                for mine, ref, side in ((lo, olo, "lower"), (up, oup, "upper")):
                    rel = abs(mine - ref) / max(ref, 1e-300) if ref else abs(mine)
                    if rel > worst["rel"]:
                        worst = {"rel": rel, "at": [n, k, a, side, mine, ref]}
                row[tag] = [lo, up]
                row[tag + "_oracle"] = [olo, oup]
                row[tag + "_contains_point"] = lo <= k / n <= up
            grid.append(row)
            if prev is not None:
                row["monotone"] = (prev["one_sided_95"][0] < row["one_sided_95"][0]
                                   and prev["one_sided_95"][1] < row["one_sided_95"][1])
            prev = row
    check("新算法与独立的对数逐项求和一致", worst["rel"] < 1e-8, {"最大相对差": worst})
    check("每个 (n, k) 的单侧与双侧界都包含点估计", all(r["one_sided_95_contains_point"] and r["two_sided_95_end_contains_point"]
                                             for r in grid), {"cases": len(grid)})
    check("同一 n 下界、上界都随 k 严格增", all(r.get("monotone", True) for r in grid),
          [(r["n"], r["k"]) for r in grid if r.get("monotone") is False])
    a = 0.05
    closed = []
    for n in NS:
        closed.append({"n": n, "upper_k0": R.upper(0, n), "closed_upper_k0": 1 - a ** (1 / n),
                       "lower_kn": R.lower(n, n), "closed_lower_kn": a ** (1 / n)})
    check("零事件与全事件对上闭式解", all(abs(c["upper_k0"] - c["closed_upper_k0"]) <= 1e-12 * c["closed_upper_k0"] + 1e-15
                                    and abs(c["lower_kn"] - c["closed_lower_kn"]) <= 1e-12 for c in closed), closed)
    lo, up = R.lower(1000, 93_733), R.upper(1000, 93_733)
    check("Codex 给的独立值：n=93,733、k=1,000", abs(lo - 0.01012254) < 5e-9 and abs(up - 0.01123725) < 5e-9,
          {"lower": lo, "upper": up, "codex": [0.01012254, 0.01123725], "point": 1000 / 93_733})
    olo, oup = old_lower(1000, 93_733), old_upper(1000, 93_733)
    check("旧算法在 k=1,000 时下溢（复现审核里的错误）", abs(olo - oup) < 1e-12 and olo < 1000 / 93_733,
          {"old_lower": olo, "old_upper": oup})
    small = []
    for k in (0, 1, 3, 4, 5, 10, 110, 111):
        small.append({"k": k, "old": [old_lower(k, 93_733), old_upper(k, 93_733)], "new": [R.lower(k, 93_733), R.upper(k, 93_733)]})
    # 新算法的系数用 lgamma 之差算，n 很大时相对误差约 1e-10；门槛离判定线至少有 0.4% 的余量，这个量级不影响任何判定
    check("小 k 时新旧算法一致到 1e-9（预先写定的门槛不受影响）",
          all(abs(s["old"][i] - s["new"][i]) <= 1e-9 * max(s["new"][i], 1e-300) for s in small for i in (0, 1)), small)
    check("门槛：下界到千分之一要 k ≥ 111，上界低于万分之一要 k+u ≤ 4（n=93,733）",
          R.lower(111, 93_733) >= 1e-3 > R.lower(110, 93_733) and R.upper(4, 93_733) < 1e-4 <= R.upper(5, 93_733),
          {"lower_110_111": [R.lower(110, 93_733), R.lower(111, 93_733)], "upper_4_5": [R.upper(4, 93_733), R.upper(5, 93_733)]})
    spots = []
    for n, k in ((93_733, 1_000), (93_733, 111), (93_733, 46_866), (46_873, 5_000), (1_003, 3)):
        lo, up = R.lower(k, n), R.upper(k, n)
        t_lo = float(mp_tail_ge(k, n, lo))  # 下界处 P(X ≥ k) 应等于 α
        t_up = float(1 - mp_tail_ge(k + 1, n, up))  # 上界处 P(X ≤ k) 应等于 α
        spots.append({"n": n, "k": k, "P(X>=k | lower)": t_lo, "P(X<=k | upper)": t_up})
    check("mpmath 50 位核界上的尾概率等于 0.05", all(abs(s["P(X>=k | lower)"] - a) < 1e-9 and abs(s["P(X<=k | upper)"] - a) < 1e-9
                                             for s in spots), spots)
    n_fail = sum(not c["pass"] for c in checks)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({"what": "第二阶段统计计算的独立核对（Codex 审核第 13.2 节第 3 项）", "checks": checks,
                               "grid": grid, "seconds": round(time.time() - t0, 1), "n_checks": len(checks), "n_fail": n_fail},
                              ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(checks)} 项，失败 {n_fail} 项；{round(time.time() - t0, 1)} 秒；写 {OUT}")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
