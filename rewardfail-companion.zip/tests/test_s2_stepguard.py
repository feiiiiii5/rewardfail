"""准备与分析环节资源保护的控制测试（Codex 10-07 审核第 13.2 节第 4 项；10-08 整机保护按申请季 D135 改：只看内存压力
是否变红）。不做耗尽整机的测试：
1. 正常：没有保护条件，环节照常完成，记开始、状态、结束；
2. 读不到内存压力（替换采样结果）：下一个检查点抛 StepStop；
3. 内存压力变红（替换压力读数为 4，hard_after=2）：先暂停，连续 2 秒仍红就停止，抛 StepStop；
4. 黄色加真实分配（压力读数固定为 2，本进程再写满 256 MiB）：不暂停、不停止，环节照常完成（D135）；
5. 暂停后恢复：变红约 3 秒后解除 → 主线程在检查点等，不红连续 2 秒后继续，环节正常完成；
6. 主线程卡住：另起一个进程，读数失败后主线程一直不走检查点 → 后台线程在宽限 2 秒后直接结束进程（退出码 6）。
工作块结束的处理（Codex 10-07 修订复核第 15.2 节；第 1–6 项原样保留）：
7. 最后一个检查点之后监控观察到停止、宽限之前工作块结束：with 语句抛 StepStop，块后代码（代表下一阶段）不执行，
   结束记录 outcome=stopped、stop_at_exit；块内已写好的文件不变；没有 step_kill；
8. 工作块结束时后台线程正在查（注入的采样慢 0.3 秒、返回读数失败）：结束时状态还是正常，等线程退出后重读，照样抛
   StepStop，step_stop 记在 step_end 之前；
9. 停止待处理时块内自己抛 ValueError：传出的是原来那个 ValueError，不换成 StepStop；结束记录 outcome=error，
   带异常摘要和 pending_stop；
10. 结束时处于暂停（变红约 1.5 秒）：在结束处等，条件连续 1 秒解除后正常结束；
11. 结束时处于暂停且一直不解除（hard_after=1）：在结束处升级为停止，抛 StepStop；
12. 在结束处等暂停时被打断（另一个线程用 _thread.interrupt_main 模拟 Ctrl-C）：照样收尾，结束记录 outcome=error，
    抛出的是那个 KeyboardInterrupt，后台线程已结束；
13. 对照：修订前的 StepGuard（实验仓 99b086d，从 git 原样取出）在第 7、8 项的情景下都记 ok、继续执行——复现审核
    里的漏停，说明第 7、8 项能区分修订前后。
第 7–13 项读不到内存压力靠替换采样结果注入，不判分、不做大分配。第 13 项的旧 StepGuard 配新的 Guard（补一个 budget 属性给它记）。
除第 3–5、10–12 项专门替换压力读数外，其余各项把系统内存压力读数固定为“正常”，免得本机当时的压力混进结果；
可用内存、交换区和 footprint 都是真实读数。
结果写 results/s2_d135/stepguard_check.json（10-07 两次修订的结果留在 results/s2_rev1/、results/s2_rev2/）；各项的保护记录在
~/.local/share/rewardfail/stage2/runs/stepguard-时间/。
"""
import _thread
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from rewardfail.s2 import guard as guard_mod, mem  # noqa: E402
from rewardfail.s2.stepguard import EXIT_STUCK, StepGuard, StepStop, write_atomic  # noqa: E402

MiB = 1 << 20
OUT = ROOT / "results/s2_d135/stepguard_check.json"
OLD_COMMIT = "99b086d"  # 第 15.2 节审核的版本
BASE = Path.home() / ".local/share/rewardfail/stage2/runs" / f"stepguard-{time.strftime('%Y%m%d-%H%M%S')}"
CHECKS = []


def check(case, expect, actual, ok):
    CHECKS.append({"case": case, "expect": expect, "actual": actual, "pass": bool(ok)})
    print("通过" if ok else "未通过", case, "|", json.dumps(actual, ensure_ascii=False)[:240], flush=True)


def evs(path):
    return [json.loads(x) for x in Path(path).read_text(encoding="utf-8").splitlines() if x.strip()]


def loop(sg, seconds, work=None):
    """模拟一个环节：每 0.1 秒走一次检查点。"""
    t0 = time.time()
    while time.time() - t0 < seconds:
        if work:
            work()
        sg.tick()
        time.sleep(0.1)


def segment(log, label, seconds, work=None, setup=None, **kw):
    """跑一个受保护的环节；StepStop 在 with 外面接住，环节结束记录才记 outcome=stopped。返回 (结局, 用时, StepGuard)。"""
    t0 = time.time()
    sg = StepGuard(log, label, **kw)
    if setup:
        setup(sg)
    try:
        with sg:
            loop(sg, seconds, work)
    except StepStop as e:
        return f"StepStop：{e}", round(time.time() - t0, 1), sg
    return "完成", round(time.time() - t0, 1), sg


def fake_read_fail(sg):
    orig = sg.g.sample
    sg.g.sample = lambda wp: dict(orig(wp), pressure=None, read_fail=["模拟：内存压力读不到"])


def old_stepguard():
    """修订前的 stepguard.py（OLD_COMMIT），从 git 原样取出。"""
    src = subprocess.run(["git", "-C", str(ROOT), "show", f"{OLD_COMMIT}:rewardfail/s2/stepguard.py"],
                         capture_output=True, text=True, check=True).stdout
    d = Path(tempfile.mkdtemp())
    (d / "stepguard_old.py").write_text(src, encoding="utf-8")
    spec = importlib.util.spec_from_file_location("stepguard_old", d / "stepguard_old.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    class Compat(guard_mod.Guard):
        budget = None  # 旧 StepGuard 开始时记预算；D135 起没有预算
    mod.Guard = Compat
    return mod


def wait_state(sg, want, seconds=3.0):
    t_end = time.time() + seconds
    while sg.state != want and time.time() < t_end:
        time.sleep(0.005)
    return sg.state == want


def stop_after_last_tick(sg):
    """最后一个检查点之后注入监控读数失败，等后台线程观察到停止；不再走检查点。"""
    orig = sg.g.sample
    sg.g.sample = lambda wp: dict(orig(wp), pressure=None, read_fail=["回归测试：最后一个检查点之后读不到内存压力"])
    return wait_state(sg, "stop")


def block(cls, log, label, body, **kw):
    """跑一个工作块，异常在 with 外面接住；块后一行代表“进入下一阶段”。"""
    sg = cls(log, label, **kw)
    t0 = time.time()
    raised, continued = None, False
    try:
        with sg:
            body(sg)
        continued = True
    except Exception as e:
        raised = e
    return {"raised": raised, "continued": continued, "seconds": round(time.time() - t0, 2), "sg": sg}


def brief(r):
    e = r["raised"]
    return {"raised": None if e is None else f"{type(e).__name__}：{e}"[:160], "continued": r["continued"],
            "seconds": r["seconds"]}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def case_late(cls, log, done_file):
    """第 7 项情景：块内先过检查点、写好一份记录，再等监控观察到停止，然后工作块结束。"""
    info = {}

    def body(sg):
        sg.tick()
        write_atomic(done_file, "已完成的记录\n")
        info["sha_written"] = sha(done_file)
        info["observed_stop"] = stop_after_last_tick(sg)
        info["state_at_block_end"] = sg.state
    r = block(cls, log, "最后检查点后停止", body, poll=0.05, grace=5)
    r.update(info, sha_after=sha(done_file))
    return r


def case_exit_race(cls, log):
    """第 8 项情景：后台线程正在采样（慢 0.3 秒、返回读数失败）时工作块结束。"""
    info, entered = {}, threading.Event()

    def body(sg):
        sg.tick()
        orig = sg.g.sample

        def slow(wp):
            entered.set()
            time.sleep(0.3)
            return dict(orig(wp), pressure=None, read_fail=["回归测试：工作块结束时后台线程正在查，读不到内存压力"])
        sg.g.sample = slow
        info["sampling"] = entered.wait(3)
        info["state_at_block_end"] = sg.state
    r = block(cls, log, "结束时线程正在查", body, poll=0.05, grace=5)
    r.update(info)
    return r


def exit_events(log):
    e = evs(log)
    return [x["ev"] + (f"({x['outcome']})" if x["ev"] == "step_end" else "") for x in e
            if x["ev"] in ("pause", "resume", "hard_stop", "step_stop", "step_kill", "step_end")], e


def main():
    BASE.mkdir(parents=True)
    real_pressure = guard_mod.pressure
    guard_mod.pressure = lambda: 1
    # 1 正常
    log = BASE / "1-normal.jsonl"
    out = segment(log, "正常", 3, status_every=1)[:2]
    e = evs(log)
    check("正常环节照常完成", "完成；记 step_begin、状态、step_end（outcome=ok）；没有暂停",
          {"out": out, "events": [x["ev"] for x in e][:8]},
          out[0] == "完成" and e[1]["ev"] == "step_begin" and e[-1]["ev"] == "step_end" and e[-1]["outcome"] == "ok"
          and any(x["ev"] == "status" for x in e) and not any(x["ev"] == "pause" for x in e))

    # 2 读不到内存压力
    log = BASE / "2-read-fail.jsonl"
    out = segment(log, "读数失败", 10, setup=fake_read_fail)[:2]
    e = evs(log)
    check("读不到内存压力就停止", "几秒内抛 StepStop；记 hard_stop（监控读数失败）与 step_end（outcome=stopped）",
          {"out": out, "hard_stop": [x["reasons"] for x in e if x["ev"] == "hard_stop"], "end": e[-1].get("outcome")},
          out[0].startswith("StepStop") and (out[1] or 0) < 4 and any("监控读数失败" in r for x in e if x["ev"] == "hard_stop"
                                                                     for r in x["reasons"]) and e[-1]["outcome"] == "stopped")

    # 3 变红
    log = BASE / "3-red.jsonl"
    guard_mod.pressure = lambda: 4
    out = segment(log, "变红", 10, hard_after=2, status_every=1)[:2]
    guard_mod.pressure = lambda: 1
    e = evs(log)
    check("内存压力变红：先暂停，持续 2 秒仍红就停止", "pause（内存压力严重（红））→ hard_stop（内存压力连续 2 秒严重）；"
          "几秒内抛 StepStop；step_end（outcome=stopped）",
          {"out": out, "pause": [x["reasons"] for x in e if x["ev"] == "pause"],
           "hard_stop": [x["reasons"] for x in e if x["ev"] == "hard_stop"], "end": e[-1].get("outcome")},
          out[0].startswith("StepStop") and 2 <= (out[1] or 0) < 5 and e[-1]["outcome"] == "stopped"
          and any(x["ev"] == "pause" and x["reasons"] == ["内存压力严重（红）"] for x in e)
          and any(x["ev"] == "hard_stop" and x["reasons"] == ["内存压力连续 2 秒严重"] for x in e))

    # 4 黄色加真实分配：照常
    log = BASE / "4-yellow-and-alloc.jsonl"
    hog = []

    def grab():
        if not hog:
            hog.append(bytearray(b"\x01") * (256 * MiB))  # 每页都写过

    guard_mod.pressure = lambda: 2
    out, took, sg = segment(log, "黄色加分配", 4, grab, status_every=1)
    guard_mod.pressure = lambda: 1
    peak, own = sg.g.peak_total, mem.usage()[0]
    hog.clear()
    e = evs(log)
    check("黄色、本进程多写 256 MiB：不暂停、不停止（D135）", "环节完成；没有 pause、hard_stop；状态记录里压力是 2、footprint 照记",
          {"out": out, "seconds": took, "peak_MiB": peak >> 20, "own_after_MiB": own >> 20,
           "events": sorted({x["ev"] for x in e}), "pressures": sorted({x.get("pressure") for x in e if x["ev"] == "status"})},
          out == "完成" and not any(x["ev"] in ("pause", "hard_stop") for x in e)
          and {x.get("pressure") for x in e if x["ev"] == "status"} == {2} and peak >= 256 * MiB)

    # 5 暂停后恢复
    log = BASE / "5-pause-resume.jsonl"
    t_end = time.time() + 3
    guard_mod.pressure = lambda: 4 if time.time() < t_end else 1
    out, took, sg = segment(log, "暂停后恢复", 4, resume_after=2, hard_after=30, status_every=1)
    out, waited = (out, took), sg.waited
    guard_mod.pressure = real_pressure
    e = evs(log)
    check("变红时停在检查点，回落后继续", "记 pause（内存压力严重（红））与 resume；主线程在检查点等了 ≥ 2 秒；环节正常完成",
          {"out": out, "waited_s": round(waited, 1), "events": [x["ev"] for x in e if x["ev"] in ("pause", "resume", "hard_stop")]},
          out[0] == "完成" and waited >= 2 and any(x["ev"] == "pause" and "内存压力严重（红）" in x["reasons"] for x in e)
          and any(x["ev"] == "resume" for x in e) and not any(x["ev"] == "hard_stop" for x in e))

    # 6 主线程卡住
    log = BASE / "6-stuck.jsonl"
    code = (f"import sys, time; sys.path.insert(0, {str(ROOT)!r})\n"
            "from rewardfail.s2 import guard\n"
            "guard.pressure = lambda: 1\n"
            "from rewardfail.s2.stepguard import StepGuard\n"
            f"sg = StepGuard({str(log)!r}, '主线程卡住', grace=2, poll=0.5)\n"
            "orig = sg.g.sample\n"
            "sg.g.sample = lambda wp: dict(orig(wp), pressure=None, read_fail=['模拟：内存压力读不到'])\n"
            "with sg:\n"
            "    time.sleep(30)\n"
            "print('不该走到这里')\n")
    t0 = time.time()
    p = subprocess.run([sys.executable, "-I", "-c", code], capture_output=True, text=True, timeout=60)
    took = round(time.time() - t0, 1)
    e = evs(log)
    check("主线程不走检查点：宽限后直接结束进程", f"退出码 {EXIT_STUCK}；10 秒内；记 step_kill；没有打印“不该走到这里”",
          {"code": p.returncode, "seconds": took, "events": [x["ev"] for x in e if x["ev"] in ("hard_stop", "step_stop", "step_kill")],
           "stdout": p.stdout[-200:]},
          p.returncode == EXIT_STUCK and took < 10 and any(x["ev"] == "step_kill" for x in e) and "不该" not in p.stdout)

    # ---- 工作块结束的处理（第 15.2 节）----
    guard_mod.pressure = lambda: 1
    # 7 最后检查点后停止、宽限前工作块结束
    log = BASE / "7-stop-after-last-tick.jsonl"
    r = case_late(StepGuard, log, BASE / "7-done.txt")
    seq, e = exit_events(log)
    end = e[-1]
    check("最后一个检查点之后观察到停止、宽限前工作块结束：抛 StepStop，不进入下一阶段",
          "with 语句抛 StepStop；块后代码没执行；事件 pause → hard_stop → step_stop → step_end(stopped)，stop_at_exit；"
          "没有 step_kill；块内写好的文件不变；用时小于宽限 5 秒",
          dict(brief(r), observed_stop=r["observed_stop"], state_at_block_end=r["state_at_block_end"], events=seq,
               stop_at_exit=end.get("stop_at_exit"), file_unchanged=r["sha_after"] == r["sha_written"]),
          r["observed_stop"] and isinstance(r["raised"], StepStop) and not r["continued"]
          and seq == ["pause", "hard_stop", "step_stop", "step_end(stopped)"] and end.get("stop_at_exit") is True
          and r["sha_after"] == r["sha_written"] and r["seconds"] < 5)

    # 8 工作块结束时后台线程正在查
    log = BASE / "8-stop-during-exit.jsonl"
    r = case_exit_race(StepGuard, log)
    seq, e = exit_events(log)
    end = e[-1]
    check("工作块结束时后台线程正在查：等线程退出后重读，查到的停止照样抛",
          "块结束时状态还是 run；with 语句抛 StepStop；块后代码没执行；step_stop 在 step_end(stopped) 之前，stop_at_exit",
          dict(brief(r), sampling=r["sampling"], state_at_block_end=r["state_at_block_end"], events=seq,
               stop_at_exit=end.get("stop_at_exit")),
          r["sampling"] and r["state_at_block_end"] == "run" and isinstance(r["raised"], StepStop) and not r["continued"]
          and seq[-2:] == ["step_stop", "step_end(stopped)"] and end.get("stop_at_exit") is True)

    # 9 已有异常时保留原异常
    log = BASE / "9-own-error-with-pending-stop.jsonl"
    err, info = ValueError("回归测试：环节自身出错"), {}

    def body9(sg):
        sg.tick()
        info["observed_stop"] = stop_after_last_tick(sg)
        raise err
    r = block(StepGuard, log, "已有异常", body9, poll=0.05, grace=5)
    seq, e = exit_events(log)
    end = e[-1]
    check("停止待处理时块内自己出错：传出原来的异常，不换成 StepStop",
          "接住的就是块内抛的那个 ValueError；step_end outcome=error，带 error 摘要与 pending_stop；没有 step_kill",
          dict(brief(r), observed_stop=info.get("observed_stop"), same_object=r["raised"] is err, events=seq,
               error=end.get("error"), pending_stop=end.get("pending_stop")),
          info.get("observed_stop") and r["raised"] is err and not r["continued"] and end["outcome"] == "error"
          and "ValueError" in (end.get("error") or "") and end.get("pending_stop") and "step_kill" not in seq)

    # 10 结束时处于暂停：等解除后正常结束
    log = BASE / "10-pause-at-exit-resume.jsonl"
    info = {}

    def body10(sg):
        sg.tick()
        t_clear = time.time() + 1.5
        guard_mod.pressure = lambda: 4 if time.time() < t_clear else 1
        info["paused"] = wait_state(sg, "pause")
    r = block(StepGuard, log, "结束时暂停后解除", body10, poll=0.1, resume_after=1, hard_after=30, status_every=1)
    guard_mod.pressure = lambda: 1
    seq, e = exit_events(log)
    check("工作块结束时处于暂停：在结束处等，条件解除后正常结束",
          "块结束时是 pause；不抛异常、块后代码执行；事件 pause → resume → step_end(ok)；waited_s ≥ 1；没有 hard_stop",
          dict(brief(r), paused=info.get("paused"), waited_s=round(r["sg"].waited, 2), events=seq),
          info.get("paused") and r["raised"] is None and r["continued"] and seq == ["pause", "resume", "step_end(ok)"]
          and r["sg"].waited >= 1)

    # 11 结束时处于暂停且不解除：升级为停止
    log = BASE / "11-pause-at-exit-escalate.jsonl"
    info = {}

    def body11(sg):
        sg.tick()
        guard_mod.pressure = lambda: 4
        info["paused"] = wait_state(sg, "pause")
    r = block(StepGuard, log, "结束时暂停后升级", body11, poll=0.1, resume_after=30, hard_after=1, status_every=1)
    guard_mod.pressure = lambda: 1
    seq, e = exit_events(log)
    end = e[-1]
    check("工作块结束时处于暂停且条件不解除：在结束处升级为停止，抛 StepStop",
          "块结束时是 pause；with 语句抛 StepStop；hard_stop 原因是“内存压力连续 1 秒严重”；step_end(stopped)，stop_at_exit",
          dict(brief(r), paused=info.get("paused"), events=seq,
               hard_stop=[x["reasons"] for x in e if x["ev"] == "hard_stop"], stop_at_exit=end.get("stop_at_exit")),
          info.get("paused") and isinstance(r["raised"], StepStop) and not r["continued"]
          and any(x["ev"] == "hard_stop" and x["reasons"] == ["内存压力连续 1 秒严重"] for x in e)
          and seq[-1] == "step_end(stopped)" and end.get("stop_at_exit") is True and r["seconds"] < 5)

    # 12 在结束处等暂停时被打断
    log = BASE / "12-interrupt-while-waiting-at-exit.jsonl"
    info = {}
    sg = StepGuard(log, "结束处等暂停时被打断", poll=0.1, resume_after=30, hard_after=30, status_every=1)
    t0, raised, continued = time.time(), None, False
    try:
        with sg:
            sg.tick()
            guard_mod.pressure = lambda: 4
            info["paused"] = wait_state(sg, "pause")
            threading.Timer(0.5, _thread.interrupt_main).start()
        continued = True
    except BaseException as e:  # 这里要接住 KeyboardInterrupt
        raised = e
    took = round(time.time() - t0, 2)
    guard_mod.pressure = lambda: 1
    seq, e = exit_events(log)
    end = e[-1]
    check("在结束处等暂停时被打断（模拟 Ctrl-C）：照样收尾、记下，抛出原来的 KeyboardInterrupt",
          "块结束时是 pause；接住的是 KeyboardInterrupt；块后代码没执行；step_end outcome=error、error 含 KeyboardInterrupt；"
          "后台线程已结束；几秒内结束",
          {"paused": info.get("paused"), "raised": None if raised is None else type(raised).__name__, "continued": continued,
           "seconds": took, "events": seq, "error": end.get("error"), "thread_alive": sg.th.is_alive()},
          info.get("paused") and isinstance(raised, KeyboardInterrupt) and not continued and end["ev"] == "step_end"
          and end["outcome"] == "error" and "KeyboardInterrupt" in (end.get("error") or "") and not sg.th.is_alive()
          and took < 5)

    # 13 对照：修订前的代码在第 7、8 项情景下漏停
    old = old_stepguard()
    log_a, log_b = BASE / "12a-old-stop-after-last-tick.jsonl", BASE / "12b-old-stop-during-exit.jsonl"
    ra = case_late(old.StepGuard, log_a, BASE / "12a-done.txt")
    rb = case_exit_race(old.StepGuard, log_b)
    seq_a, _ = exit_events(log_a)
    seq_b, _ = exit_events(log_b)
    check(f"对照：修订前的 StepGuard（{OLD_COMMIT}）在第 7、8 项情景下都漏停",
          "两个情景都观察到停止，却不抛异常、块后代码照常执行，step_end 记 ok（即审核里的反例）",
          {"7": dict(brief(ra), observed_stop=ra["observed_stop"], events=seq_a),
           "8": dict(brief(rb), sampling=rb["sampling"], events=seq_b)},
          ra["observed_stop"] and ra["raised"] is None and ra["continued"] and seq_a[-2:] == ["step_stop", "step_end(ok)"]
          and rb["sampling"] and rb["raised"] is None and rb["continued"] and seq_b[-2:] == ["step_stop", "step_end(ok)"])
    guard_mod.pressure = real_pressure

    n_fail = sum(not c["pass"] for c in CHECKS)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({"what": "准备与分析环节资源保护的控制测试（含工作块结束的处理）", "logs": str(BASE),
                               "old_code_for_control": f"实验仓 {OLD_COMMIT}:rewardfail/s2/stepguard.py", "checks": CHECKS,
                               "n_checks": len(CHECKS), "n_fail": n_fail}, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(CHECKS)} 项，失败 {n_fail} 项；写 {OUT}")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
