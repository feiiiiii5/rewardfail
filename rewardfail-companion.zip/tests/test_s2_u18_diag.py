"""补充诊断脚本（experiments/s2_u18_diag.py，申请季方案第 19.2 节）的机制测试：只用合成输入，不碰主测量的 19 行。

把脚本写定的编号、次数与门限换成测试值（改模块属性），再走一遍 main：
- D3：k 行换成“回答写成 4/2、每次符号比较在库的计时之内慢 6 秒”的注入行，重复 3 次。默认设置（库内 5 秒）应全部比较超时记 0；
  参照设置（60 秒）应全部 1 分，比较墙钟约 6 秒。
- D1：三条，footprint 门限换成 1 GiB、墙钟门限 8 秒。x-hog 占 1,200 MiB，应按 footprint 杀掉，杀之前写一次调用栈；
  x-slow 比较慢 30 秒，应按墙钟杀掉，调用栈里有注入的 slow_eq；x-ok 正常，应自己结束，结果为 1。
- D2：时限换成 2 秒（外层 10 秒）。x-one 1 分，x-timeout（回答写成 4/2、比较慢 4 秒）比较超时，x-zero 回答错记正常 0；
  k₃₀₀ = 1 + 1，u₃₀₀ = 1 + D1 的 3 条。
- 同一运行目录再跑一遍：各段复用 pass_done.json，D1 复用已存结果，类别不变；再改写定的重复次数（进版本锁的预先参数）就停下。
Codex 审核第 20.2 节三处修改的边界核对（10-08 补，合成输入或替身，不制造整机内存压力）：
- D3 计时：合成逐行记录覆盖完成、库内比较超时（结束计时完整）、比较未完成（墙钟缺失、整行 20 秒）、部分比较未完成、
  未进入比较；缺失不补 0，耗时只按类别统计完成的行，#r1 与其余重复分开。
- D1 监控（真子进程，比较慢 30 秒）：footprint 每次都读失败时仍按墙钟终点结束且每秒读了压力；压力读不到、压力为红时
  都按资源干预立即结束。
- D1 派发（替身代替 d1_watch，等待窗口从 30 秒换成 3 秒）：持续红时不派下一条、资源干预那次不缓存，回落满窗口才重做；
  一开始就读不到压力时不派；同一条连续两次资源干预就停下，续跑接着做，第几次的编号接上。
原始记录在 ~/.local/share/rewardfail/stage2/runs/u18test-时间/；结果写 results/s2_u18/diag_check.json。诊断报告本身只写在
运行目录（不写 results/s2_u18/report.json，那是正式运行的位置）。
运行：.venv/bin/python -I tests/test_s2_u18_diag.py（在实验仓根目录）
"""
import json
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments"))

import s2_u18_diag as diag  # noqa: E402

OUT = ROOT / "results/s2_u18/diag_check.json"
GT, OK, WRONG = "2", "The answer is \\boxed{2}", "The answer is \\boxed{3}"
FRAC = "\\boxed{\\frac{4}{2}}"  # 字符串与标准答案不同，只有符号比较认得出（同自检 S4）
TASKS = {
    "x-k": {"id": "x-k", "gt": GT, "out": FRAC, "inject": {"slow": "compare", "sec": 6}},
    "x-hog": {"id": "x-hog", "gt": GT, "out": OK, "inject": {"hog_mb": 1200, "hold": 30}},
    "x-slow": {"id": "x-slow", "gt": GT, "out": OK, "inject": {"slow": "compare", "sec": 30}},
    "x-ok": {"id": "x-ok", "gt": GT, "out": OK},
    "x-one": {"id": "x-one", "gt": GT, "out": OK},
    "x-timeout": {"id": "x-timeout", "gt": GT, "out": FRAC, "inject": {"slow": "compare", "sec": 4}},
    "x-zero": {"id": "x-zero", "gt": GT, "out": WRONG},
}
D2 = ["x-one", "x-timeout", "x-zero"]
REP = {"k_ids": ["x-k"], "main_metric": {"n": 93733},
       "u_detail": {i: {"default": "0 分：比较超时", "reference": "0 分：比较超时"} for i in ("x-hog", "x-slow", "x-ok", *D2)}}
CHECKS = []


def check(name, expect, actual, ok):
    CHECKS.append({"check": name, "expect": expect, "actual": actual, "pass": bool(ok)})
    print("通过" if ok else "未通过", name, "|", json.dumps(actual, ensure_ascii=False, default=str)[:300])


def patch(repeats=3):
    diag.K_ID, diag.D1_IDS, diag.REPEATS = "x-k", ("x-hog", "x-slow", "x-ok"), repeats
    diag.D1_FP, diag.D1_WALL, diag.D2_LIMIT = 1 << 30, 8, 2
    diag.READING = {"x-hog": "不同", "x-slow": "相同", "x-ok": "相同", "x-one": "不同", "x-timeout": "相同", "x-zero": "相同"}
    diag.targets = lambda: (REP, list(D2))
    diag.tasks_for = lambda ids: {i: dict(TASKS[i]) for i in ids}


def d3_timing():
    """第 20.2 节第 3 项：合成逐行记录（主测量精简格式），不跑判分。"""
    def row(n, cls, steps, wall):
        return {"id": f"x-k#r{n}", "class": cls, "wall": wall, "attempts": [{"steps": steps}]}
    cmp_ = lambda w, end, cats=(): ["compare", w, end, list(cats), 0]  # noqa: E731
    parse = ["pred_parse", 0.2, True, [], 0]
    rows = [row(3, "比较中止（未裁定）", [parse, cmp_(None, False)], 20.0),    # 比较未完成：墙钟缺失，整行 20 秒
            row(1, "1 分", [parse, cmp_(6.1, True)], 6.4),
            row(2, "0 分：比较超时", [parse, cmp_(5.0, True, ["timeout"])], 5.3),  # 库内超时，结束计时完整
            row(4, "0 分：解析超时", [["pred_parse", 5.0, True, ["timeout"], 0]], 5.2),  # 未进入比较
            row(10, "1 分", [parse, cmp_(7.0, True)], 7.3),
            row(5, "1 分", [parse, cmp_(3.0, True), cmp_(None, False)], None)]  # 部分比较未完成，整行墙钟也缺
    s = diag.d3_summary([diag.row_view(r, lambda c: None) for r in rows])
    views = {r["id"]: (r["timing"], r["compare_wall"]) for r in s["rows"]}
    check("D3 计时：缺失不补 0", "未完成两行比较墙钟为缺失，不进统计；未进入比较单列；各类别统计里没有 0 秒",
          {"timing": s["timing"], "views": views, "by_class": s["compare_wall_by_class"]},
          s["timing"] == {"完成": 3, "比较未完成": 2, "未进入比较": 1}
          and views["x-k#r3"] == ("比较未完成", None) and views["x-k#r5"] == ("比较未完成", None)
          and views["x-k#r4"] == ("未进入比较", None)
          and s["compare_wall_by_class"] == {"0 分：比较超时": {"n": 1, "median": 5.0, "min": 5.0, "max": 5.0},
                                             "1 分": {"n": 2, "median": 6.55, "min": 6.1, "max": 7.0}})
    check("D3 计时：首次与重复分开", "按编号数值排序，#r1 单列；重复只统计 #r2 起完成的行；整行墙钟缺失 1 行",
          {"first": s["first"], "repeats": s["repeats_compare_wall_by_class"], "order": [r["id"] for r in s["rows"]],
           "row_wall_missing": s["row_wall_missing"]},
          s["first"] == {"id": "x-k#r1", "class": "1 分", "timing": "完成", "compare_wall": 6.1}
          and s["repeats_compare_wall_by_class"] == {"0 分：比较超时": {"n": 1, "median": 5.0, "min": 5.0, "max": 5.0},
                                                     "1 分": {"n": 1, "median": 7.0, "min": 7.0, "max": 7.0}}
          and [r["id"] for r in s["rows"]][-1] == "x-k#r10" and s["row_wall_missing"] == 1)


def d1_monitor(base):
    """第 20.2 节第 1 项：真子进程（比较慢 30 秒），换掉 footprint 或压力的读数。"""
    d = base / "boundary" / "monitor"
    d.mkdir(parents=True, exist_ok=True)
    usage, pressure, wall = diag.mem.usage, diag.guard_mod.pressure, diag.D1_WALL
    slow = dict(TASKS["x-slow"])
    try:
        def broken(pid=None):
            raise OSError("合成：footprint 读不到")
        diag.mem.usage, diag.D1_WALL = broken, 4
        r = diag.d1_watch(d, dict(slow, id="m-fpfail"), None)
        check("D1 监控：footprint 读不到", "仍按墙钟终点（4 秒）结束，每秒都读了压力；不是资源干预",
              {k: r[k] for k in ("stopped_by", "stop_kind", "seconds", "fp_read_fail", "pressure_reads", "fp_max_MiB")},
              (r["stopped_by"] or "").startswith("墙钟") and r["stop_kind"] == "取栈终点" and r["seconds"] < 12
              and r["fp_read_fail"].get("OSError", 0) >= 4 and r["pressure_reads"] >= 4 and r["fp_max_MiB"] is None)
        diag.mem.usage, diag.D1_WALL = usage, 120
        for name, val, word in (("压力读不到", None, "读不到"), ("压力为红", 4, "变红")):
            diag.guard_mod.pressure = lambda v=val: v
            r = diag.d1_watch(d, dict(slow, id=f"m-pr{val}"), None)
            check(f"D1 监控：{name}", "第一次读数就按资源干预结束（墙钟终点 120 秒远未到）",
                  {k: r[k] for k in ("stopped_by", "stop_kind", "seconds", "pressure_reads")},
                  word in (r["stopped_by"] or "") and r["stop_kind"] == "资源干预" and r["pressure_reads"] == 1
                  and r["seconds"] < 6)
    finally:
        diag.mem.usage, diag.guard_mod.pressure, diag.D1_WALL = usage, pressure, wall


def d1_dispatch(base):
    """第 20.2 节第 2 项：替身代替 d1_watch，压力由测试控制；等待窗口换成 3 秒（脚本写定的是 30 秒）。"""
    defaults = {"D1_RESUME": diag.D1_RESUME, "D1_MAX_RES": diag.D1_MAX_RES}
    check("D1 派发：写定参数", "回落窗口 30 秒，同一条连续 2 次资源干预就停", defaults, defaults == {"D1_RESUME": 30, "D1_MAX_RES": 2})
    saved = (diag.d1_watch, diag.guard_mod.pressure, diag.D1_IDS, diag.D1_RESUME)
    state, calls, script = {"pr": 1}, [], {}
    tasks = {"y-a": {"id": "y-a"}, "y-b": {"id": "y-b"}}

    def fake(d, t, reader, att=1):
        kind = script[t["id"]].pop(0)
        calls.append({"t": time.time(), "id": t["id"], "att": att, "pr": state["pr"]})
        if kind == "资源干预":
            state["pr"] = 4
            if state.get("auto_clear"):
                threading.Timer(0.5, lambda: state.update(pr=1)).start()
        return {"id": t["id"], "att": att, "stop_kind": kind, "fp_max_MiB": 1, "last_step": None,
                "stopped_by": "内存压力变红（D135）" if kind == "资源干预" else None if kind == "自己结束" else "墙钟超过 120 秒"}

    def lines(p):
        return [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()] if p.exists() else []

    def bg(d):
        d.mkdir(parents=True, exist_ok=True)
        th = threading.Thread(target=diag.run_d1, args=(d, tasks), daemon=True)
        th.start()
        return th

    diag.d1_watch, diag.guard_mod.pressure = fake, (lambda: state["pr"])
    diag.D1_IDS, diag.D1_RESUME = ("y-a", "y-b"), 3
    try:
        # 持续红，然后回落
        d = base / "boundary" / "red"
        script.update({"y-a": ["资源干预", "取栈终点"], "y-b": ["自己结束"]})
        th = bg(d)
        time.sleep(6)
        during = {"calls": len(calls), "cached": (d / "d1" / "y-a.json").exists()}
        t_clear = time.time()
        state["pr"] = 1
        th.join(30)
        a2 = calls[1] if len(calls) > 1 else {}
        cached = json.loads((d / "d1" / "y-a.json").read_text(encoding="utf-8")) if (d / "d1" / "y-a.json").exists() else {}
        g = lines(d / "d1" / "guard.jsonl")
        check("D1 派发：持续红后回落", "红的 6 秒里只派了第一次、没缓存；回落满 3 秒才重做 y-a（第 2 次），缓存的是取栈终点；"
              "再派 y-b；尝试记录 3 行，保护记录有暂停与恢复",
              {"during": during, "gap_after_clear": round(a2.get("t", 0) - t_clear, 2), "a2": a2,
               "cached": {k: cached.get(k) for k in ("att", "stop_kind")}, "attempts": len(lines(d / "d1" / "attempts.jsonl")),
               "guard": [e["ev"] for e in g], "alive": th.is_alive()},
              during == {"calls": 1, "cached": False} and not th.is_alive() and a2.get("id") == "y-a" and a2.get("att") == 2
              and a2["t"] - t_clear >= 3 and a2["pr"] == 1 and cached.get("stop_kind") == "取栈终点"
              and [c["id"] for c in calls] == ["y-a", "y-a", "y-b"] and len(lines(d / "d1" / "attempts.jsonl")) == 3
              and [e["ev"] for e in g] == ["pause", "resume"])
        # 一开始就读不到压力
        calls.clear()
        d = base / "boundary" / "unknown"
        state["pr"] = None
        script.update({"y-a": ["自己结束"], "y-b": ["自己结束"]})
        th = bg(d)
        time.sleep(4)
        n_during = len(calls)
        t_clear = time.time()
        state["pr"] = 2  # 黄色照常
        th.join(30)
        g = lines(d / "d1" / "guard.jsonl")
        check("D1 派发：读不到压力", "读不到的 4 秒里一条都不派；读到黄色满 3 秒后才派，黄色不拦",
              {"during": n_during, "first_gap": round(calls[0]["t"] - t_clear, 2) if calls else None,
               "guard": [[e["ev"], e.get("why")] for e in g], "ids": [c["id"] for c in calls]},
              n_during == 0 and not th.is_alive() and calls and calls[0]["t"] - t_clear >= 3
              and [c["id"] for c in calls] == ["y-a", "y-b"] and g and g[0]["why"] == "读不到内存压力")
        # 同一条连续两次资源干预：停下；续跑接着做
        calls.clear()
        d = base / "boundary" / "twice"
        state.update(pr=1, auto_clear=True)
        script.update({"y-a": ["资源干预", "资源干预"], "y-b": ["自己结束"]})
        d.mkdir(parents=True, exist_ok=True)
        try:
            diag.run_d1(d, tasks)
            stopped = None
        except SystemExit as e:
            stopped = str(e)
        first = {"stopped": (stopped or "")[:80], "calls": [(c["id"], c["att"]) for c in calls],
                 "cached": (d / "d1" / "y-a.json").exists()}
        calls.clear()
        script.update({"y-a": ["取栈终点"], "y-b": ["自己结束"]})
        state["pr"] = 2  # 续跑时已回落，仍须从尝试记录继承资源干预并观察满窗口
        t_resume = time.time()
        out = diag.run_d1(d, tasks)
        check("D1 派发：连续两次资源干预", "停下且不缓存、不派 y-b；同一目录续跑即使已回落，也先观察满 3 秒；"
              "y-a 记第 3 次并完成，再做 y-b",
              {"first": first, "resume": [(c["id"], c["att"]) for c in calls], "resume_wait": calls[0]["t"] - t_resume,
               "out": {i: out[i]["stop_kind"] for i in out}},
              stopped and "连续 2 次资源干预" in stopped and first["calls"] == [("y-a", 1), ("y-a", 2)] and not first["cached"]
              and calls[0]["t"] - t_resume >= 3
              and [(c["id"], c["att"]) for c in calls] == [("y-a", 3), ("y-b", 1)]
              and {i: out[i]["stop_kind"] for i in out} == {"y-a": "取栈终点", "y-b": "自己结束"})
    finally:
        diag.d1_watch, diag.guard_mod.pressure, diag.D1_IDS, diag.D1_RESUME = saved


def run(base):
    sys.argv = ["s2_u18_diag.py", "--run-dir", str(base), "--out", str(base / "report-test.json")]
    t0 = time.time()
    diag.main()
    return json.loads((base / "report-test.json").read_text(encoding="utf-8")), round(time.time() - t0, 1)


def main():
    base = diag.s2_main.RUNS / f"u18test-{time.strftime('%Y%m%d-%H%M%S')}"
    patch()
    r, sec = run(base)
    d3d, d3r = r["d3"]["d3-default"], r["d3"]["d3-reference"]
    check("D3 默认设置", "3 行都是“0 分：比较超时”，比较有完整结束计时（约 5 秒），按类别保留",
          {k: d3d[k] for k in ("classes", "timing", "compare_wall_by_class")},
          d3d["classes"] == {"0 分：比较超时": 3} and d3d["timing"] == {"完成": 3}
          and 4.5 <= d3d["compare_wall_by_class"]["0 分：比较超时"]["median"] < 6)
    check("D3 参照设置", "3 行都是 1 分，比较墙钟中位数 6–7 秒；#r1 与其余 2 次分开",
          {k: d3r[k] for k in ("classes", "timing", "compare_wall_by_class", "first", "repeats_compare_wall_by_class")},
          d3r["classes"] == {"1 分": 3} and 6 <= d3r["compare_wall_by_class"]["1 分"]["median"] < 7
          and d3r["first"]["id"] == "x-k#r1" and d3r["repeats_compare_wall_by_class"]["1 分"]["n"] == 2)
    d1 = r["d1"]
    stacks = {i: (base / "d1" / d1[i]["stacks"]).read_text(encoding="utf-8") if (base / "d1" / d1[i]["stacks"]).exists() else ""
              for i in d1}
    check("D1 占内存的行", "按 footprint 杀掉（门限 1024 MiB），被杀前写了调用栈",
          {k: d1["x-hog"][k] for k in ("stopped_by", "fp_max_MiB", "exit")}, (d1["x-hog"]["stopped_by"] or "").startswith("footprint")
          and d1["x-hog"]["fp_max_MiB"] > 1024 and "most recent call first" in stacks["x-hog"])
    check("D1 比较慢的行", "按墙钟杀掉（8 秒），调用栈里有注入的 slow_eq，最后一步是比较",
          {k: d1["x-slow"][k] for k in ("stopped_by", "seconds", "last_step")},
          (d1["x-slow"]["stopped_by"] or "").startswith("墙钟") and "slow_eq" in stacks["x-slow"]
          and (d1["x-slow"]["last_step"] or {}).get("kind") == "compare")
    check("D1 正常的行", "自己结束，结果为 1，没被杀", {k: d1["x-ok"][k] for k in ("stopped_by", "result", "exit")},
          d1["x-ok"]["stopped_by"] is None and (d1["x-ok"]["result"] or {}).get("res") == 1 and d1["x-ok"]["exit"] == 0)
    d2 = r["d2"]
    cls = {i: d2["rows"][i]["class"] for i in D2}
    check("D2 各行类别", "x-one 1 分；x-timeout 比较超时；x-zero 正常 0", cls,
          cls == {"x-one": "1 分", "x-timeout": "0 分：比较超时", "x-zero": "正常 0"})
    check("D2 汇总", "k₃₀₀=2、u₃₀₀=4；与人工初判不一致（读法“不同”却判 1）的是 x-one；外层 10 秒",
          {k: d2[k] for k in ("k_300", "u_300", "d0_disagree_but_1", "outer", "reading_vs_verdict")},
          d2["k_300"] == 2 and d2["u_300"] == 4 and d2["d0_disagree_but_1"] == ["x-one"] and d2["outer"] == 10)
    spec_d2 = json.loads((base / "d2-ref300" / "pass_spec.json").read_text(encoding="utf-8"))
    check("D2 段参数", "参照模式加 --limits 2，单行上限 2×10+90 秒，不设子进程上限", spec_d2,
          spec_d2["extra"] == ["--limits", "2"] and spec_d2["row_limit"] == 110 and spec_d2["child_limit"] is None)
    r2, sec2 = run(base)
    reused = all((base / p / "pass_done.json").exists() for p in ("d3-default", "d3-reference", "d2-ref300"))
    same = (r2["d3"]["d3-default"]["classes"] == d3d["classes"] and r2["d2"]["rows"] == d2["rows"]
            and r2["d1"] == d1)
    check("同一运行目录续跑", "各段复用、D1 复用，结果相同，几秒内完成", {"seconds": sec2, "first_seconds": sec, "same": same},
          reused and same and sec2 < 60)
    patch(repeats=4)
    try:
        run(base)
        stopped = None
    except SystemExit as e:
        stopped = str(e)[:200]
    check("改了写定参数后续跑", "版本锁不同，停下", stopped, stopped and "执行版本与第一次运行不同" in stopped)
    d3_timing()
    d1_monitor(base)
    d1_dispatch(base)
    n_fail = sum(not c["pass"] for c in CHECKS)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({"what": "补充诊断脚本机制测试（合成输入，不碰主测量的 19 行）", "run_dir": str(base),
                               "seconds": sec, "checks": CHECKS, "n_fail": n_fail}, ensure_ascii=False, indent=1,
                              default=str), encoding="utf-8")
    print(f"{len(CHECKS)} 项，失败 {n_fail} 项；写 {OUT}")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()
